import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const schema = z.object({
  funeralHomeId: z.string().uuid(),
  customerName: z.string().trim().min(2).max(100),
  customerPhone: z.string().trim().min(10).max(20),
  customerEmail: z.string().trim().email().max(255).optional().or(z.literal("")),
  notes: z.string().trim().max(1000).optional(),
  serviceIds: z.array(z.string().uuid()).min(1).max(50),
});

function escapeHtml(text: string): string {
  const map: Record<string, string> = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;",
  };
  return text.replace(/[&<>"']/g, (m) => map[m]);
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const parsed = schema.safeParse(await req.json());
    if (!parsed.success) {
      return new Response(
        JSON.stringify({ error: "Date invalide", details: parsed.error.flatten().fieldErrors }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } },
      );
    }

    const { funeralHomeId, customerName, customerPhone, customerEmail, notes, serviceIds } =
      parsed.data;

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const { data: home, error: homeError } = await supabase
      .from("funeral_homes")
      .select("id, name, email")
      .eq("id", funeralHomeId)
      .single();
    if (homeError || !home) throw new Error("Firma nu a fost găsită");

    const { data: services, error: servicesError } = await supabase
      .from("services")
      .select("id, name, price")
      .eq("funeral_home_id", funeralHomeId)
      .eq("approval_status", "approved")
      .in("id", serviceIds);
    if (servicesError) throw servicesError;
    if (!services || services.length === 0) throw new Error("Serviciile selectate nu sunt valide");

    const { data: order, error: orderError } = await supabase
      .from("orders")
      .insert({
        funeral_home_id: funeralHomeId,
        customer_name: customerName,
        customer_email: customerEmail || "",
        customer_phone: customerPhone,
        total_price: 0,
        status: "pending",
        order_type: "custom",
        lead_source: "custom_package",
        notes: notes || null,
      })
      .select("id")
      .single();
    if (orderError) throw orderError;

    const { error: itemsError } = await supabase.from("order_items").insert(
      services.map((s) => ({
        order_id: order.id,
        service_id: s.id,
        item_name: s.name,
        item_price: Number(s.price),
        quantity: 1,
      })),
    );
    if (itemsError) throw itemsError;

    if (RESEND_API_KEY) {
      const servicesHtml = services
        .map((s) => `<li>${escapeHtml(s.name)}</li>`)
        .join("");

      const html = `
        <h2>Cerere nouă — Pachet personalizat</h2>
        <p>Un client a compus un pachet personalizat pentru <strong>${escapeHtml(home.name)}</strong>.</p>
        <h3>Date client</h3>
        <ul style="list-style:none;padding:0;">
          <li><strong>Nume:</strong> ${escapeHtml(customerName)}</li>
          <li><strong>Telefon:</strong> ${escapeHtml(customerPhone)}</li>
          ${customerEmail ? `<li><strong>Email:</strong> ${escapeHtml(customerEmail)}</li>` : ""}
        </ul>
        <h3>Servicii solicitate</h3>
        <ul style="padding-left:20px;">${servicesHtml}</ul>
        ${notes ? `<h3>Detalii suplimentare</h3><p>${escapeHtml(notes)}</p>` : ""}
        <p style="color:#666;font-size:12px;">Prețul final se stabilește direct cu clientul. Email trimis automat prin Funerio.ro</p>
      `;

      const recipients = [home.email, "contactfunerio@gmail.com"].filter(Boolean);

      const emailResponse = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${RESEND_API_KEY}`,
        },
        body: JSON.stringify({
          from: "Funerio Solicitări <onboarding@resend.dev>",
          to: recipients,
          subject: `Pachet personalizat - ${customerName}`,
          html,
        }),
      });

      if (!emailResponse.ok) {
        console.error("Resend error:", await emailResponse.text());
      }
    }

    return new Response(JSON.stringify({ success: true, orderId: order.id }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error) {
    console.error("submit-custom-package error:", error);
    return new Response(JSON.stringify({ error: "Cererea nu a putut fi trimisă" }), {
      status: 500,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  }
};

serve(handler);
