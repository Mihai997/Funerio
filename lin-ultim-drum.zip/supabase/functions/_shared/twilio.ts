/**
 * Helperi partajati pentru integrarea Twilio.
 * - validare semnatura X-Twilio-Signature
 * - normalizare E.164
 * - parametri semnati pentru URL-urile de TwiML
 */

const encoder = new TextEncoder();

function bytesToBase64(bytes: Uint8Array): string {
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin);
}

function base64UrlEncode(input: string): string {
  return btoa(input).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function base64UrlDecode(input: string): string {
  const padded = input.replace(/-/g, "+").replace(/_/g, "/");
  return atob(padded + "=".repeat((4 - (padded.length % 4)) % 4));
}

async function hmac(algo: "SHA-1" | "SHA-256", secret: string, message: string): Promise<Uint8Array> {
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    { name: "HMAC", hash: algo },
    false,
    ["sign"],
  );
  const sig = await crypto.subtle.sign("HMAC", key, encoder.encode(message));
  return new Uint8Array(sig);
}

function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

/** Numarul in format E.164 romanesc (+40...). Returneaza null daca nu e valid. */
export function toE164(phone?: string | null): string | null {
  if (!phone) return null;
  let cleaned = phone.replace(/[\s\-().]/g, "");
  if (cleaned.startsWith("00")) cleaned = "+" + cleaned.slice(2);
  if (!cleaned.startsWith("+")) {
    cleaned = "+40" + cleaned.replace(/^0/, "");
  }
  return /^\+[1-9]\d{7,14}$/.test(cleaned) ? cleaned : null;
}

/**
 * Valideaza semnatura Twilio pentru un webhook.
 * `params` = parametrii POST form-encoded, `url` = URL-ul public exact configurat in Twilio.
 */
export async function isValidTwilioSignature(
  authToken: string,
  signature: string | null,
  url: string,
  params: Record<string, string>,
): Promise<boolean> {
  if (!signature) return false;
  const data = url + Object.keys(params).sort().map((k) => k + params[k]).join("");
  const expected = bytesToBase64(await hmac("SHA-1", authToken, data));
  return timingSafeEqual(expected, signature);
}

/**
 * Verifica semnatura incercand mai multe variante de URL (proxy, http/https),
 * pentru ca Twilio semneaza exact URL-ul pe care l-a apelat.
 */
export async function verifyTwilioRequest(
  req: Request,
  authToken: string,
  params: Record<string, string>,
): Promise<boolean> {
  const signature = req.headers.get("X-Twilio-Signature");
  if (!signature) return false;

  const raw = new URL(req.url);
  const forwardedHost = req.headers.get("x-forwarded-host");
  const candidates = new Set<string>([raw.toString()]);
  if (forwardedHost) {
    const alt = new URL(raw.toString());
    alt.host = forwardedHost;
    alt.protocol = "https:";
    candidates.add(alt.toString());
  }
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  if (supabaseUrl) {
    const alt = new URL(raw.pathname + raw.search, supabaseUrl);
    candidates.add(alt.toString());
  }

  for (const candidate of candidates) {
    if (await isValidTwilioSignature(authToken, signature, candidate, params)) return true;
  }
  return false;
}

/** Parseaza corpul form-encoded al unui webhook Twilio. */
export async function parseTwilioForm(req: Request): Promise<Record<string, string>> {
  const text = await req.text();
  const out: Record<string, string> = {};
  new URLSearchParams(text).forEach((value, key) => {
    out[key] = value;
  });
  return out;
}

/** Creeaza un token semnat, cu expirare, pentru parametrii TwiML. */
export async function signPayload(secret: string, payload: unknown, ttlSeconds = 3600): Promise<string> {
  const body = base64UrlEncode(JSON.stringify({ p: payload, exp: Date.now() + ttlSeconds * 1000 }));
  const sig = bytesToBase64(await hmac("SHA-256", secret, body)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  return `${body}.${sig}`;
}

/** Verifica si decodeaza un token semnat. Returneaza null daca e invalid sau expirat. */
export async function verifyPayload<T>(secret: string, token: string | null): Promise<T | null> {
  if (!token || !token.includes(".")) return null;
  const [body, sig] = token.split(".");
  const expected = bytesToBase64(await hmac("SHA-256", secret, body)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  if (!timingSafeEqual(expected, sig)) return null;
  try {
    const parsed = JSON.parse(base64UrlDecode(body)) as { p: T; exp: number };
    if (!parsed.exp || parsed.exp < Date.now()) return null;
    return parsed.p;
  } catch {
    return null;
  }
}

/** Anuntul legal de inregistrare, redat la inceputul fiecarui apel. */
export const RECORDING_NOTICE =
  "Acest apel este realizat prin Funerio și este înregistrat pentru calitate.";

export function xmlEscape(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}
