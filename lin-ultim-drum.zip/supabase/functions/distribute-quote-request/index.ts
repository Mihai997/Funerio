import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";
import { z } from "npm:zod@3.25.76";

const BodySchema = z.object({
  county: z.string().trim().min(2).max(100),
  city: z.string().trim().min(1).max(100),
  customer_name: z.string().trim().min(2).max(100),
  customer_phone: z.string().trim().transform((value) => value.replace(/[\s\-()]/g, "")).refine((value) => /^(?:\+40|0)\d{9}$/.test(value)),
  customer_email: z.string().trim().email().max(200).optional(),
  funeral_home_ids: z.array(z.string().uuid()).min(1).max(3).optional(),
});

const escapeHtml = (value: string) => value.replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" })[character] ?? character);

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return new Response(JSON.stringify({ error: "Metodă nepermisă." }), { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } });

  try {
    const parsed = BodySchema.safeParse(await req.json());
    if (!parsed.success) return new Response(JSON.stringify({ error: "Verifică numele, telefonul și locația selectată." }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const backendUrl = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const resendKey = Deno.env.get("RESEND_API_KEY");
    if (!backendUrl || !serviceKey) throw new Error("Backend configuration is unavailable");
    const client = createClient(backendUrl, serviceKey);
    const { county, city, customer_name, customer_phone, customer_email, funeral_home_ids } = parsed.data;

    const baseQuery = () => client.from("funeral_homes").select("id, name, email, city").eq("county", county).eq("subscription_active", true).order("rating", { ascending: false }).order("name");
    let homes: { id: string; name: string; email: string; city: string }[] = [];
    let expandedToCounty = false;

    if (funeral_home_ids?.length) {
      const { data: chosen, error: chosenError } = await client
        .from("funeral_homes")
        .select("id, name, email, city")
        .in("id", funeral_home_ids);
      if (chosenError) throw chosenError;
      homes = chosen ?? [];
    } else {
    const { data: localHomes, error: localError } = await baseQuery().eq("city", city).limit(3);
    if (localError) throw localError;

    homes = localHomes ?? [];
    if (homes.length === 0) {
      const { data: countyHomes, error: countyError } = await baseQuery().limit(3);
      if (countyError) throw countyError;
      homes = countyHomes ?? [];
      expandedToCounty = true;
    }
    }
    if (homes.length === 0) return new Response(JSON.stringify({ error: "Momentan nu există firme disponibile în județul selectat." }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const orders = homes.map((home) => ({ funeral_home_id: home.id, customer_name, customer_phone, customer_email: customer_email || "necunoscut@example.com", total_price: 0, status: "pending", lead_source: "quote" }));
    const { error: orderError } = await client.from("orders").insert(orders);
    if (orderError) throw orderError;

    if (resendKey) {
      const emailResults = await Promise.allSettled(homes.map((home) => fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${resendKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: "Funerio <onboarding@resend.dev>",
          to: [home.email],
          subject: `Cerere de ofertă nouă prin Funerio - ${customer_name}`,
          html: `<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto"><h1>Funerio</h1><h2>Cerere de ofertă nouă</h2><p>Bună ziua, <strong>${escapeHtml(home.name)}</strong>.</p><p>Ați primit o cerere nouă din <strong>${escapeHtml(city)}, ${escapeHtml(county)}</strong>.</p><p><strong>Nume:</strong> ${escapeHtml(customer_name)}<br><strong>Telefon:</strong> <a href="tel:${escapeHtml(customer_phone)}">${escapeHtml(customer_phone)}</a></p><p>Vă recomandăm să contactați clientul cât mai curând.</p></div>`,
        }),
      }).then(async (response) => {
        if (!response.ok) throw new Error(`Email provider returned ${response.status}`);
      })));
      const failedEmails = emailResults.filter((result) => result.status === "rejected").length;
      if (failedEmails > 0) console.error(`Quote request email delivery failed for ${failedEmails} recipient(s)`);
    }

    return new Response(JSON.stringify({ success: true, firmsCount: homes.length, expandedToCounty }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (error) {
    console.error("distribute-quote-request failed", error instanceof Error ? error.message : "Unknown error");
    return new Response(JSON.stringify({ error: "Cererea nu a putut fi trimisă. Încearcă din nou." }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});