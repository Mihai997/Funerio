import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const prefixes = [
  "Casa Funebră", "Memorial", "Eternitate", "Servicii Funerare", "Pompe Funebre",
  "Casa Memorială", "Îngerașul", "Sfânta Cruce", "Odihna Eternă", "Lumina Veșnică",
  "Pace Eternă", "Speranța", "Recviem", "Compasiune", "Casa Păcii",
  "Sfântul Gheorghe", "Învierea", "Paradisul", "Cer Senin", "Grădina Eternă",
];

const suffixes = [
  "", "Plus", "Grup", "Serv", "Expert", "Total", "Com", "Impex", "Pro", "Gold",
];

const countyToCities: Record<string, string[]> = {
  "Alba": ["Alba Iulia", "Aiud", "Sebeș", "Blaj", "Cugir"],
  "Arad": ["Arad", "Ineu", "Lipova", "Pecica", "Curtici"],
  "Argeș": ["Pitești", "Curtea de Argeș", "Câmpulung", "Mioveni", "Costești"],
  "Bacău": ["Bacău", "Onești", "Moinești", "Comănești", "Buhuși"],
  "Bihor": ["Oradea", "Salonta", "Marghita", "Beiuș", "Aleșd"],
  "Bistrița-Năsăud": ["Bistrița", "Năsăud", "Beclean", "Sângeorz-Băi"],
  "Botoșani": ["Botoșani", "Dorohoi", "Darabani", "Săveni"],
  "Brașov": ["Brașov", "Făgăraș", "Săcele", "Codlea", "Zărnești"],
  "Brăila": ["Brăila", "Ianca", "Însurăței", "Făurei"],
  "București": ["București", "Sector 1", "Sector 2", "Sector 3", "Sector 4", "Sector 5", "Sector 6"],
  "Buzău": ["Buzău", "Râmnicu Sărat", "Nehoiu", "Pătârlagele"],
  "Caraș-Severin": ["Reșița", "Caransebeș", "Oravița", "Moldova Nouă", "Bocșa"],
  "Călărași": ["Călărași", "Oltenița", "Budești", "Fundulea"],
  "Cluj": ["Cluj-Napoca", "Turda", "Dej", "Câmpia Turzii", "Gherla"],
  "Constanța": ["Constanța", "Mangalia", "Medgidia", "Cernavodă", "Năvodari"],
  "Covasna": ["Sfântu Gheorghe", "Târgu Secuiesc", "Covasna", "Întorsura Buzăului"],
  "Dâmbovița": ["Târgoviște", "Moreni", "Pucioasa", "Găești", "Titu"],
  "Dolj": ["Craiova", "Băilești", "Calafat", "Filiași", "Segarcea"],
  "Galați": ["Galați", "Tecuci", "Târgu Bujor", "Berești"],
  "Giurgiu": ["Giurgiu", "Bolintin-Vale", "Mihăilești"],
  "Gorj": ["Târgu Jiu", "Motru", "Rovinari", "Bumbești-Jiu", "Novaci"],
  "Harghita": ["Miercurea Ciuc", "Odorheiu Secuiesc", "Toplița", "Gheorgheni", "Cristuru Secuiesc"],
  "Hunedoara": ["Deva", "Hunedoara", "Petroșani", "Brad", "Orăștie"],
  "Ialomița": ["Slobozia", "Fetești", "Urziceni", "Țăndărei"],
  "Iași": ["Iași", "Pașcani", "Hârlău", "Târgu Frumos"],
  "Ilfov": ["Voluntari", "Pantelimon", "Buftea", "Popești-Leordeni", "Bragadiru"],
  "Maramureș": ["Baia Mare", "Sighetu Marmației", "Borșa", "Vișeu de Sus"],
  "Mehedinți": ["Drobeta-Turnu Severin", "Strehaia", "Orșova", "Baia de Aramă"],
  "Mureș": ["Târgu Mureș", "Reghin", "Sighișoara", "Târnăveni", "Luduș"],
  "Neamț": ["Piatra Neamț", "Roman", "Târgu Neamț", "Bicaz", "Roznov"],
  "Olt": ["Slatina", "Caracal", "Scornicești", "Balș", "Corabia"],
  "Prahova": ["Ploiești", "Câmpina", "Băicoi", "Sinaia", "Vălenii de Munte"],
  "Satu Mare": ["Satu Mare", "Carei", "Negrești-Oaș", "Tășnad"],
  "Sălaj": ["Zalău", "Șimleu Silvaniei", "Jibou", "Cehu Silvaniei"],
  "Sibiu": ["Sibiu", "Mediaș", "Cisnădie", "Avrig", "Agnita"],
  "Suceava": ["Suceava", "Fălticeni", "Rădăuți", "Câmpulung Moldovenesc", "Vatra Dornei"],
  "Teleorman": ["Alexandria", "Roșiori de Vede", "Turnu Măgurele", "Zimnicea"],
  "Timiș": ["Timișoara", "Lugoj", "Sânnicolau Mare", "Jimbolia", "Buziaș"],
  "Tulcea": ["Tulcea", "Babadag", "Măcin", "Isaccea"],
  "Vaslui": ["Vaslui", "Bârlad", "Huși", "Negrești"],
  "Vâlcea": ["Râmnicu Vâlcea", "Drăgășani", "Băile Olănești", "Călimănești", "Horezu"],
  "Vrancea": ["Focșani", "Adjud", "Panciu", "Mărășești", "Odobești"],
};

const descriptions = [
  "Oferim servicii funerare complete cu respect și profesionalism. Echipa noastră vă stă la dispoziție 24/7.",
  "Cu o experiență de peste 15 ani, asigurăm servicii funerare de cea mai înaltă calitate.",
  "Servicii funerare complete la prețuri accesibile. Ne ocupăm de toate aspectele organizării.",
  "Compasiune și profesionalism în cele mai grele momente. Servicii funerare complete.",
  "Tradiție și respect în serviciile funerare. Vă ajutăm să onorați memoria celor dragi.",
  "Servicii funerare moderne și tradiționale. Transport, sicrie, flori și organizare completă.",
  "Oferim pachete funerare personalizate pentru a respecta ultimele dorințe ale celor plecați.",
  "Echipă dedicată de profesioniști care vă ghidează prin fiecare etapă a procesului funerar.",
  "Servicii funerare de încredere cu transparență totală a costurilor și atenție la detalii.",
  "Ne dedicăm să oferim servicii funerare demne, la cele mai înalte standarde de calitate.",
];

const serviceTemplates = [
  { category: "transport", name: "Transport decedat în localitate", price: 500, priceUnit: "cursă", description: "Transport decedat în cadrul localității cu autovehicul specializat" },
  { category: "transport", name: "Transport decedat interjudețean", price: 1200, priceUnit: "cursă", description: "Transport decedat între județe cu autovehicul frigorific specializat" },
  { category: "transport", name: "Transport familie la cimitir", price: 300, priceUnit: "cursă", description: "Transport pentru familia îndoliată de la domiciliu la cimitir" },
  { category: "sicriu", name: "Sicriu lemn masiv stejar", price: 3500, priceUnit: "buc", description: "Sicriu din lemn masiv de stejar, finisaj premium, captuseala de mătase" },
  { category: "sicriu", name: "Sicriu lemn brad", price: 1200, priceUnit: "buc", description: "Sicriu din lemn de brad, model clasic, capitonat interior" },
  { category: "sicriu", name: "Sicriu metalic", price: 2800, priceUnit: "buc", description: "Sicriu metalic de înaltă calitate cu ornamente și finisaje elegante" },
  { category: "sicriu", name: "Sicriu lemn nuc", price: 4500, priceUnit: "buc", description: "Sicriu premium din lemn de nuc sculptat manual" },
  { category: "flori", name: "Coroană flori naturale mare", price: 800, priceUnit: "buc", description: "Coroană funerară din flori naturale, diametru 1.2m" },
  { category: "flori", name: "Coroană flori naturale mică", price: 400, priceUnit: "buc", description: "Coroană funerară din flori naturale, diametru 0.8m" },
  { category: "flori", name: "Aranjament floral altar", price: 350, priceUnit: "buc", description: "Aranjament floral decorativ pentru altar sau capelă" },
  { category: "flori", name: "Buchete condoleanțe", price: 200, priceUnit: "buc", description: "Buchet de condoleanțe din flori proaspete de sezon" },
  { category: "masa", name: "Masă de pomană (30 persoane)", price: 2500, priceUnit: "eveniment", description: "Organizare masă de pomană pentru 30 de persoane cu meniu tradițional complet" },
  { category: "masa", name: "Masă de pomană (50 persoane)", price: 4000, priceUnit: "eveniment", description: "Organizare masă de pomană pentru 50 de persoane cu meniu tradițional" },
  { category: "masa", name: "Masă de pomană (100 persoane)", price: 7500, priceUnit: "eveniment", description: "Organizare masă de pomană pentru 100 de persoane, meniu complet" },
  { category: "masa", name: "Colivă tradițională", price: 150, priceUnit: "buc", description: "Colivă tradițională românească preparată după rețete autentice" },
  { category: "pomeni", name: "Pachete pomană (30 buc)", price: 900, priceUnit: "set", description: "30 de pachete de pomană cu produse tradiționale" },
  { category: "pomeni", name: "Pachete pomană (50 buc)", price: 1400, priceUnit: "set", description: "50 de pachete de pomană complete cu lumânări și produse" },
  { category: "pomeni", name: "Lumânări și candele", price: 200, priceUnit: "set", description: "Set complet de lumânări și candele pentru ceremonie" },
  { category: "ceremonie", name: "Oficierea slujbei religioase", price: 800, priceUnit: "ceremonie", description: "Coordonarea și organizarea slujbei religioase cu preotul paroh" },
  { category: "ceremonie", name: "Muzică funebră live", price: 600, priceUnit: "ceremonie", description: "Ansamblu muzical pentru ceremonii funerare" },
  { category: "ceremonie", name: "Pregătire și îmbălsămare", price: 1000, priceUnit: "serviciu", description: "Pregătirea și îmbălsămarea decedatului de către specialiști" },
  { category: "ceremonie", name: "Închiriere capelă", price: 500, priceUnit: "zi", description: "Închiriere capelă pentru priveghiul și ceremonia de rămas bun" },
  { category: "documente", name: "Acte deces și formalități", price: 400, priceUnit: "serviciu", description: "Obținerea certificatului de deces și a tuturor actelor necesare" },
  { category: "documente", name: "Formalități cimitir", price: 300, priceUnit: "serviciu", description: "Rezervarea locului de veci și formalitățile necesare la cimitir" },
  { category: "crematoriu", name: "Serviciu incinerare", price: 2000, priceUnit: "serviciu", description: "Serviciu complet de incinerare cu urnă standard inclusă" },
  { category: "crematoriu", name: "Urnă premium", price: 800, priceUnit: "buc", description: "Urnă funerară premium din materiale nobile" },
  { category: "altele", name: "Cruce lemn monument", price: 1500, priceUnit: "buc", description: "Cruce monument din lemn masiv sculptat" },
  { category: "altele", name: "Anunțuri deces", price: 200, priceUnit: "serviciu", description: "Publicare anunțuri deces în presă locală și online" },
  { category: "altele", name: "Fotografie și video ceremonie", price: 700, priceUnit: "serviciu", description: "Documentare foto-video profesională a ceremoniei" },
];

const packageTemplates = [
  { name: "Pachet Economic", description: "Pachet funerar esențial cu servicii de bază la prețuri accesibile", priceMin: 2500, priceMax: 4000, serviceCount: [3, 5] },
  { name: "Pachet Standard", description: "Pachet funerar complet cu servicii esențiale și opțiuni suplimentare", priceMin: 4500, priceMax: 7000, serviceCount: [5, 7] },
  { name: "Pachet Premium", description: "Pachet funerar premium cu servicii de cea mai înaltă calitate", priceMin: 7500, priceMax: 11000, serviceCount: [6, 9] },
  { name: "Pachet Complet", description: "Pachet all-inclusive cu toate serviciile funerare disponibile", priceMin: 11000, priceMax: 15000, serviceCount: [8, 12] },
];

function randomInt(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomFloat(min: number, max: number, decimals = 1) {
  return parseFloat((Math.random() * (max - min) + min).toFixed(decimals));
}

function randomPick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function shuffle<T>(arr: T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceRoleKey);

    const counties = Object.keys(countyToCities);
    const usedNames = new Set<string>();
    const funeralHomes: any[] = [];

    // Generate 100 unique funeral homes
    for (let i = 0; i < 100; i++) {
      let name: string;
      do {
        const prefix = randomPick(prefixes);
        const suffix = randomPick(suffixes);
        name = suffix ? `${prefix} ${suffix}` : prefix;
        // Add city hint for uniqueness
        if (usedNames.has(name)) {
          const county = counties[i % counties.length];
          const city = randomPick(countyToCities[county]);
          name = `${prefix} ${city.split(" ")[0]}`;
        }
      } while (usedNames.has(name));
      usedNames.add(name);

      const county = counties[i % counties.length];
      const city = randomPick(countyToCities[county]);
      const priceRange = randomPick(["€", "€€", "€€€"]);
      const phonePrefix = randomPick(["072", "073", "074", "075", "076"]);
      const phone = `${phonePrefix}${randomInt(1000000, 9999999)}`;
      const emailSlug = name.toLowerCase()
        .replace(/[ăâ]/g, "a").replace(/[îí]/g, "i").replace(/[șş]/g, "s").replace(/[țţ]/g, "t")
        .replace(/[^a-z0-9]/g, "").substring(0, 20);

      funeralHomes.push({
        name,
        description: randomPick(descriptions),
        county,
        city,
        price_range: priceRange,
        rating: randomFloat(3.0, 5.0),
        review_count: randomInt(5, 250),
        phone,
        email: `contact@${emailSlug}.ro`,
        logo: `/placeholder.svg`,
      });
    }

    // Insert funeral homes
    const { data: insertedHomes, error: homesError } = await supabase
      .from("funeral_homes")
      .insert(funeralHomes)
      .select("id");

    if (homesError) throw homesError;

    const homeIds = insertedHomes!.map((h: any) => h.id);

    // Generate services for each home
    const allServices: any[] = [];
    const homeServiceMap: Record<string, string[]> = {};

    for (const homeId of homeIds) {
      const numServices = randomInt(5, 12);
      const selectedTemplates = shuffle(serviceTemplates).slice(0, numServices);
      const serviceEntries: any[] = [];

      for (const tmpl of selectedTemplates) {
        const priceVariation = randomFloat(0.7, 1.3);
        serviceEntries.push({
          funeral_home_id: homeId,
          name: tmpl.name,
          category: tmpl.category,
          description: tmpl.description,
          price: Math.round(tmpl.price * priceVariation),
          price_unit: tmpl.priceUnit,
        });
      }
      allServices.push(...serviceEntries);
    }

    // Insert services in batches of 500
    const insertedServiceIds: string[] = [];
    for (let i = 0; i < allServices.length; i += 500) {
      const batch = allServices.slice(i, i + 500);
      const { data: batchData, error: svcError } = await supabase
        .from("services")
        .insert(batch)
        .select("id, funeral_home_id");

      if (svcError) throw svcError;

      for (const svc of batchData!) {
        if (!homeServiceMap[svc.funeral_home_id]) {
          homeServiceMap[svc.funeral_home_id] = [];
        }
        homeServiceMap[svc.funeral_home_id].push(svc.id);
      }
    }

    // Generate packages for each home
    const allPackages: any[] = [];
    for (const homeId of homeIds) {
      const numPackages = randomInt(2, 4);
      const selectedPkgs = packageTemplates.slice(0, numPackages);

      for (const tmpl of selectedPkgs) {
        allPackages.push({
          funeral_home_id: homeId,
          name: tmpl.name,
          description: tmpl.description,
          price: randomInt(tmpl.priceMin, tmpl.priceMax),
        });
      }
    }

    // Insert packages in batches
    const packageServiceAssocs: any[] = [];
    for (let i = 0; i < allPackages.length; i += 500) {
      const batch = allPackages.slice(i, i + 500);
      const { data: pkgData, error: pkgError } = await supabase
        .from("packages")
        .insert(batch)
        .select("id, funeral_home_id");

      if (pkgError) throw pkgError;

      // Create package_services associations
      for (const pkg of pkgData!) {
        const homeServices = homeServiceMap[pkg.funeral_home_id] || [];
        if (homeServices.length === 0) continue;
        const numAssoc = Math.min(randomInt(3, 8), homeServices.length);
        const selectedSvcIds = shuffle(homeServices).slice(0, numAssoc);

        for (const svcId of selectedSvcIds) {
          packageServiceAssocs.push({
            package_id: pkg.id,
            service_id: svcId,
          });
        }
      }
    }

    // Insert package_services in batches
    for (let i = 0; i < packageServiceAssocs.length; i += 500) {
      const batch = packageServiceAssocs.slice(i, i + 500);
      const { error: assocError } = await supabase
        .from("package_services")
        .insert(batch);

      if (assocError) throw assocError;
    }

    return new Response(
      JSON.stringify({
        success: true,
        stats: {
          funeral_homes: homeIds.length,
          services: allServices.length,
          packages: allPackages.length,
          package_services: packageServiceAssocs.length,
        },
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
