import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";
import { z } from "npm:zod@3.25.76";
import {
  toE164,
  xmlEscape,
  parseTwilioForm,
  verifyTwilioRequest,
  signPayload,
  verifyPayload,
  RECORDING_NOTICE,
} from "../_shared/twilio.ts";

const BodySchema = z.object({
  callLogId: z.string().uuid(),
});

type CallbackToken = { logId: string };

const xml = (body: string) =>
  new Response(body, { status: 200, headers: { ...corsHeaders, "Content-Type": "text/xml" } });

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const twilioAccountSid = Deno.env.get("TWILIO_ACCOUNT_SID");
  const twilioAuthToken = Deno.env.get("TWILIO_AUTH_TOKEN");

  if (!supabaseUrl || !serviceKey || !twilioAccountSid || !twilioAuthToken) {
    return json({ error: "Serviciul de apel nu este configurat." }, 500);
  }

  const admin = createClient(supabaseUrl, serviceKey);
  const url = new URL(req.url);
  const mode = url.searchParams.get("mode");
  const token = url.searchParams.get("t");

  try {
    // --- Cereri venite de la Twilio (TwiML / status / recording) ---
    if (mode === "twiml" || mode === "status" || mode === "recording") {
      const form = await parseTwilioForm(req);
      if (!(await verifyTwilioRequest(req, twilioAuthToken, form))) {
        console.warn("firm-callback: invalid Twilio signature");
        return new Response("Forbidden", { status: 403, headers: corsHeaders });
      }

      const payload = await verifyPayload<CallbackToken>(serviceKey, token);
      if (!payload?.logId) {
        return xml(
          `<?xml version="1.0" encoding="UTF-8"?><Response><Say language="ro-RO">Link expirat.</Say></Response>`,
        );
      }
      const logId = payload.logId;

      if (mode === "recording") {
        const recordingUrl = form.RecordingUrl;
        if (recordingUrl) {
          await admin
            .from("call_logs")
            .update({ recording_url: recordingUrl + ".mp3" })
            .eq("id", logId);
        }
        return new Response("OK", { status: 200, headers: corsHeaders });
      }

      if (mode === "twiml") {
        const { data: log } = await admin
          .from("call_logs")
          .select("caller_phone, tracking_phone")
          .eq("id", logId)
          .maybeSingle();

        const clientNumber = toE164(log?.caller_phone);
        const callerId = toE164(log?.tracking_phone);
        if (!clientNumber || !callerId) {
          return xml(
            `<?xml version="1.0" encoding="UTF-8"?><Response><Say language="ro-RO">Ne pare rău, apelul nu poate fi realizat.</Say></Response>`,
          );
        }

        const statusUrl = `${supabaseUrl}/functions/v1/firm-callback?mode=status&t=${encodeURIComponent(token!)}`;
        const recordingCb = `${supabaseUrl}/functions/v1/firm-callback?mode=recording&t=${encodeURIComponent(token!)}`;

        return xml(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say language="ro-RO">${xmlEscape(RECORDING_NOTICE)} Vă conectăm cu clientul.</Say>
  <Dial callerId="${xmlEscape(callerId)}" timeout="30" record="record-from-answer-dual" recordingStatusCallback="${xmlEscape(recordingCb)}" action="${xmlEscape(statusUrl)}" method="POST">
    <Number>${xmlEscape(clientNumber)}</Number>
  </Dial>
</Response>`);
      }

      // mode === "status"
      const dialStatus = form.DialCallStatus ?? null;
      const dialDuration = parseInt(form.DialCallDuration || "0", 10) || 0;
      console.log(`Callback status for log ${logId}: ${dialStatus}, duration=${dialDuration}`);

      if (dialStatus === "completed" && dialDuration > 0) {
        await admin
          .from("call_logs")
          .update({
            call_duration: dialDuration,
            call_status: "completed",
            ended_at: new Date().toISOString(),
          })
          .eq("id", logId);
      } else {
        await admin
          .from("call_logs")
          .update({ call_status: dialStatus || "no-answer", ended_at: new Date().toISOString() })
          .eq("id", logId);
      }

      return xml(
        `<?xml version="1.0" encoding="UTF-8"?><Response><Say language="ro-RO">Mulțumim. La revedere.</Say></Response>`,
      );
    }

    // --- Cerere din aplicatie ---
    if (req.method !== "POST") {
      return json({ error: "Method not allowed" }, 405);
    }

    const authHeader = req.headers.get("Authorization") ?? "";
    const accessToken = authHeader.replace("Bearer ", "").trim();
    if (!accessToken) return json({ error: "Autentificare necesară." }, 401);

    const { data: userData, error: userError } = await admin.auth.getUser(accessToken);
    const user = userData?.user;
    if (userError || !user) return json({ error: "Sesiune invalidă." }, 401);

    const parsed = BodySchema.safeParse(await req.json());
    if (!parsed.success) return json({ error: "Cerere invalidă." }, 400);

    const { data: log } = await admin
      .from("call_logs")
      .select("id, funeral_home_id, caller_phone, call_duration, outcome, tracking_phone")
      .eq("id", parsed.data.callLogId)
      .maybeSingle();

    if (!log) return json({ error: "Lead-ul nu a fost găsit." }, 404);

    const [{ data: ownedHomeId }, { data: isAdmin }] = await Promise.all([
      admin.rpc("get_user_funeral_home", { _user_id: user.id }),
      admin.rpc("has_role", { _user_id: user.id, _role: "admin" }),
    ]);

    if (!isAdmin && ownedHomeId !== log.funeral_home_id) {
      return json({ error: "Nu ai acces la acest lead." }, 403);
    }

    if ((log.call_duration ?? 0) > 0 || log.outcome === "resolved") {
      return json(
        { error: "Apelul de revenire este disponibil doar pentru lead-uri nepreluate." },
        400,
      );
    }

    if (!toE164(log.caller_phone)) {
      return json({ error: "Acest lead nu are un număr de contact valid." }, 400);
    }

    const { data: home } = await admin
      .from("funeral_homes")
      .select("phone, tracking_phone")
      .eq("id", log.funeral_home_id)
      .maybeSingle();

    const fromNumber = toE164(home?.tracking_phone);
    const firmNumber = toE164(home?.phone);
    if (!firmNumber || !fromNumber) {
      return json({ error: "Firma nu are un număr de apel configurat." }, 400);
    }

    const signed = await signPayload(serviceKey, { logId: log.id } satisfies CallbackToken, 2 * 60 * 60);
    const twimlUrl = `${supabaseUrl}/functions/v1/firm-callback?mode=twiml&t=${encodeURIComponent(signed)}`;

    const twilioResponse = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${twilioAccountSid}/Calls.json`,
      {
        method: "POST",
        headers: {
          Authorization: "Basic " + btoa(`${twilioAccountSid}:${twilioAuthToken}`),
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({
          To: firmNumber,
          From: fromNumber,
          Url: twimlUrl,
          Method: "POST",
        }).toString(),
      },
    );

    const twilioResult = await twilioResponse.json();
    if (!twilioResponse.ok) {
      console.error("Twilio error:", twilioResponse.status, twilioResult);
      return json({ error: "Apelul nu a putut fi inițiat.", details: twilioResult?.message }, 502);
    }

    await admin
      .from("call_logs")
      .update({ call_status: "callback-initiated", call_sid: twilioResult.sid ?? undefined })
      .eq("id", log.id);

    return json({ ok: true });
  } catch (error: unknown) {
    console.error("firm-callback error:", error);
    return json({ error: "Eroare internă." }, 500);
  }
});
