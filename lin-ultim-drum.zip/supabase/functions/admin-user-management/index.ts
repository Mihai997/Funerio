import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.75.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? '';
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY') ?? '';

    const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('Unauthorized');
    }

    const supabaseUser = createClient(supabaseUrl, anonKey, {
      global: {
        headers: {
          Authorization: authHeader,
        },
      },
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    const { data: roleRows, error: roleError } = await supabaseUser
      .from('user_roles')
      .select('user_id')
      .eq('role', 'admin')
      .limit(1);

    if (roleError || !roleRows || roleRows.length === 0) {
      throw new Error('Unauthorized');
    }

    const { action, email, password, userId, funeralHomeId } = await req.json();

    if (action === 'list-users') {
      // Get all profiles
      const { data: profiles, error: profilesError } = await supabaseAdmin
        .from('profiles')
        .select('id');

      if (profilesError) throw profilesError;

      // Get all funeral homes
      const { data: funeralHomes, error: fhError } = await supabaseAdmin
        .from('funeral_homes')
        .select('id, name, owner_id');

      if (fhError) throw fhError;

      const users = [];
      
      for (const profile of profiles || []) {
        const { data: { user }, error: userError } = await supabaseAdmin.auth.admin.getUserById(profile.id);
        
        if (!userError && user) {
          const funeralHome = funeralHomes?.find(fh => fh.owner_id === user.id);
          users.push({
            id: user.id,
            email: user.email || "",
            funeral_home: funeralHome
          });
        }
      }

      return new Response(
        JSON.stringify({ users }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'create-user') {
      // Create new user
      const { data: newUser, error: createError } = await supabaseAdmin.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
      });

      if (createError) throw createError;

      // Link user to funeral home if provided
      if (funeralHomeId && newUser.user) {
        const { error: updateError } = await supabaseAdmin
          .from('funeral_homes')
          .update({ owner_id: newUser.user.id })
          .eq('id', funeralHomeId);

        if (updateError) throw updateError;
      }

      return new Response(
        JSON.stringify({ success: true, user: newUser }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'reset-password') {
      // Reset user password
      const { error: resetError } = await supabaseAdmin.auth.admin.updateUserById(
        userId,
        { password }
      );

      if (resetError) throw resetError;

      return new Response(
        JSON.stringify({ success: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'delete-user') {
      // Delete user
      const { error: deleteError } = await supabaseAdmin.auth.admin.deleteUser(userId);

      if (deleteError) throw deleteError;

      return new Response(
        JSON.stringify({ success: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    throw new Error('Invalid action');

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
