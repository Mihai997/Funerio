import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";
import { z } from "npm:zod@3.25.76";
import {
  toE164,
  xmlEscape,
  parseTwilioForm,
  verifyTwilioRequest,
  signPayload,
  verifyPayload,
  RECORDING_NOTICE,
} from "../_shared/twilio.ts";

const InitialRequestSchema = z.object({
  county: z.string().trim().min(2).max(100),
  city: z.string().trim().min(1).max(100),
  userName: z.string().trim().min(2).max(100),
  userPhone: z.string().trim().min(9).max(20),
});

type Step = { id: string; name: string; phone: string; tracking: string };
type CallToken = { steps: Step[]; caller: string; callerName: string };

const xml = (body: string) =>
  new Response(body, { status: 200, headers: { ...corsHeaders, "Content-Type": "text/xml" } });

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

// Limitare de rata simpla, in memorie (per instanta): max 3 apeluri / ora / cheie
const rateBuckets = new Map<string, number[]>();
function rateLimited(key: string, max = 3, windowMs = 60 * 60 * 1000): boolean {
  const now = Date.now();
  const hits = (rateBuckets.get(key) ?? []).filter((t) => now - t < windowMs);
  if (hits.length >= max) {
    rateBuckets.set(key, hits);
    return true;
  }
  hits.push(now);
  rateBuckets.set(key, hits);
  return false;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const twilioAccountSid = Deno.env.get("TWILIO_ACCOUNT_SID");
    const twilioAuthToken = Deno.env.get("TWILIO_AUTH_TOKEN");
    if (!supabaseUrl || !supabaseServiceKey || !twilioAccountSid || !twilioAuthToken) {
      throw new Error("Call service configuration is unavailable");
    }
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const stepParam = url.searchParams.get("step");
    const token = url.searchParams.get("t");
    const isRecording = url.searchParams.get("rec") === "1";

    // ---------- Callback-uri Twilio ----------
    if (token) {
      const form = await parseTwilioForm(req);
      if (!(await verifyTwilioRequest(req, twilioAuthToken, form))) {
        console.warn("initiate-sequential-call: invalid Twilio signature");
        return new Response("Forbidden", { status: 403, headers: corsHeaders });
      }

      const payload = await verifyPayload<CallToken>(supabaseServiceKey, token);
      if (!payload) {
        return xml(
          `<?xml version="1.0" encoding="UTF-8"?><Response><Say language="ro-RO">Sesiunea de apel a expirat.</Say></Response>`,
        );
      }

      const { steps, caller, callerName } = payload;
      const currentStep = parseInt(stepParam ?? "0", 10) || 0;

      // Recording status callback pentru un pas
      if (isRecording) {
        const recordingUrl = form.RecordingUrl;
        const parentSid = form.CallSid;
        if (recordingUrl && parentSid) {
          await supabase
            .from("call_logs")
            .update({ recording_url: recordingUrl + ".mp3" })
            .eq("call_sid", `${parentSid}-step${currentStep}`);
        }
        return new Response("OK", { status: 200, headers: corsHeaders });
      }

      const dialCallStatus = form.DialCallStatus ?? null;
      const dialDuration = parseInt(form.DialCallDuration || "0", 10) || 0;
      const parentSid = form.CallSid ?? "unknown";

      // Actualizam pasul anterior
      if (currentStep > 0 && dialCallStatus) {
        const update: Record<string, unknown> = {
          call_status: dialCallStatus,
          ended_at: new Date().toISOString(),
        };
        if (dialDuration > 0) update.call_duration = dialDuration;
        await supabase
          .from("call_logs")
          .update(update)
          .eq("call_sid", `${parentSid}-step${currentStep - 1}`);
      }

      if (dialCallStatus === "completed" || dialCallStatus === "answered") {
        return xml(
          `<?xml version="1.0" encoding="UTF-8"?><Response><Say language="ro-RO">Mulțumim că ați folosit Funerio. La revedere.</Say></Response>`,
        );
      }

      if (currentStep >= steps.length) {
        return xml(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say language="ro-RO">Ne pare rău, nicio firmă din județul selectat nu a răspuns. Vă rugăm să încercați din nou mai târziu.</Say>
</Response>`);
      }

      const step = steps[currentStep];
      await supabase.from("call_logs").insert({
        funeral_home_id: step.id,
        caller_phone: caller,
        caller_name: callerName?.slice(0, 100) || null,
        tracking_phone: step.tracking,
        real_phone: step.phone,
        call_sid: `${parentSid}-step${currentStep}`,
        call_status: "initiated",
        started_at: new Date().toISOString(),
      });

      const base = `${supabaseUrl}/functions/v1/initiate-sequential-call`;
      const actionUrl = `${base}?step=${currentStep + 1}&t=${encodeURIComponent(token)}`;
      const recordingCb = `${base}?rec=1&step=${currentStep}&t=${encodeURIComponent(token)}`;

      return xml(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say language="ro-RO">${xmlEscape(RECORDING_NOTICE)} Vă conectăm la ${xmlEscape(step.name)}.</Say>
  <Dial action="${xmlEscape(actionUrl)}" method="POST" timeout="25" callerId="${xmlEscape(step.tracking)}" record="record-from-answer-dual" recordingStatusCallback="${xmlEscape(recordingCb)}">
    <Number>${xmlEscape(step.phone)}</Number>
  </Dial>
</Response>`);
    }

    // ---------- Cerere initiala din aplicatie ----------
    if (req.method !== "POST") {
      return json({ error: "Method not allowed" }, 405);
    }

    const parsed = InitialRequestSchema.safeParse(await req.json());
    if (!parsed.success) {
      return json({ error: "Verifică numele, telefonul și locația selectată." }, 400);
    }
    const { county, city, userName } = parsed.data;
    const userE164 = toE164(parsed.data.userPhone);
    if (!userE164) {
      return json({ error: "Numărul de telefon nu este valid." }, 400);
    }

    const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
    if (rateLimited(`phone:${userE164}`) || rateLimited(`ip:${ip}`, 10)) {
      return json({ error: "Prea multe cereri de apel. Încearcă din nou mai târziu." }, 429);
    }

    const homesQuery = () =>
      supabase
        .from("funeral_homes")
        .select("id, name, phone, tracking_phone, city")
        .eq("county", county)
        .eq("subscription_active", true)
        .not("tracking_phone", "is", null)
        .order("rating", { ascending: false })
        .order("name");

    const { data: localHomes, error: homesError } = await homesQuery().eq("city", city);
    if (homesError) {
      console.error("Error fetching funeral homes:", homesError);
      return json({ error: "Nu am putut verifica firmele disponibile." }, 500);
    }

    let homes = localHomes ?? [];
    let expandedToCounty = false;
    if (homes.length === 0) {
      const { data: countyHomes, error: countyError } = await homesQuery();
      if (countyError) {
        console.error("Error fetching county funeral homes:", countyError);
        return json({ error: "Nu am putut verifica firmele disponibile." }, 500);
      }
      homes = countyHomes ?? [];
      expandedToCounty = true;
    }

    const candidateSteps = homes.flatMap((home) => {
      const phone = toE164(home.phone);
      const tracking = toE164(home.tracking_phone);
      return phone && tracking
        ? [{ id: home.id, name: home.name.replace(/[<>&]/g, " "), phone, tracking }]
        : [];
    });

    if (candidateSteps.length === 0) {
      return json(
        { error: "Momentan nu există firme disponibile pentru apel în județul selectat." },
        404,
      );
    }

    // Ordonare aleatorie ponderata dupa scorul de prioritate al firmei (ultimele 90 de zile;
    // firmele noi pornesc de la 80 si trec treptat la scorul real in primele 10 apeluri).
    // Orice firma pastreaza o sansa minima (pondere >= 5).
    const ids = candidateSteps.map((s) => s.id);
    const { data: scoreRows, error: scoreError } = await supabase
      .rpc("get_firm_priority_scores", { _ids: ids });
    if (scoreError) console.error("Error loading priority scores:", scoreError);
    const scores = new Map<string, number>();
    for (const row of (scoreRows ?? []) as Array<{ funeral_home_id: string; final_score: number | string }>) {
      scores.set(row.funeral_home_id, Number(row.final_score));
    }

    const weighted: Array<Step & { weight: number }> = candidateSteps.map((step) => {
      const score = scores.get(step.id) ?? 80;
      return { ...step, weight: Math.max(5, Number.isFinite(score) ? score : 80) };
    });

    // Extragere fara inlocuire dupa pondere, apoi limita de siguranta 10 firme.
    const picked: Array<Step & { weight: number }> = [];
    let pool = [...weighted];
    while (pool.length > 0 && picked.length < 10) {
      const total = pool.reduce((sum, s) => sum + s.weight, 0);
      let r = Math.random() * total;
      let idx = pool.length - 1;
      for (let i = 0; i < pool.length; i++) {
        r -= pool[i].weight;
        if (r <= 0) {
          idx = i;
          break;
        }
      }
      picked.push(pool[idx]);
      pool = pool.filter((_, i) => i !== idx);
    }
    const steps: Step[] = picked;

    const signed = await signPayload(
      supabaseServiceKey,
      { steps, caller: userE164, callerName: userName } satisfies CallToken,
      2 * 60 * 60,
    );
    const twimlUrl = `${supabaseUrl}/functions/v1/initiate-sequential-call?step=0&t=${encodeURIComponent(signed)}`;

    const twilioResponse = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${twilioAccountSid}/Calls.json`,
      {
        method: "POST",
        headers: {
          Authorization: "Basic " + btoa(`${twilioAccountSid}:${twilioAuthToken}`),
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({
          To: userE164,
          From: steps[0].tracking,
          Url: twimlUrl,
          Method: "POST",
        }).toString(),
      },
    );

    const twilioResult = await twilioResponse.json();
    if (!twilioResponse.ok) {
      console.error("Twilio error:", twilioResult);
      return json({ error: "Failed to initiate call", details: twilioResult.message }, 500);
    }

    console.log("Call initiated successfully:", twilioResult.sid);

    return json({
      success: true,
      callSid: twilioResult.sid,
      firmsCount: steps.length,
      expandedToCounty,
      message: `Apel inițiat. Vei fi conectat pe rând cu ${steps.length} firme din ${county}.`,
    });
  } catch (error: unknown) {
    console.error("Error in initiate-sequential-call:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return json({ error: message }, 500);
  }
});
