import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

// Input validation schema
const checkoutSchema = z.object({
  customerName: z.string().trim().min(2),
  customerEmail: z.string().trim().email(),
  customerPhone: z.string().trim().min(10),
  funeralHomeName: z.string().trim(),
  services: z.array(z.object({
    name: z.string(),
    price: z.number(),
  })),
  packageName: z.string().optional(),
  totalCost: z.number(),
  churchLocation: z.string().optional(),
  cemeteryLocation: z.string().optional(),
  morgueLocation: z.string().optional(),
  paymentMethod: z.enum(["online", "la-sediu"]),
});

// HTML escape function
function escapeHtml(text: string): string {
  const map: { [key: string]: string } = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return text.replace(/[&<>"']/g, (m) => map[m]);
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const validationResult = checkoutSchema.safeParse(body);
    
    if (!validationResult.success) {
      console.error('Validation failed:', validationResult.error.format());
      return new Response(
        JSON.stringify({ 
          error: "Invalid input data",
          details: validationResult.error.errors.map(e => e.message)
        }),
        {
          status: 400,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    const { 
      customerName, 
      customerEmail, 
      customerPhone,
      funeralHomeName,
      services,
      packageName,
      totalCost,
      churchLocation,
      cemeteryLocation,
      morgueLocation,
      paymentMethod
    } = validationResult.data;

    console.log("Sending checkout email for:", customerName);

    const servicesHtml = services.map(s => 
      `<li>${escapeHtml(s.name)}: <strong>${s.price.toLocaleString("ro-RO")} RON</strong></li>`
    ).join('');

    const locationsHtml = [
      churchLocation && `<li><strong>Biserică:</strong> ${escapeHtml(churchLocation)}</li>`,
      cemeteryLocation && `<li><strong>Cimitir:</strong> ${escapeHtml(cemeteryLocation)}</li>`,
      morgueLocation && `<li><strong>Morgă:</strong> ${escapeHtml(morgueLocation)}</li>`,
    ].filter(Boolean).join('');

    // Send email to Funerio
    const emailResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: "Funerio Solicitări <onboarding@resend.dev>",
        to: ["contactfunerio@gmail.com"],
        reply_to: customerEmail,
        subject: `Solicitare Servicii Funerare - ${customerName}`,
        html: `
          <h2>Solicitare Nouă de Servicii Funerare</h2>
          <p>O nouă solicitare a fost primită prin platforma Funerio:</p>
          
          <hr style="margin: 20px 0; border: none; border-top: 1px solid #ddd;" />
          
          <h3>Detalii Client:</h3>
          <ul style="list-style: none; padding: 0;">
            <li><strong>Nume:</strong> ${escapeHtml(customerName)}</li>
            <li><strong>Email:</strong> ${escapeHtml(customerEmail)}</li>
            <li><strong>Telefon:</strong> ${escapeHtml(customerPhone)}</li>
          </ul>
          
          <h3>Furnizor Selectat:</h3>
          <p><strong>${escapeHtml(funeralHomeName)}</strong></p>
          
          ${packageName ? `
          <h3>Pachet Selectat:</h3>
          <p style="background: #f0f9ff; padding: 10px; border-radius: 5px; color: #0369a1;">
            <strong>${escapeHtml(packageName)}</strong>
          </p>
          ` : ''}
          
          <h3>Servicii Solicitate:</h3>
          <ul style="padding-left: 20px;">
            ${servicesHtml}
          </ul>
          
          ${locationsHtml ? `
          <h3>Locații:</h3>
          <ul style="list-style: none; padding: 0;">
            ${locationsHtml}
          </ul>
          ` : ''}
          
          <h3>Detalii Plată:</h3>
          <ul style="list-style: none; padding: 0;">
            <li><strong>Metodă Preferată:</strong> ${paymentMethod === 'online' ? 'Plată Online' : 'Plată la Sediul Firmei'}</li>
            <li style="font-size: 20px; color: #0369a1; margin-top: 10px;">
              <strong>Total Estimat:</strong> ${totalCost.toLocaleString("ro-RO")} RON
            </li>
          </ul>
          
          <hr style="margin: 20px 0; border: none; border-top: 1px solid #ddd;" />
          
          <p style="color: #666; font-size: 12px;">
            Acest email a fost trimis automat prin platforma Funerio.ro
          </p>
        `,
      }),
    });

    if (!emailResponse.ok) {
      throw new Error(`Failed to send email: ${await emailResponse.text()}`);
    }

    console.log("Email sent successfully");

    // Send confirmation email to customer
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: "Funerio <onboarding@resend.dev>",
        to: [customerEmail],
        subject: "Confirmare Solicitare - Funerio",
        html: `
          <h2>Bună ziua, ${escapeHtml(customerName)}!</h2>
          <p>Vă mulțumim pentru solicitarea dumneavoastră prin platforma Funerio.</p>
          
          <p>Am primit solicitarea pentru serviciile de la <strong>${escapeHtml(funeralHomeName)}</strong> și echipa noastră vă va contacta în cel mai scurt timp.</p>
          
          <h3>Sumar Solicitare:</h3>
          <ul style="padding-left: 20px;">
            ${servicesHtml}
          </ul>
          
          <p style="font-size: 18px; margin: 20px 0;">
            <strong>Total Estimat:</strong> ${totalCost.toLocaleString("ro-RO")} RON
          </p>
          
          <p>Dacă aveți întrebări urgente, ne puteți contacta direct la:</p>
          <ul style="list-style: none; padding: 0;">
            <li>📧 Email: contactfunerio@gmail.com</li>
          </ul>
          
          <p>Cu respect,<br><strong>Echipa Funerio</strong></p>
          
          <hr style="margin: 20px 0; border: none; border-top: 1px solid #ddd;" />
          
          <p style="color: #666; font-size: 12px;">
            Funerio - Platforma Digitală pentru Servicii Funerare
          </p>
        `,
      }),
    });

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Error in send-checkout-email function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
