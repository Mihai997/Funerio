import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

// Input validation schema
const contactSchema = z.object({
  name: z.string().trim().min(2, "Name must be at least 2 characters").max(100, "Name must be less than 100 characters"),
  email: z.string().trim().email("Invalid email address").max(255, "Email must be less than 255 characters"),
  phone: z.string().trim().min(10, "Phone must be at least 10 characters").max(20, "Phone must be less than 20 characters"),
  companyName: z.string().trim().min(2, "Company name must be at least 2 characters").max(200, "Company name must be less than 200 characters"),
  message: z.string().trim().min(10, "Message must be at least 10 characters").max(2000, "Message must be less than 2000 characters")
});

interface ContactEmailRequest {
  name: string;
  email: string;
  phone: string;
  companyName: string;
  message: string;
}

// Simple in-memory rate limiting (per deployment instance)
const requestLog = new Map<string, number[]>();
const RATE_LIMIT_WINDOW_MS = 60000; // 1 minute
const MAX_REQUESTS_PER_WINDOW = 3;

function checkRateLimit(identifier: string): boolean {
  const now = Date.now();
  const requests = requestLog.get(identifier) || [];
  
  // Remove old requests outside the window
  const recentRequests = requests.filter(time => now - time < RATE_LIMIT_WINDOW_MS);
  
  if (recentRequests.length >= MAX_REQUESTS_PER_WINDOW) {
    return false;
  }
  
  recentRequests.push(now);
  requestLog.set(identifier, recentRequests);
  return true;
}

// HTML escape function to prevent injection
function escapeHtml(text: string): string {
  const map: { [key: string]: string } = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return text.replace(/[&<>"']/g, (m) => map[m]);
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Rate limiting check
    const clientIp = req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || 'unknown';
    
    if (!checkRateLimit(clientIp)) {
      console.warn('Rate limit exceeded for:', clientIp);
      return new Response(
        JSON.stringify({ error: "Too many requests. Please try again later." }),
        {
          status: 429,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    // Parse and validate input
    const body = await req.json();
    const validationResult = contactSchema.safeParse(body);
    
    if (!validationResult.success) {
      console.error('Validation failed:', validationResult.error.format());
      return new Response(
        JSON.stringify({ 
          error: "Invalid input data",
          details: validationResult.error.errors.map(e => e.message)
        }),
        {
          status: 400,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    const { name, email, phone, companyName, message } = validationResult.data;

    console.log("Sending contact email from:", email, "IP:", clientIp);

    // Send email to company (Funerio) using fetch API
    const emailResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: "Funerio Contact <onboarding@resend.dev>",
        to: ["contact@funerio.ro"],
        reply_to: email,
        subject: `Cerere Parteneriat - ${companyName}`,
        html: `
          <h2>Cerere Nouă de Parteneriat</h2>
          <p>O nouă firmă funerară dorește să se alăture platformei Funerio:</p>
          
          <hr style="margin: 20px 0; border: none; border-top: 1px solid #ddd;" />
          
          <h3>Detalii Companie:</h3>
          <ul style="list-style: none; padding: 0;">
            <li><strong>Nume Firmă:</strong> ${escapeHtml(companyName)}</li>
            <li><strong>Persoană de Contact:</strong> ${escapeHtml(name)}</li>
            <li><strong>Email:</strong> ${escapeHtml(email)}</li>
            <li><strong>Telefon:</strong> ${escapeHtml(phone)}</li>
          </ul>
          
          <h3>Mesaj:</h3>
          <p style="background: #f5f5f5; padding: 15px; border-radius: 5px; white-space: pre-wrap;">${escapeHtml(message)}</p>
          
          <hr style="margin: 20px 0; border: none; border-top: 1px solid #ddd;" />
          
          <p style="color: #666; font-size: 12px;">
            Acest email a fost trimis automat prin formularul de contact de pe Funerio.ro
          </p>
        `,
      }),
    });

    if (!emailResponse.ok) {
      throw new Error(`Failed to send email: ${await emailResponse.text()}`);
    }

    console.log("Email sent successfully");

    // Send confirmation email to the company that submitted the form
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: "Funerio <onboarding@resend.dev>",
        to: [email],
        subject: "Am primit cererea dumneavoastră - Funerio",
        html: `
          <h2>Bună ziua, ${escapeHtml(name)}!</h2>
          <p>Vă mulțumim pentru interesul manifestat față de platforma Funerio.</p>
          
          <p>Am primit cererea dumneavoastră pentru <strong>${escapeHtml(companyName)}</strong> și echipa noastră vă va contacta în cel mai scurt timp pentru a discuta despre:</p>
          
          <ul>
            <li>Beneficiile platformei Funerio pentru firma dumneavoastră</li>
            <li>Pachetele și prețurile disponibile</li>
            <li>Procesul de înscriere și configurare a contului</li>
            <li>Modalitatea de adăugare a serviciilor și pachetelor</li>
          </ul>
          
          <p>Dacă aveți întrebări urgente, ne puteți contacta direct la:</p>
          <ul style="list-style: none; padding: 0;">
            <li>📞 Telefon: 0800 123 456</li>
            <li>📧 Email: contact@funerio.ro</li>
          </ul>
          
          <p>Cu stimă,<br><strong>Echipa Funerio</strong></p>
          
          <hr style="margin: 20px 0; border: none; border-top: 1px solid #ddd;" />
          
          <p style="color: #666; font-size: 12px;">
            Funerio - Platforma Digitală pentru Servicii Funerare
          </p>
        `,
      }),
    });

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Error in send-contact-email function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
