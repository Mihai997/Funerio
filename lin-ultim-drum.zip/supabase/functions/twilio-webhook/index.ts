import { createClient } from "npm:@supabase/supabase-js@2";
import {
  parseTwilioForm,
  verifyTwilioRequest,
  toE164,
  xmlEscape,
  RECORDING_NOTICE,
} from "../_shared/twilio.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const xml = (body: string) =>
  new Response(body, { status: 200, headers: { ...corsHeaders, "Content-Type": "text/xml" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const authToken = Deno.env.get("TWILIO_AUTH_TOKEN");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const formData = await parseTwilioForm(req);

    if (!authToken || !(await verifyTwilioRequest(req, authToken, formData))) {
      console.warn("Rejected request with invalid Twilio signature");
      return new Response("Forbidden", { status: 403, headers: corsHeaders });
    }

    console.log("Twilio webhook received:", JSON.stringify(formData));

    // Dial action callback (dupa ce <Dial> se termina)
    const dialCallStatus = formData.DialCallStatus;
    if (dialCallStatus) {
      const parentCallSid = formData.CallSid;
      const dialDuration = formData.DialCallDuration ? parseInt(formData.DialCallDuration) : 0;

      if (parentCallSid) {
        const updateData: Record<string, unknown> = {
          call_status: dialCallStatus === "completed" ? "completed" : dialCallStatus,
        };
        if (dialDuration > 0) {
          updateData.call_duration = dialDuration;
          updateData.ended_at = new Date().toISOString();
        }
        await supabase.from("call_logs").update(updateData).eq("call_sid", parentCallSid);
      }

      return xml(`<?xml version="1.0" encoding="UTF-8"?><Response></Response>`);
    }

    const callSid = formData.CallSid;
    const callStatus = formData.CallStatus;
    const callerPhone = formData.From || formData.Caller;
    const trackingPhone = formData.To || formData.Called;
    const callDuration = formData.CallDuration ? parseInt(formData.CallDuration) : 0;

    // Recording status callback
    const recordingUrl = formData.RecordingUrl;
    if (recordingUrl && formData.RecordingSid && !callStatus) {
      if (callSid) {
        const { error: recError } = await supabase
          .from("call_logs")
          .update({ recording_url: recordingUrl + ".mp3" })
          .eq("call_sid", callSid);
        if (recError) console.error("Error saving recording URL:", recError);
      }
      return new Response("OK", { status: 200, headers: corsHeaders });
    }

    if (!callSid) {
      return new Response("Missing CallSid", { status: 400, headers: corsHeaders });
    }

    const { data: funeralHome, error: fhError } = await supabase
      .from("funeral_homes")
      .select("id, phone")
      .eq("tracking_phone", trackingPhone)
      .maybeSingle();

    if (fhError) {
      console.error("Error finding funeral home:", fhError);
      return new Response("Error finding funeral home", { status: 500, headers: corsHeaders });
    }

    if (!funeralHome) {
      console.warn("No funeral home found for tracking phone:", trackingPhone);
      return xml(
        `<?xml version="1.0" encoding="UTF-8"?><Response><Say language="ro-RO">Numărul nu este configurat.</Say></Response>`,
      );
    }

    const { data: existingCall } = await supabase
      .from("call_logs")
      .select("id")
      .eq("call_sid", callSid)
      .maybeSingle();

    if (existingCall) {
      const updateData: Record<string, unknown> = { call_status: callStatus };
      if (callDuration > 0) {
        updateData.call_duration = callDuration;
        updateData.ended_at = new Date().toISOString();
      }
      if (recordingUrl) updateData.recording_url = recordingUrl + ".mp3";

      const { error: updateError } = await supabase
        .from("call_logs")
        .update(updateData)
        .eq("call_sid", callSid);
      if (updateError) console.error("Error updating call log:", updateError);
    } else {
      const { error: insertError } = await supabase.from("call_logs").insert({
        funeral_home_id: funeralHome.id,
        caller_phone: callerPhone,
        tracking_phone: trackingPhone,
        real_phone: funeralHome.phone,
        call_sid: callSid,
        call_status: callStatus,
        started_at: new Date().toISOString(),
      });
      if (insertError) console.error("Error inserting call log:", insertError);
    }

    if (callStatus === "ringing" || callStatus === "initiated" || !existingCall) {
      const forwardPhone = toE164(funeralHome.phone);
      if (!forwardPhone) {
        console.error("Invalid firm phone for forwarding:", funeralHome.phone);
        return xml(
          `<?xml version="1.0" encoding="UTF-8"?><Response><Say language="ro-RO">Momentan nu putem prelua apelul. Vă rugăm reveniți.</Say></Response>`,
        );
      }

      const callbackUrl = `${supabaseUrl}/functions/v1/twilio-webhook`;
      const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say language="ro-RO">${xmlEscape(RECORDING_NOTICE)}</Say>
  <Dial callerId="${xmlEscape(trackingPhone)}" timeout="30" record="record-from-answer-dual" recordingStatusCallback="${callbackUrl}" action="${callbackUrl}">
    <Number>${xmlEscape(forwardPhone)}</Number>
  </Dial>
</Response>`;

      return xml(twiml);
    }

    return new Response("OK", { status: 200, headers: corsHeaders });
  } catch (error: unknown) {
    console.error("Error in twilio-webhook:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
