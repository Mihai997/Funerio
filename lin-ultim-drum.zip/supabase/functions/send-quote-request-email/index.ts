import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const requestSchema = z.object({
  funeral_home_ids: z.array(z.string().uuid()).min(1).max(3),
  customer_name: z.string().trim().min(2).max(100),
  customer_phone: z.string().trim().min(10).max(20),
  customer_email: z.string().trim().max(255).optional(),
  county: z.string().trim().min(1).max(100),
  city: z.string().trim().min(1).max(100),
});

function escapeHtml(text: string): string {
  const map: Record<string, string> = {
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;",
  };
  return text.replace(/[&<>"']/g, (m) => map[m]);
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const validation = requestSchema.safeParse(body);

    if (!validation.success) {
      return new Response(
        JSON.stringify({ error: "Invalid input", details: validation.error.errors }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const { funeral_home_ids, customer_name, customer_phone, customer_email, county, city } = validation.data;

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data: homes, error: dbError } = await supabase
      .from("funeral_homes")
      .select("id, name, email")
      .in("id", funeral_home_ids);

    if (dbError) throw dbError;
    if (!homes || homes.length === 0) {
      return new Response(
        JSON.stringify({ error: "No funeral homes found" }),
        { status: 404, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const emailPromises = homes.map((home) => {
      const emailHtml = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #ffffff;">
          <div style="background: #1a1a2e; padding: 30px; text-align: center;">
            <h1 style="color: #ffffff; margin: 0; font-size: 24px;">Funerio</h1>
            <p style="color: #a0a0b0; margin: 8px 0 0;">Cerere de Ofertă Nouă</p>
          </div>
          
          <div style="padding: 30px;">
            <p style="font-size: 16px; color: #333;">Bună ziua, <strong>${escapeHtml(home.name)}</strong>,</p>
            <p style="color: #555;">Ați primit o cerere de ofertă nouă prin platforma Funerio. Mai jos găsiți detaliile clientului:</p>
            
            <div style="background: #f8f9fa; border-radius: 8px; padding: 20px; margin: 20px 0;">
              <h3 style="margin: 0 0 15px; color: #1a1a2e; font-size: 16px;">📋 Detalii Client</h3>
              <table style="width: 100%; border-collapse: collapse;">
                <tr>
                  <td style="padding: 8px 0; color: #666; width: 120px;">Nume:</td>
                  <td style="padding: 8px 0; color: #333; font-weight: bold;">${escapeHtml(customer_name)}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;">Telefon:</td>
                  <td style="padding: 8px 0; color: #333; font-weight: bold;">
                    <a href="tel:${escapeHtml(customer_phone)}" style="color: #0369a1; text-decoration: none;">${escapeHtml(customer_phone)}</a>
                  </td>
                </tr>
                ${customer_email ? `
                <tr>
                  <td style="padding: 8px 0; color: #666;">Email:</td>
                  <td style="padding: 8px 0; color: #333;">
                    <a href="mailto:${escapeHtml(customer_email)}" style="color: #0369a1; text-decoration: none;">${escapeHtml(customer_email)}</a>
                  </td>
                </tr>
                ` : ""}
              </table>
            </div>
            
            <div style="background: #f0f9ff; border-radius: 8px; padding: 20px; margin: 20px 0;">
              <h3 style="margin: 0 0 15px; color: #1a1a2e; font-size: 16px;">📍 Locația</h3>
              <p style="margin: 0; color: #333; font-size: 16px;">
                <strong>${escapeHtml(city)}</strong>, județul <strong>${escapeHtml(county)}</strong>
              </p>
            </div>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="tel:${escapeHtml(customer_phone)}" 
                 style="display: inline-block; background: #0369a1; color: #ffffff; padding: 14px 30px; border-radius: 8px; text-decoration: none; font-weight: bold; font-size: 16px;">
                📞 Contactează Clientul
              </a>
            </div>
            
            <p style="color: #888; font-size: 13px; text-align: center; margin-top: 30px;">
              Vă recomandăm să contactați clientul cât mai curând posibil.
            </p>
          </div>
          
          <div style="background: #f1f1f1; padding: 20px; text-align: center; font-size: 12px; color: #888;">
            Acest email a fost trimis automat prin platforma <a href="https://funerio.ro" style="color: #0369a1;">Funerio.ro</a>
          </div>
        </div>
      `;

      return fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${RESEND_API_KEY}`,
        },
        body: JSON.stringify({
          from: "Funerio <onboarding@resend.dev>",
          to: [home.email],
          subject: `Cerere de ofertă nouă prin Funerio - ${customer_name}`,
          html: emailHtml,
        }),
      });
    });

    const results = await Promise.allSettled(emailPromises);
    const failures = results.filter((r) => r.status === "rejected");
    if (failures.length > 0) {
      console.error("Some emails failed:", failures);
    }

    console.log(`Sent ${results.length - failures.length}/${results.length} quote request emails`);

    return new Response(
      JSON.stringify({ success: true, sent: results.length - failures.length, total: results.length }),
      { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  } catch (error: any) {
    console.error("Error in send-quote-request-email:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  }
};

serve(handler);
