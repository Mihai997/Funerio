import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const recordingUrl = url.searchParams.get("url");

    if (!recordingUrl) {
      return new Response(JSON.stringify({ error: "Missing url parameter" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Verify the URL is a Twilio recording URL
    if (!recordingUrl.includes("api.twilio.com") && !recordingUrl.includes("twilio.com")) {
      return new Response(JSON.stringify({ error: "Invalid recording URL" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const accountSid = Deno.env.get("TWILIO_ACCOUNT_SID");
    const authToken = Deno.env.get("TWILIO_AUTH_TOKEN");

    console.log("Account SID loaded:", accountSid ? `${accountSid.substring(0, 6)}... (${accountSid.length} chars)` : "MISSING");
    console.log("Auth Token loaded:", authToken ? `${authToken.substring(0, 4)}... (${authToken.length} chars)` : "MISSING");
    console.log("Fetching recording URL:", recordingUrl);

    if (!accountSid || !authToken) {
      return new Response(JSON.stringify({ error: "Twilio credentials not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Fetch recording from Twilio with Basic Auth
    const credentials = btoa(`${accountSid}:${authToken}`);
    const response = await fetch(recordingUrl, {
      headers: {
        "Authorization": `Basic ${credentials}`,
      },
    });

    if (!response.ok) {
      console.error("Twilio fetch failed:", response.status, response.statusText);
      return new Response(JSON.stringify({ error: "Failed to fetch recording" }), {
        status: response.status,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const audioData = await response.arrayBuffer();

    return new Response(audioData, {
      status: 200,
      headers: {
        ...corsHeaders,
        "Content-Type": "audio/mpeg",
        "Cache-Control": "public, max-age=86400",
      },
    });
  } catch (error: unknown) {
    console.error("Error in get-recording:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
