ALTER TABLE public.call_logs
  ADD COLUMN IF NOT EXISTS outcome text NOT NULL DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS contact_person text,
  ADD COLUMN IF NOT EXISTS outcome_notes text,
  ADD COLUMN IF NOT EXISTS outcome_amount numeric,
  ADD COLUMN IF NOT EXISTS resolved_at timestamp with time zone,
  ADD COLUMN IF NOT EXISTS resolved_by uuid;

CREATE INDEX IF NOT EXISTS call_logs_funeral_home_started_idx ON public.call_logs (funeral_home_id, started_at DESC);

CREATE POLICY "Owners can update their funeral home call logs"
ON public.call_logs
FOR UPDATE
USING (funeral_home_id = public.get_user_funeral_home(auth.uid()))
WITH CHECK (funeral_home_id = public.get_user_funeral_home(auth.uid()));

GRANT SELECT, UPDATE ON public.call_logs TO authenticated;
GRANT ALL ON public.call_logs TO service_role;

CREATE OR REPLACE FUNCTION public.get_firm_scores()
RETURNS TABLE (
  funeral_home_id uuid,
  funeral_home_name text,
  subscription_active boolean,
  total_leads bigint,
  answered_leads bigint,
  valid_leads bigint,
  resolved_leads bigint,
  lost_leads bigint,
  unprocessed_leads bigint,
  missed_leads bigint
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT
    f.id,
    f.name,
    f.subscription_active,
    COUNT(c.id)::bigint AS total_leads,
    COUNT(c.id) FILTER (WHERE COALESCE(c.call_duration, 0) > 0)::bigint AS answered_leads,
    COUNT(c.id) FILTER (WHERE COALESCE(c.call_duration, 0) > 30)::bigint AS valid_leads,
    COUNT(c.id) FILTER (WHERE c.outcome = 'resolved')::bigint AS resolved_leads,
    COUNT(c.id) FILTER (WHERE c.outcome = 'lost')::bigint AS lost_leads,
    COUNT(c.id) FILTER (WHERE COALESCE(c.call_duration, 0) > 30 AND COALESCE(c.outcome, 'pending') = 'pending')::bigint AS unprocessed_leads,
    COUNT(c.id) FILTER (WHERE COALESCE(c.call_duration, 0) = 0)::bigint AS missed_leads
  FROM public.funeral_homes f
  LEFT JOIN public.call_logs c ON c.funeral_home_id = f.id
  WHERE public.has_role(auth.uid(), 'admin'::app_role)
  GROUP BY f.id, f.name, f.subscription_active
$$;

GRANT EXECUTE ON FUNCTION public.get_firm_scores() TO authenticated;