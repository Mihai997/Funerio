ALTER TABLE public.services
  ADD COLUMN approval_status text NOT NULL DEFAULT 'pending',
  ADD COLUMN rejection_reason text,
  ADD COLUMN reviewed_at timestamptz,
  ADD COLUMN reviewed_by uuid;
ALTER TABLE public.packages
  ADD COLUMN approval_status text NOT NULL DEFAULT 'pending',
  ADD COLUMN rejection_reason text,
  ADD COLUMN reviewed_at timestamptz,
  ADD COLUMN reviewed_by uuid;

UPDATE public.services SET approval_status = 'approved';
UPDATE public.packages SET approval_status = 'approved';

ALTER TABLE public.services ADD CONSTRAINT services_approval_status_chk CHECK (approval_status IN ('pending','approved','rejected'));
ALTER TABLE public.packages ADD CONSTRAINT packages_approval_status_chk CHECK (approval_status IN ('pending','approved','rejected'));

CREATE OR REPLACE FUNCTION public.enforce_catalog_approval()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN NEW; -- backend/service calls
  END IF;
  IF public.has_role(auth.uid(), 'admin'::app_role) THEN
    IF TG_OP = 'INSERT' THEN
      NEW.approval_status := 'approved';
      NEW.reviewed_at := now();
      NEW.reviewed_by := auth.uid();
    END IF;
    RETURN NEW;
  END IF;
  NEW.approval_status := 'pending';
  NEW.rejection_reason := NULL;
  NEW.reviewed_at := NULL;
  NEW.reviewed_by := NULL;
  RETURN NEW;
END;
$$;

CREATE TRIGGER services_enforce_approval BEFORE INSERT OR UPDATE ON public.services
FOR EACH ROW EXECUTE FUNCTION public.enforce_catalog_approval();
CREATE TRIGGER packages_enforce_approval BEFORE INSERT OR UPDATE ON public.packages
FOR EACH ROW EXECUTE FUNCTION public.enforce_catalog_approval();

CREATE OR REPLACE FUNCTION public.reset_package_on_items_change()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _pid uuid := COALESCE(NEW.package_id, OLD.package_id);
BEGIN
  IF auth.uid() IS NOT NULL AND NOT public.has_role(auth.uid(), 'admin'::app_role) THEN
    UPDATE public.packages SET approval_status = 'pending', rejection_reason = NULL,
      reviewed_at = NULL, reviewed_by = NULL WHERE id = _pid;
  END IF;
  RETURN COALESCE(NEW, OLD);
END;
$$;
CREATE TRIGGER package_services_reset_approval AFTER INSERT OR DELETE ON public.package_services
FOR EACH ROW EXECUTE FUNCTION public.reset_package_on_items_change();

DROP POLICY "Everyone can view services" ON public.services;
CREATE POLICY "Everyone can view approved services" ON public.services FOR SELECT USING (approval_status = 'approved');
DROP POLICY "Everyone can view packages" ON public.packages;
CREATE POLICY "Everyone can view approved packages" ON public.packages FOR SELECT USING (approval_status = 'approved');
DROP POLICY "Everyone can view package services" ON public.package_services;
CREATE POLICY "Everyone can view approved package services" ON public.package_services FOR SELECT
USING (EXISTS (SELECT 1 FROM public.packages p WHERE p.id = package_id AND p.approval_status = 'approved'));