CREATE TABLE public.site_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_name text NOT NULL,
  session_id text NOT NULL,
  path text,
  county text,
  city text,
  metadata jsonb,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT INSERT ON public.site_events TO anon;
GRANT INSERT, SELECT ON public.site_events TO authenticated;
GRANT ALL ON public.site_events TO service_role;

ALTER TABLE public.site_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can log site events"
ON public.site_events
FOR INSERT
WITH CHECK (true);

CREATE POLICY "Admins can view site events"
ON public.site_events
FOR SELECT
USING (public.has_role(auth.uid(), 'admin'::app_role));

CREATE INDEX site_events_name_created_idx ON public.site_events (event_name, created_at DESC);
CREATE INDEX site_events_created_idx ON public.site_events (created_at DESC);

CREATE OR REPLACE FUNCTION public.get_site_funnel(_from timestamp with time zone, _to timestamp with time zone)
RETURNS TABLE (event_name text, sessions bigint, events bigint)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT e.event_name, COUNT(DISTINCT e.session_id)::bigint, COUNT(*)::bigint
  FROM public.site_events e
  WHERE public.has_role(auth.uid(), 'admin'::app_role)
    AND e.created_at >= _from
    AND e.created_at <= _to
  GROUP BY e.event_name
$$;

REVOKE EXECUTE ON FUNCTION public.get_site_funnel(timestamp with time zone, timestamp with time zone) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.get_site_funnel(timestamp with time zone, timestamp with time zone) TO authenticated;