ALTER TABLE public.call_logs
ADD COLUMN caller_name text;

ALTER TABLE public.call_logs
ADD CONSTRAINT call_logs_caller_name_length
CHECK (caller_name IS NULL OR char_length(caller_name) <= 100);