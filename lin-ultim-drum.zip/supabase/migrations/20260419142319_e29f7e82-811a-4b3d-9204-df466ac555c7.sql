ALTER TABLE public.funeral_homes
ADD COLUMN IF NOT EXISTS subscription_active boolean NOT NULL DEFAULT true;