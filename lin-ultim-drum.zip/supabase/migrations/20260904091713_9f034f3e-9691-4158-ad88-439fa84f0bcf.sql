-- 1. Ascunde coloana `phone` (numarul real al firmei) de vizitatorii publici
REVOKE SELECT ON public.funeral_homes FROM anon;
GRANT SELECT (
  id, name, logo, description, county, city, price_range, rating, review_count,
  email, owner_id, created_at, updated_at, tracking_phone, subscription_active
) ON public.funeral_homes TO anon;

-- 2. Sursa lead-ului pentru comenzi (doar raportare, nu se factureaza)
ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS lead_source text NOT NULL DEFAULT 'quote';

UPDATE public.orders SET lead_source = 'custom_package' WHERE order_type = 'custom';

ALTER TABLE public.orders
  ADD CONSTRAINT orders_lead_source_check
  CHECK (lead_source IN ('call', 'quote', 'custom_package'));