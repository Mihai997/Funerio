REVOKE EXECUTE ON FUNCTION public.enforce_catalog_approval() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.reset_package_on_items_change() FROM PUBLIC, anon, authenticated;