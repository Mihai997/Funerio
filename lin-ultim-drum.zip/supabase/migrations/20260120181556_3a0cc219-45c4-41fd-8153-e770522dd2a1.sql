-- Drop the overly permissive policy
DROP POLICY IF EXISTS "Service role can manage call logs" ON public.call_logs;

-- Create proper policies for call_logs management
-- Admins can manage all call logs
CREATE POLICY "Admins can manage all call logs"
ON public.call_logs
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));