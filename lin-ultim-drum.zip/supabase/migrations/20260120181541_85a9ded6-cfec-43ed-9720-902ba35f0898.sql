-- Create call_logs table for tracking phone calls
CREATE TABLE public.call_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  funeral_home_id UUID NOT NULL REFERENCES public.funeral_homes(id) ON DELETE CASCADE,
  caller_phone TEXT,
  tracking_phone TEXT NOT NULL,
  real_phone TEXT NOT NULL,
  call_sid TEXT UNIQUE,
  call_status TEXT NOT NULL DEFAULT 'initiated',
  call_duration INTEGER DEFAULT 0,
  started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  ended_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add tracking_phone column to funeral_homes
ALTER TABLE public.funeral_homes 
ADD COLUMN tracking_phone TEXT;

-- Enable RLS on call_logs
ALTER TABLE public.call_logs ENABLE ROW LEVEL SECURITY;

-- Policy: Admins can view all call logs
CREATE POLICY "Admins can view all call logs"
ON public.call_logs
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Policy: Owners can view their funeral home call logs
CREATE POLICY "Owners can view their funeral home call logs"
ON public.call_logs
FOR SELECT
USING (funeral_home_id = get_user_funeral_home(auth.uid()));

-- Policy: Edge function can insert call logs (service role)
CREATE POLICY "Service role can manage call logs"
ON public.call_logs
FOR ALL
USING (true)
WITH CHECK (true);

-- Create index for faster queries
CREATE INDEX idx_call_logs_funeral_home_id ON public.call_logs(funeral_home_id);
CREATE INDEX idx_call_logs_call_sid ON public.call_logs(call_sid);
CREATE INDEX idx_call_logs_started_at ON public.call_logs(started_at DESC);