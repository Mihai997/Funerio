-- Delete existing admin user and related data
DELETE FROM user_roles WHERE user_id = '37f3e5b8-e6c2-4fe2-91e7-d7db6ef56e19';
DELETE FROM auth.users WHERE id = '37f3e5b8-e6c2-4fe2-91e7-d7db6ef56e19';