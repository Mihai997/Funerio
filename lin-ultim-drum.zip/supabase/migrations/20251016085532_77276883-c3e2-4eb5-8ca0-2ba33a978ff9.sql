-- Drop existing restrictive SELECT policies on orders table
DROP POLICY IF EXISTS "Owners can view their funeral home orders" ON public.orders;

-- Create new policy that allows both funeral home owners AND customers to view orders
CREATE POLICY "Owners and customers can view orders"
ON public.orders
FOR SELECT
USING (
  funeral_home_id = get_user_funeral_home(auth.uid())
  OR customer_email = (auth.jwt()->>'email')
);

-- Drop existing restrictive SELECT policy on order_items
DROP POLICY IF EXISTS "Users can view order items for their orders" ON public.order_items;

-- Create new policy allowing customers to view their order items
CREATE POLICY "Owners and customers can view order items"
ON public.order_items
FOR SELECT
USING (
  order_id IN (
    SELECT id FROM public.orders 
    WHERE funeral_home_id = get_user_funeral_home(auth.uid())
       OR customer_email = (auth.jwt()->>'email')
  )
);