DROP POLICY IF EXISTS "Everyone can create orders" ON public.orders;
DROP POLICY IF EXISTS "Everyone can create order items" ON public.order_items;
DROP POLICY IF EXISTS "Anyone can log site events" ON public.site_events;
CREATE POLICY "Anyone can log valid site events" ON public.site_events
FOR INSERT TO anon, authenticated
WITH CHECK (
  char_length(event_name) BETWEEN 1 AND 64
  AND char_length(session_id) BETWEEN 1 AND 128
  AND (path IS NULL OR char_length(path) <= 512)
  AND (county IS NULL OR char_length(county) <= 100)
  AND (city IS NULL OR char_length(city) <= 100)
  AND (metadata IS NULL OR pg_column_size(metadata) <= 4096)
);