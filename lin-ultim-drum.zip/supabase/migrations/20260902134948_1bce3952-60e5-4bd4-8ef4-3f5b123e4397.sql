REVOKE EXECUTE ON FUNCTION public.get_firm_scores() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_firm_scores() TO authenticated;