
CREATE POLICY "Public can view firm logos"
ON storage.objects FOR SELECT
USING (bucket_id = 'firm-logos');

CREATE POLICY "Firm owners can upload their logo"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'firm-logos'
  AND (
    (storage.foldername(name))[1] = public.get_user_funeral_home(auth.uid())::text
    OR public.has_role(auth.uid(), 'admin'::app_role)
  )
);

CREATE POLICY "Firm owners can update their logo"
ON storage.objects FOR UPDATE TO authenticated
USING (
  bucket_id = 'firm-logos'
  AND (
    (storage.foldername(name))[1] = public.get_user_funeral_home(auth.uid())::text
    OR public.has_role(auth.uid(), 'admin'::app_role)
  )
);

CREATE POLICY "Firm owners can delete their logo"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'firm-logos'
  AND (
    (storage.foldername(name))[1] = public.get_user_funeral_home(auth.uid())::text
    OR public.has_role(auth.uid(), 'admin'::app_role)
  )
);
