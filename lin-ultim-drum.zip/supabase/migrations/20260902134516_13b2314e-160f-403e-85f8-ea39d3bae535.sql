CREATE OR REPLACE FUNCTION public.get_firm_scores()
 RETURNS TABLE(funeral_home_id uuid, funeral_home_name text, subscription_active boolean, total_leads bigint, answered_leads bigint, valid_leads bigint, resolved_leads bigint, lost_leads bigint, unprocessed_leads bigint, missed_leads bigint)
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT
    f.id,
    f.name,
    f.subscription_active,
    COUNT(c.id)::bigint AS total_leads,
    COUNT(c.id) FILTER (WHERE COALESCE(c.call_duration, 0) > 0)::bigint AS answered_leads,
    COUNT(c.id) FILTER (WHERE COALESCE(c.call_duration, 0) >= 40)::bigint AS valid_leads,
    COUNT(c.id) FILTER (WHERE c.outcome = 'resolved')::bigint AS resolved_leads,
    0::bigint AS lost_leads,
    COUNT(c.id) FILTER (WHERE COALESCE(c.call_duration, 0) >= 40 AND COALESCE(c.outcome, 'pending') <> 'resolved')::bigint AS unprocessed_leads,
    COUNT(c.id) FILTER (WHERE COALESCE(c.call_duration, 0) = 0)::bigint AS missed_leads
  FROM public.funeral_homes f
  LEFT JOIN public.call_logs c ON c.funeral_home_id = f.id
  WHERE public.has_role(auth.uid(), 'admin'::app_role)
  GROUP BY f.id, f.name, f.subscription_active
$function$;