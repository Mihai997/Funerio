-- Create profiles table for user information
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  phone TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create user_roles table
CREATE TABLE IF NOT EXISTS public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (user_id, role)
);

-- Create funeral_homes table
CREATE TABLE IF NOT EXISTS public.funeral_homes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  logo TEXT,
  description TEXT NOT NULL,
  county TEXT NOT NULL,
  city TEXT NOT NULL,
  price_range TEXT NOT NULL CHECK (price_range IN ('€', '€€', '€€€')),
  rating DECIMAL(2,1) DEFAULT 0.0 CHECK (rating >= 0 AND rating <= 5),
  review_count INTEGER DEFAULT 0,
  phone TEXT NOT NULL,
  email TEXT NOT NULL,
  owner_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create service_category enum if it doesn't exist
DO $$ BEGIN
  CREATE TYPE public.service_category AS ENUM (
    'transport',
    'sicriu',
    'flori',
    'masa',
    'pomeni',
    'ceremonie',
    'documente',
    'crematoriu',
    'altele'
  );
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

-- Create services table
CREATE TABLE IF NOT EXISTS public.services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  funeral_home_id UUID REFERENCES public.funeral_homes(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  category service_category NOT NULL,
  description TEXT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  price_unit TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create packages table
CREATE TABLE IF NOT EXISTS public.packages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  funeral_home_id UUID REFERENCES public.funeral_homes(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create package_services junction table
CREATE TABLE IF NOT EXISTS public.package_services (
  package_id UUID REFERENCES public.packages(id) ON DELETE CASCADE NOT NULL,
  service_id UUID REFERENCES public.services(id) ON DELETE CASCADE NOT NULL,
  PRIMARY KEY (package_id, service_id)
);

-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.funeral_homes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.package_services ENABLE ROW LEVEL SECURITY;

-- Security definer function to check user role
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- Security definer function to get user's funeral home
CREATE OR REPLACE FUNCTION public.get_user_funeral_home(_user_id UUID)
RETURNS UUID
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id FROM public.funeral_homes WHERE owner_id = _user_id LIMIT 1
$$;

-- RLS Policies for profiles
DROP POLICY IF EXISTS "Users can view their own profile" ON public.profiles;
CREATE POLICY "Users can view their own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can insert their own profile" ON public.profiles;
CREATE POLICY "Users can insert their own profile"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

-- RLS Policies for user_roles
DROP POLICY IF EXISTS "Users can view their own roles" ON public.user_roles;
CREATE POLICY "Users can view their own roles"
  ON public.user_roles FOR SELECT
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins can view all roles" ON public.user_roles;
CREATE POLICY "Admins can view all roles"
  ON public.user_roles FOR SELECT
  USING (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins can manage all roles" ON public.user_roles;
CREATE POLICY "Admins can manage all roles"
  ON public.user_roles FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for funeral_homes
DROP POLICY IF EXISTS "Everyone can view funeral homes" ON public.funeral_homes;
CREATE POLICY "Everyone can view funeral homes"
  ON public.funeral_homes FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Owners can update their own funeral home" ON public.funeral_homes;
CREATE POLICY "Owners can update their own funeral home"
  ON public.funeral_homes FOR UPDATE
  USING (auth.uid() = owner_id);

DROP POLICY IF EXISTS "Admins can manage all funeral homes" ON public.funeral_homes;
CREATE POLICY "Admins can manage all funeral homes"
  ON public.funeral_homes FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for services
DROP POLICY IF EXISTS "Everyone can view services" ON public.services;
CREATE POLICY "Everyone can view services"
  ON public.services FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Owners can manage their funeral home services" ON public.services;
CREATE POLICY "Owners can manage their funeral home services"
  ON public.services FOR ALL
  USING (
    funeral_home_id = public.get_user_funeral_home(auth.uid())
  );

DROP POLICY IF EXISTS "Admins can manage all services" ON public.services;
CREATE POLICY "Admins can manage all services"
  ON public.services FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for packages
DROP POLICY IF EXISTS "Everyone can view packages" ON public.packages;
CREATE POLICY "Everyone can view packages"
  ON public.packages FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Owners can manage their funeral home packages" ON public.packages;
CREATE POLICY "Owners can manage their funeral home packages"
  ON public.packages FOR ALL
  USING (
    funeral_home_id = public.get_user_funeral_home(auth.uid())
  );

DROP POLICY IF EXISTS "Admins can manage all packages" ON public.packages;
CREATE POLICY "Admins can manage all packages"
  ON public.packages FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for package_services
DROP POLICY IF EXISTS "Everyone can view package services" ON public.package_services;
CREATE POLICY "Everyone can view package services"
  ON public.package_services FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Owners can manage their package services" ON public.package_services;
CREATE POLICY "Owners can manage their package services"
  ON public.package_services FOR ALL
  USING (
    package_id IN (
      SELECT id FROM public.packages 
      WHERE funeral_home_id = public.get_user_funeral_home(auth.uid())
    )
  );

DROP POLICY IF EXISTS "Admins can manage all package services" ON public.package_services;
CREATE POLICY "Admins can manage all package services"
  ON public.package_services FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- Create trigger function for updating updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

-- Add triggers for updated_at
DROP TRIGGER IF EXISTS update_profiles_updated_at ON public.profiles;
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS update_funeral_homes_updated_at ON public.funeral_homes;
CREATE TRIGGER update_funeral_homes_updated_at
  BEFORE UPDATE ON public.funeral_homes
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS update_services_updated_at ON public.services;
CREATE TRIGGER update_services_updated_at
  BEFORE UPDATE ON public.services
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS update_packages_updated_at ON public.packages;
CREATE TRIGGER update_packages_updated_at
  BEFORE UPDATE ON public.packages
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Create trigger function to create profile on user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, phone)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'phone', '')
  );
  RETURN NEW;
END;
$$;

-- Trigger for automatic profile creation
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();