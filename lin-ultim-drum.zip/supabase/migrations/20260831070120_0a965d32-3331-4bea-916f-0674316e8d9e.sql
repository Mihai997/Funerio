ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS order_type text NOT NULL DEFAULT 'standard',
  ADD COLUMN IF NOT EXISTS notes text;