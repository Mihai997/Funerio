DROP FUNCTION IF EXISTS public.get_firm_scores();

CREATE FUNCTION public.get_firm_scores()
RETURNS TABLE(funeral_home_id uuid, funeral_home_name text, subscription_active boolean, total_leads bigint, answered_leads bigint, valid_leads bigint, resolved_leads bigint, lost_leads bigint, unprocessed_leads bigint, missed_leads bigint, speed_points numeric)
LANGUAGE sql STABLE SET search_path TO 'public'
AS $$
  SELECT
    f.id, f.name, f.subscription_active,
    COUNT(c.id)::bigint,
    COUNT(c.id) FILTER (WHERE COALESCE(c.call_duration,0) > 0)::bigint,
    COUNT(c.id) FILTER (WHERE COALESCE(c.call_duration,0) >= 40)::bigint,
    COUNT(c.id) FILTER (WHERE c.outcome = 'resolved')::bigint,
    0::bigint,
    COUNT(c.id) FILTER (WHERE COALESCE(c.call_duration,0) >= 40 AND COALESCE(c.outcome,'pending') <> 'resolved')::bigint,
    COUNT(c.id) FILTER (WHERE COALESCE(c.call_duration,0) = 0)::bigint,
    COALESCE(SUM(
      CASE WHEN c.outcome = 'resolved' AND c.resolved_at IS NOT NULL THEN
        GREATEST(0, LEAST(1, 1 - (EXTRACT(EPOCH FROM (c.resolved_at - c.started_at))/86400 - 7) / 23))
      END), 0)::numeric
  FROM public.funeral_homes f
  LEFT JOIN public.call_logs c ON c.funeral_home_id = f.id AND c.started_at >= now() - interval '90 days'
  WHERE public.has_role(auth.uid(), 'admin'::app_role)
  GROUP BY f.id, f.name, f.subscription_active
$$;

CREATE OR REPLACE FUNCTION public.get_firm_priority_scores(_ids uuid[])
RETURNS TABLE(funeral_home_id uuid, total_calls bigint, real_score numeric, final_score numeric)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
  WITH s AS (
    SELECT f.id,
      COUNT(c.id) AS total,
      COUNT(c.id) FILTER (WHERE COALESCE(c.call_duration,0) > 0) AS answered,
      COUNT(c.id) FILTER (WHERE COALESCE(c.call_duration,0) >= 40) AS qualified,
      COUNT(c.id) FILTER (WHERE c.outcome = 'resolved') AS resolved,
      AVG(CASE WHEN c.outcome = 'resolved' AND c.resolved_at IS NOT NULL THEN
        GREATEST(0, LEAST(1, 1 - (EXTRACT(EPOCH FROM (c.resolved_at - c.started_at))/86400 - 7) / 23)) END) AS speed
    FROM public.funeral_homes f
    LEFT JOIN public.call_logs c ON c.funeral_home_id = f.id AND c.started_at >= now() - interval '90 days'
    WHERE f.id = ANY(_ids)
      AND (auth.role() = 'service_role'
           OR public.has_role(auth.uid(), 'admin'::app_role)
           OR f.id = public.get_user_funeral_home(auth.uid()))
    GROUP BY f.id
  ), r AS (
    SELECT id, total,
      ( 50 * CASE WHEN total > 0 THEN answered::numeric/total ELSE 0 END
      + 20 * CASE WHEN answered > 0 THEN qualified::numeric/answered ELSE 0 END
      + 20 * CASE WHEN qualified > 0 THEN LEAST(resolved, qualified)::numeric/qualified ELSE 0 END
      + 10 * COALESCE(speed, 0)) AS real
    FROM s
  )
  SELECT id, total, ROUND(real, 1),
    ROUND((LEAST(total,10)/10.0) * real + (1 - LEAST(total,10)/10.0) * 80, 1)
  FROM r
$$;

REVOKE EXECUTE ON FUNCTION public.get_firm_priority_scores(uuid[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_firm_priority_scores(uuid[]) TO authenticated, service_role;