REVOKE EXECUTE ON FUNCTION public.get_firm_scores() FROM anon, public;
GRANT EXECUTE ON FUNCTION public.get_firm_scores() TO authenticated;