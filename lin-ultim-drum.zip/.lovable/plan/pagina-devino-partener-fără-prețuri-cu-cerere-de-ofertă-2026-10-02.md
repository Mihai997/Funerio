# Pagina „Devino partener” fără prețuri, cu cerere de ofertă

## Ce vede firma care intră pe pagină

1. **Partea de sus**: titlul „Primește clienți noi din zona ta, prin Funerio”, o frază scurtă despre beneficii și butonul „Cere o ofertă personalizată”, care te duce direct la formular.
2. **De ce Funerio**: 6 avantaje, fără prețuri:
   - Apeluri directe de la familii din zona ta
   - Număr de telefon dedicat, iar apelurile sunt înregistrate
   - Profil complet cu servicii și pachete
   - Panou de control cu statistici și rezultate lunare
   - Plătești doar pentru rezultate concrete, cu ofertă adaptată firmei tale
   - Suport la configurarea profilului
3. **Cum funcționează**, în 3 pași: trimiți cererea → te contactăm cu o ofertă personalizată → îți activăm profilul.
4. **Formular scurt** pe aceeași pagină: nume, numele firmei, telefon, email, județ (cu căutare) și un mesaj opțional. Butonul „Trimite cererea”, iar după trimitere apare mesajul: „Mulțumim! Revenim cu o ofertă personalizată în cel mult 24 de ore.”
5. **Întrebări frecvente** (3–4), fără prețuri. De exemplu: „Cât costă?” → „Prețul se stabilește personalizat, în funcție de zonă și volum.”

## Ce dispare
- Pachetele Standard și Premium, prețurile (199/399 RON, 29 RON/lead) și mențiunile despre prețuri din descrierea paginii pentru Google.
- Trimiterea către pagina „Contact” de pe această pagină. Formularul este acum direct pe pagină.

## Trimiterea cererii
- Deocamdată cererea ajunge pe emailul echipei, prin sistemul de email deja existent pentru formularul de contact, marcată ca „Cerere ofertă partener”.
- Trimiterea automată a ofertei pe email către firmă o vom dezvolta ulterior.

## Detalii tehnice
- Rescriere `src/pages/PartnersPage.tsx`: secțiuni noi, formular validat cu zod, trimitere prin `send-contact-email` (cu subiect sau mesaj cu prefix „Cerere ofertă partener”).
- Se șterge `src/components/PartnerPlans.tsx`, pentru că nu mai este folosit.
- Se actualizează titlul și descrierea paginii (SEO), fără prețuri.
- Telefonul și emailul afișate rămân cele de acum (0800 123 456, contact@funerio.ro). Dacă sunt doar exemple, spune-mi datele reale.
