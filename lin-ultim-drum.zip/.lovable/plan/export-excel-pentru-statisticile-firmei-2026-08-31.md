# Export Excel pentru statisticile firmei

Firmele vor putea descărca datele lor din dashboard într-un fișier Excel (.xlsx), respectând perioada selectată în tabul Statistici (Total / Ultimul An / Ultima Lună).

## Ce va conține fișierul

Un singur fișier `.xlsx` cu două foi:

**Foaia „Sumar”**
- Numele firmei, perioada exportată și data generării
- Total apeluri
- Apeluri peste 30 secunde (leads / potențiali clienți)
- Rată conversie apeluri (%)
- Valoare medie și rată finalizare (așa cum sunt afișate pe card-uri)

**Foaia „Apeluri”**
- Data și ora apelului
- Persoană de contact (dacă a fost completată la finalizare)
- Număr telefon apelant
- Durată (secunde + format mm:ss)
- Status apel
- Lead facturabil (Da/Nu, peste 30s)

## Unde apare butonul

- Buton „Exportă Excel” în tabul **Statistici**, lângă filtrele de perioadă (Total / Ultimul An / Ultima Lună).
- Pe mobil butonul se afișează pe rând separat, la lățime completă, ca să rămână ușor de apăsat.
- În timpul generării butonul afișează starea de încărcare, iar la final apare un toast de confirmare.

## Detalii tehnice

- Adăugăm librăria `xlsx` (SheetJS) și un helper `src/lib/exportStats.ts` care primește datele deja încărcate în pagină și scrie fișierul.
- Numele fișierului: `funerio-statistici-<nume-firma-slug>-<perioada>-<data>.xlsx`.
- Exportul folosește apelurile firmei din perioada selectată. Deoarece în prezent `call_logs` se încarcă cu `limit(100)`, la export facem o interogare dedicată, filtrată pe `funeral_home_id` și intervalul perioadei, fără limita de 100, ca fișierul să conțină toate apelurile.
- Formatare: antet îngroșat, lățimi de coloană setate, durate și procente formatate ca text lizibil; datele în format `dd.MM.yyyy HH:mm` (ro-RO).
- Fără modificări de schemă în baza de date și fără politici noi — se folosesc politicile existente de acces ale firmei la propriile apeluri.
