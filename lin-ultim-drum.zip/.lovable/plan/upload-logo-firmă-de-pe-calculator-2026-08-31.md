# Upload logo firmă de pe calculator

Firmele vor putea încărca logo-ul direct de pe calculator sau telefon, în locul lipirii unui URL. Imaginea este redimensionată automat înainte de salvare, ca să rămână de calitate bună fără să încetinească site-ul.

## Experiența utilizatorului

În pagina Setări firmă, câmpul „URL Logo” devine o zonă de upload:
- Previzualizare rotundă a logo-ului curent (sau emblema Funerio dacă nu există logo).
- Buton „Încarcă imagine” care deschide selectorul de fișiere (pe mobil permite și camera).
- Buton „Șterge” pentru eliminarea logo-ului.
- Indicator de încărcare pe durata procesării și mesaje clare de eroare (tip fișier greșit, fișier prea mare).
- Acceptăm JPG, PNG, WebP; maximum 10 MB la selectare.

Logo-urile existente adăugate prin URL rămân valabile și sunt afișate în previzualizare.

## Optimizarea imaginii

Înainte de upload, imaginea este redimensionată în browser:
- Latura maximă 800px (păstrând proporțiile), fără mărirea imaginilor mai mici.
- Conversie în WebP, calitate 0.85 (fallback JPEG dacă browserul nu suportă WebP).
- Rezultatul tipic: sub 150 KB, fără pierdere vizibilă de calitate.

## Detalii tehnice

- Creăm un bucket public de storage `firm-logos`, cu limită de dimensiune fișier.
- Politici pe `storage.objects`: citire publică pentru acest bucket; upload/actualizare/ștergere permise utilizatorilor autentificați doar în folderul propriu (`<funeral_home_id>/...`), pe baza funcției existente `get_user_funeral_home`, plus acces complet pentru administratori prin `has_role`.
- Componentă nouă `src/components/LogoUploader.tsx` (previzualizare + upload + ștergere) și helper `src/lib/imageResize.ts` care face redimensionarea pe canvas.
- Fișierul se încarcă la calea `<funeral_home_id>/logo-<timestamp>.webp`; salvăm URL-ul public în `funeral_homes.logo`. La înlocuire, fișierul vechi din bucket este șters dacă aparține bucket-ului.
- Integrare în `src/pages/SettingsPage.tsx`; nu se modifică schema tabelului `funeral_homes` (folosim tot coloana `logo`).
