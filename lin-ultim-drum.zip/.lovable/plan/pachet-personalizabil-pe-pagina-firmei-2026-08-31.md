# Pachet personalizabil pe pagina firmei

Clientul își compune singur un pachet din serviciile firmei, direct în tab-ul „Pachete” de pe pagina publică a firmei, și trimite o cerere de ofertă. Nu se afișează un total în lei — doar lista serviciilor alese, prețul final rămâne de discutat cu firma.

## Ce vede utilizatorul

1. În tab-ul **Pachete** de pe `/firme/:id`, deasupra pachetelor predefinite, apare un card distinct: **„Pachet personalizat — alege exact serviciile de care ai nevoie”**, cu buton „Creează pachetul tău”.
2. La deschidere (dialog pe desktop, ecran full-height pe mobil) serviciile firmei sunt grupate pe categorii, fiecare cu checkbox, nume și descriere scurtă. Prețurile individuale rămân vizibile ca reper, dar nu se însumează.
3. O bară fixă jos arată „X servicii selectate” + buton **„Cere ofertă”** (dezactivat până la minim un serviciu).
4. Pasul 2 din același dialog: nume, telefon, email (opțional) și un câmp liber „Detalii suplimentare”, plus acceptarea Termenilor.
5. La trimitere: mesaj de confirmare, dialogul se închide, firma primește cererea.

## Ce se întâmplă în spate

- Cererea se salvează ca lead pentru firmă, astfel încât să apară în dashboard-ul firmei alături de celelalte solicitări.
- Firma primește un email cu datele clientului și lista serviciilor cerute (fără total).
- Nu se atinge fluxul de checkout existent și nu se modifică pachetele predefinite.

## Detalii tehnice

**Frontend**
- `src/pages/FuneralHomeDetailPage.tsx`: card nou „Pachet personalizat” în `TabsContent value="packages"`, înainte de lista de pachete.
- Componentă nouă `src/components/CustomPackageDialog.tsx`: primește `funeralHome`, gestionează selecția serviciilor (grupate cu `serviceCategories`), pasul de date de contact, validările (nume min. 2 caractere, telefon RO `^(\+4|0)[0-9]{9}$`), și trimiterea.
- Stil conform sistemului existent: `rounded-full` pentru butoane/inputuri, target-uri mari pe mobil, conținut scrollabil cu footer sticky, fără culori hardcodate.
- Fără afișare de total: doar contorul de servicii selectate și, opțional, textul „Prețul final îți va fi comunicat de firmă”.

**Backend**
- Migrație: coloană `order_type text not null default 'standard'` pe `public.orders` (valori `standard` / `custom`) și `notes text` pentru detaliile suplimentare; `total_price` se salvează `0` pentru cererile de tip `custom`, deoarece nu se estimează preț.
- Inserarea comenzii + `order_items` (nume serviciu, preț de referință) se face prin edge function nouă `submit-custom-package` (fără verificare JWT, flux public, service role pentru insert), care apoi trimite emailul către firmă prin Resend (`onboarding@resend.dev`), reutilizând stilul din `send-checkout-email`.
- Validare input cu zod în edge function; escape HTML pentru email.

**Dashboard firmă**
- În tab-ul „Apeluri”/comenzi existent, cererile de tip `custom` se afișează cu un badge „Pachet personalizat” și lista serviciilor din `order_items`; unde se afișează prețul, pentru `custom` se arată „La cerere” în loc de 0 RON.

## Verificare

- Compunere pachet și trimitere cerere pe mobil (375×812) și desktop.
- Cererea apare în dashboard-ul firmei cu badge-ul corect și serviciile alese.
- Nicio regresie pe pachetele predefinite și pe checkout-ul existent.
