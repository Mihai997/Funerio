# Contact + Parteneri: separare pagini și eliminare selector localitate

## Ce se schimbă

1. **Eliminăm complet selecția de oraș** din secțiunea de pachete (combobox „Selectează orașul", badge-ul „Ofertă disponibilă pentru...", și titlul dinamic din tabelul comparativ devine fix: „Beneficii incluse").

2. **Separăm conținutul în două pagini** în loc de o singură pagină foarte lungă:

   - `/parteneri` — pagina comercială: hero („Înscrie-ți firma pe Funerio"), cele două pachete (Standard / Premium), tabelul comparativ, grila „De ce să alegi Funerio?", și un CTA mare la final → „Trimite cererea de înscriere" care duce la formular.
   - `/contact` — pagina scurtă: formularul de înscriere + datele de contact (telefon, email, sediu) + cardul „Proces rapid de activare", așezate una lângă alta pe desktop (formular stânga, contact dreapta) și una sub alta pe mobil.

3. **Datele de contact urcă sus**: pe `/contact` nu mai există nimic înaintea lor, deci sunt vizibile imediat. În plus, pe `/parteneri` adăugăm o bandă compactă cu telefon + email imediat sub hero, ca utilizatorul să aibă contactul la îndemână fără scroll.

4. **Navigație**: linkul existent către contact rămâne, iar din meniu/footer se adaugă „Parteneri". Vechiul `/contact` cu pachete redirecționează logic: pachetele se mută pe `/parteneri`, iar `/contact` rămâne pentru formular + contact.

## Detalii tehnice

- `src/components/PartnerPlans.tsx`: se scot `useState`/`Popover`/`Command`/`romanianLocalities` și tot ce ține de `city`; componenta devine pur prezentațională.
- Pagină nouă `src/pages/PartnersPage.tsx` (rută `/parteneri` în `src/App.tsx`) cu `Seo` propriu (title/description orientate pe „Devino partener Funerio"), `PartnerPlans`, grila de beneficii mutată din `ContactPage`, bandă de contact rapid și CTA către `/contact`.
- `src/pages/ContactPage.tsx`: rămâne doar formularul (logica de submit și validarea zod neschimbate), cardurile de contact și cardul de activare; `Seo` actualizat.
- Fără modificări de backend sau de business logic.
