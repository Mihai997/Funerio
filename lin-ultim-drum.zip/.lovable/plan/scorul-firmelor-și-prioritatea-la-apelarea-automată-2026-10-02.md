# Scorul firmelor și prioritatea la apelarea automată

## Principiile scorului (0–100)

Scorul folosește doar apelurile din ultimele 90 de zile, ca o firmă să-și poată reface scorul.

| Criteriu | Pondere | Ce măsoară |
|---|---|---|
| Rata de răspuns | 50% | Câte apeluri primite au fost preluate |
| Calitatea convorbirii | 20% | Câte apeluri preluate au durat cel puțin 40 de secunde (lead calificat) |
| Finalizare | 20% | Câte lead-uri calificate au fost marcate „Finalizat” |
| Rapiditate | 10% | Cât de repede marchează firma rezultatul unui lead (în maxim 7 zile = punctaj întreg) |

Apelurile nepreluate scad scorul cel mai mult, pentru că un client îndoliat care nu primește răspuns este cel mai grav caz.

## Firme noi

- O firmă începe cu un scor de pornire de 80, ca să fie sunată des de la început.
- Pe parcursul primelor 10 apeluri, scorul trece treptat de la 80 la scorul real: după 5 apeluri contează pe jumătate scorul de pornire și pe jumătate cel real, iar după 10 apeluri contează doar scorul real.
- Așa, o firmă nouă care nu răspunde coboară repede, iar una bună rămâne sus.

## Cum se folosește la „Contactează acum o firmă”

- Ordinea rămâne aleatorie, dar cu șanse mai mari pentru firmele cu scor mare: o firmă cu scorul 90 are de aproximativ 3 ori mai multe șanse să fie sunată prima decât una cu scorul 30.
- Orice firmă cu abonament activ are o șansă minimă, ca să nu rămână niciodată fără apeluri.
- Rămân la fel: oprire la prima firmă care răspunde și maximum 10 firme sunate într-un apel.

## Unde se vede scorul

- În administrare, coloana „Scor” existentă folosește aceeași formulă, iar firmele noi au eticheta „Nouă (x/10 apeluri)”.
- Firma își vede scorul în tabul „Rezultate”, cu explicații scurte despre cum îl poate crește (de exemplu: „Răspunde la mai multe apeluri”).

## Detalii tehnice

- O singură sursă de adevăr: o funcție în baza de date, `get_firm_priority_scores(ids uuid[])`, calculează pe `call_logs` din ultimele 90 de zile: răspuns (`call_duration > 0`), calificat (`>= 40`), finalizat (`outcome='resolved'`) și rapiditate (`resolved_at - started_at`). Poate fi apelată doar de admin sau de serverul aplicației.
- Formula de amestec: `final = (n/10)*real + (1 - n/10)*80`, unde `n = min(apeluri din ultimele 90 de zile, 10)`.
- Ponderea la extragere este `max(5, final)^1.0`, cu extragere fără înlocuire (ca acum).
- `initiate-sequential-call` înlocuiește ponderea actuală `1 + 0.5*valid + 2*resolved` cu apelul la această funcție; funcția se redeploy-ează.
- `get_firm_scores` și `src/lib/firmScore.ts` se aliniază la aceleași reguli (90 de zile, amestec pentru firmele noi, criteriul de rapiditate).
- Tabul „Rezultate” din `RoiDashboard.tsx` primește un card cu scorul firmei.
- Regula se notează în `AGENTS.md`.
