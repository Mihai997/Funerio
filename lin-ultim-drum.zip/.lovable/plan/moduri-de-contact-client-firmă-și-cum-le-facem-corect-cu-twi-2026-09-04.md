# Moduri de contact client → firmă și cum le facem corect cu Twilio

## Situația actuală: 5 moduri de contact

| # | Mod | Unde | Twilio? | Se creează lead (`call_logs`)? |
|---|-----|------|---------|-------------------------------|
| 1 | Apel direct `tel:` | Card firmă + pagina firmei | Nu | **Nu** — lead invizibil |
| 2 | „Contactează acum o firmă" (apel secvențial) | Wizard pagina principală | Da (`initiate-sequential-call`) | Da, dar fără înregistrare |
| 3 | Apel primit pe numărul de tracking | Twilio → `twilio-webhook` | Da | Da, cu înregistrare |
| 4 | Cerere de ofertă | Wizard + pagina „Cere ofertă" | Nu | **Nu** — doar comandă + email |
| 5 | Pachet personalizat | Pagina firmei | Nu | **Nu** — doar comandă + email |
| 6 | Callback firmă → client | Dashboard firmă | Da (`firm-callback`) | Actualizează lead-ul existent |

## Probleme critice găsite (în ordinea gravității)

1. **Doar 1 firmă din 103 are număr de tracking configurat.** Modurile 2, 3 și 6 funcționează efectiv doar pentru „Casa Funebră Demo". Restul firmelor nu apar deloc în apelul secvențial și nu pot folosi callback-ul.
2. **Webhook-urile Twilio nu verifică semnătura.** Oricine poate trimite cereri false către `twilio-webhook` și `initiate-sequential-call` ca să fabrice apeluri „răspunse", să strice statisticile de facturare sau să declanșeze apeluri reale către orice număr — pe costul contului Twilio.
3. **Apelul secvențial trimite numărul clientului în URL, necriptat**, iar funcția nu are nicio limitare — poate fi folosită pentru apeluri abuzive.
4. **Numerele de tracking și numerele reale ale firmelor sunt vizibile public** în browser (pagina firmei citește toate coloanele). Asta anulează scopul numărului de tracking.
5. **Apelurile secvențiale nu se înregistrează** (lipsește `record` în TwiML) și folosesc identificatori inventați de apel, deci nu pot fi corelate cu Twilio.
6. **Numărul de tracking salvat în lead nu e cel folosit real de Twilio** la apelul secvențial (se folosește mereu numărul primei firme).
7. **Apelul direct `tel:` nu generează lead** — firma primește client fără ca platforma să știe, deci nu se facturează.
8. **Cererile de ofertă și pachetele personalizate nu sunt lead-uri** în rapoarte — trăiesc doar ca „comenzi" + email.
9. **Două implementări paralele pentru cererea de ofertă** (una server-side, una direct din browser), cu validări diferite și risc de salvări parțiale.

## Ce propun să facem

### Etapa 1 — siguranță și corectitudine Twilio (obligatoriu)
- Validare semnătură `X-Twilio-Signature` în toate funcțiile apelate de Twilio (`twilio-webhook`, `initiate-sequential-call`, `firm-callback`), folosind auth token-ul existent.
- Semnare/expirare a parametrilor din URL-urile de TwiML, astfel încât numărul clientului să nu mai circule în clar și link-urile să nu poată fi reluate.
- Limitare de rată pe `initiate-sequential-call` (per număr de telefon și per IP) + validare strictă E.164 într-un singur helper comun folosit de toate funcțiile.
- Blocarea coloanelor `phone` / `tracking_phone` din citirile publice: pagina firmei primește doar numărul de afișat, restul rămâne în backend.

### Etapa 2 — toate apelurile prin Twilio, toate înregistrate
- Fiecare firmă activă primește obligatoriu un număr de tracking; în administrare apare avertisment vizibil și filtru pentru firmele fără număr.
- Toate butoanele de apel (card firmă, pagina firmei, pagini de landing) folosesc **exclusiv** numărul de tracking — nicăieri nu se mai afișează numărul real al firmei. Orice apel direct trece prin Twilio și devine lead cu durată + înregistrare.
- Dacă firma nu are număr de tracking, butonul de apel nu se afișează (rămâne cererea de ofertă), ca să nu existe apeluri netrasate.
- Înregistrare activată pe toate cele trei trasee de apel (apel direct pe tracking, apel secvențial, callback firmă), cu același `recordingStatusCallback` și redare din dashboard prin proxy-ul existent.
- Apelul secvențial și callback-ul: salvăm identificatorul real Twilio al fiecărei etape și numărul de tracking corect al firmei apelate, ca înregistrarea să se lege de lead-ul potrivit.
- Notă legală: se adaugă un anunț scurt de înregistrare la începutul apelului (obligatoriu GDPR pentru înregistrarea convorbirilor).


### Etapa 3 — lead-uri unificate (raportare)
- Cererile de ofertă și pachetele personalizate devin lead-uri vizibile în dashboard, marcate ca „formular" (distincte de apeluri), cu status propriu.
- Aceste lead-uri **nu se facturează** — se facturează doar apelurile calificate (≥40s). Apar doar în rapoarte și statistici.
- O singură implementare pentru cererea de ofertă (funcția server-side), eliminând varianta duplicată din browser.

## Decizii confirmate
- Un număr Twilio de tracking per firmă (cost lunar per număr, suportat de platformă).
- Mesaj audio scurt de anunț al înregistrării la începutul fiecărui apel, în română.
- Lead-urile din formular: doar raportare, fără facturare.
- Numărul real al firmei nu se mai afișează public nicăieri — doar numărul de tracking; fără fallback la numărul real.

## Cum arată situația după schimbări

| Mod de contact | Trece prin Twilio | Înregistrat | Lead | Facturat |
|---|---|---|---|---|
| Apel din card / pagina firmei | Da (tracking) | Da | Da | Da, dacă ≥40s |
| „Contactează acum o firmă" (secvențial) | Da | Da | Da, per firmă apelată | Da, dacă ≥40s |
| Callback firmă → client | Da | Da | Actualizează lead-ul | Da, dacă ≥40s |
| Cerere de ofertă | Nu (formular) | — | Da, tip „formular" | Nu |
| Pachet personalizat | Nu (formular) | — | Da, tip „formular" | Nu |

- Numărul real al firmei nu mai apare în browser; numărul clientului rămâne mascat pentru firme.
- Fiecare apel are: durată reală, status (Nepreluat / Apel scurt / Lead calificat / Finalizat) și înregistrare ascultabilă din dashboard.
- Facturarea devine verificabilă: fiecare lead calificat are apel Twilio + înregistrare ca dovadă.
- Firmele fără număr de tracking alocat nu afișează buton de apel până la alocare.

## Detalii tehnice


- Helper nou partajat în `supabase/functions/_shared/`: `twilioSignature.ts` (validare HMAC-SHA1 conform Twilio), `phone.ts` (E.164 unic), `signedParams.ts` (token semnat cu expirare pentru URL-urile de TwiML).
- `twilio-webhook`: validare semnătură, refuz 403 la semnătură invalidă, validare E.164 înainte de `<Dial>`.
- `initiate-sequential-call`: parametrii de pas se mută într-un token semnat; se adaugă `record="record-from-answer-dual"` + `recordingStatusCallback`; `call_sid` real din `DialCallSid`; `tracking_phone` per firmă corect.
- Expunerea numerelor: view public / politici pe coloane pentru `funeral_homes`, iar frontend-ul nu mai face `select('*')`.
- Lead-uri din formular: câmp nou `lead_source` (`call` / `quote` / `custom_package`) pe sursa unificată de lead-uri, cu migrare a datelor existente.

## Riscuri și limitări
- Numerele de tracking trebuie cumpărate în Twilio pentru fiecare firmă (cost lunar per număr) — fără ele, urmărirea apelurilor nu poate funcționa.
- Trebuie verificat în contul Twilio: webhook-ul de Voice pe fiecare număr, permisiunile geografice pentru România și protecția anti-fraudă.
- Etapa 3 schimbă modul de calcul al lead-urilor, deci și rapoartele financiare — o facem doar după ce validăm regulile de facturare pentru lead-urile din formular.
