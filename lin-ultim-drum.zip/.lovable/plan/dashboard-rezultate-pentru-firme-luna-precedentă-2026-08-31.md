# Dashboard „Rezultate" pentru firme (luna precedentă)

Tab nou în dashboard-ul firmei care arată clar ce a adus Funerio firmei în luna trecută și cât a crescut față de luna anterioară. Fără costuri sau prețuri de abonament — doar volum de lead-uri, clienți câștigați și încasări.

## Ce vede firma

**Antet**: „Rezultatele tale în [Luna Anul]" + perioada exactă (01–31).

**4 carduri principale**, fiecare cu valoarea lunii precedente și o săgeată de creștere/scădere față de luna dinaintea ei:

- **Apeluri primite** — toate apelurile direcționate prin Funerio.
- **Lead-uri calificate** — apeluri conectate peste 30 de secunde.
- **Clienți câștigați** — apeluri marcate ca soluționate la finalizare.
- **Încasări generate** — suma prețurilor completate la finalizarea apelurilor.

**Card de rezumat „Impactul Funerio"**, cu limbaj simplu:

```text
În [Luna] ai primit 24 de apeluri prin Funerio,
din care 18 lead-uri reale și 7 clienți câștigați.
Valoare totală a comenzilor: 21.400 RON.
Valoare medie per client: 3.057 RON.
Rată de transformare lead → client: 39%.
```

Plus creșterile față de luna anterioară, afișate verde/roșu (ex. „+35% lead-uri, +2 clienți, +18% încasări").

**Indicatori secundari** (rând compact):
- Rată de preluare a apelurilor (preluate / primite).
- Timp mediu de convorbire.
- Lead-uri nefinalizate (apeluri >30s pe care firma nu le-a marcat) — mesaj de tip „ai X lead-uri neprocesate, valoarea lor poate fi recuperată".
- Ziua/intervalul orar cu cele mai multe apeluri.

**Notă explicativă** când firma nu a completat prețuri: „Completează prețul la finalizarea apelurilor ca să vezi încasările reale generate."

## Comportament

- Perioada implicită este luna precedentă completă; un selector simplu permite și „Luna curentă".
- Dacă nu există date în luna precedentă, se afișează un mesaj prietenos cu îndrumare, nu carduri goale.
- Layout responsive: 2 coloane pe mobil pentru carduri, 4 pe desktop; textele mari rămân lizibile.

## Detalii tehnice

- Tab nou „Rezultate" în `src/pages/DashboardPage.tsx` (lângă Statistici / Apeluri / Servicii / Financiar).
- Componentă nouă `src/components/dashboard/RoiDashboard.tsx`, primește `funeralHomeId`.
- O singură interogare pe `call_logs` pentru intervalul ultimelor două luni (`started_at`, `call_duration`, `outcome`, `outcome_amount`), agregarea se face în client.
- Definiții: lead calificat = `call_duration > 30`; client câștigat = `outcome = 'resolved'`; încasări = suma `outcome_amount` pe apelurile soluționate din perioadă.
- Creștere = (luna precedentă − luna dinaintea ei) / luna dinaintea ei; când baza este 0 se afișează „nou" în loc de procent.
- Reutilizează cardurile shadcn existente și iconițele lucide; fără dependențe noi.
