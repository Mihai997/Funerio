# Plan: apelarea firmelor prin Twilio (manual + secvențial)

## Ce există deja (verificat în cod)

- **Apel manual (tel:)**: butonul de apel de pe card/pagina firmei sună numărul de tracking al firmei. Twilio preia apelul, redă anunțul de înregistrare în română, redirecționează către numărul real al firmei și înregistrează convorbirea. Lead-ul se salvează automat în `call_logs`, cu durată, status și link-ul înregistrării.
- **Secvențial („Contactează acum o firmă")**: funcția `initiate-sequential-call` sună clientul, îl conectează pe rând cu firmele din localitate (fallback pe județ), se oprește la prima firmă care răspunde, salvate per firmă, cu înregistrare și tokenuri semnate.
- **Securitate**: validare semnătură Twilio, parametri semnați, limitare de rată — deja implementate.

## Schimbări de făcut

### 1. Apel manual — completări
- **Acoperire numere de tracking**: în administrare, secțiune „Firme fără număr de tracking" cu listă + stare vizibilă; butonul de apel rămâne ascuns pentru firmele fără număr (nu se poate urmări/factura apelul). Numerele se cumpără în contul Twilio — platforma doar le alocă pe firmă.
- **Verificare capăt-la-capăt a fluxului tel:**: anunț înregistrare → redirecționare → înregistrare salvată pe lead → status final (Nepreluat / Apel scurt / Lead calificat) → facturare ≥ 40s (regulile existente rămân).
- **Test cu un apel real** către numărul de tracking al firmei demo: confirmăm lead, durată și înregistrare în dashboard.

### 2. Secvențial — ordine aleatorie ponderată
- Firmele participante rămân cele cu abonament activ și număr de tracking din localitate (fallback județ).
- Ordinea de sunare devine **aleatorie ponderată**: toate firmele pot fi primele, dar ponderea crește cu scorul de răspuns al firmei (leads preluate, apeluri calificate — scorul existent din `firmScore`). Firmele noi, fără istoric, primesc pondere de bază.
- Oprirea rămâne la prima firmă care răspunde, indiferent de durata apelului.
- Limită de siguranță: maximum 10 firme sunate într-un apel secvențial.

### 3. Verificări după implementare
- Rulare `tsgo --noEmit`, test secvențial pe Dolj/Craiova în preview, verificare `call_logs` (două lead-uri doar dacă două firme au fost sunate efectiv).

## Întrebări deschise (decise deja în chat)
- Apelul manual rămâne `tel:` pe tracking — nu click-to-call. ✔
- Facturare identică (≥ 40s) pentru ambele trasee. ✔
- Ordine: aleatoriu ponderat; oprire la primul răspuns. ✔
