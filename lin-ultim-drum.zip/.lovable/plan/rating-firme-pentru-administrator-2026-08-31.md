# Rating firme pentru administrator

Scor de performanță pentru fiecare firmă, calculat pe tot istoricul de apeluri, vizibil doar în zona de administrare.

## 1. Persistăm rezultatul apelurilor

Momentan finalizarea unui apel din dashboard-ul firmei se ține doar în memoria browserului și se pierde la refresh, deci nu poate sta la baza unui scor. Adăugăm salvarea în baza de date:

- Câmpuri noi pe apel: rezultat (`soluționat` / `pierdut` / `în așteptare`), persoana de contact, notițe, data finalizării, cine a finalizat.
- Dialogul „Finalizare apel" din dashboard-ul firmei salvează aceste date; lista de apeluri și tab-ul „Apeluri" le citesc din baza de date (nu se mai pierd la refresh).

## 2. Criteriile scorului (pe total istoric)

Pentru fiecare firmă:

- **Lead-uri primite** — apeluri direcționate către firmă (toate).
- **Lead-uri valide** — apeluri conectate cu durată peste 30s (cele facturabile).
- **Lead-uri soluționate** — apeluri marcate „soluționat" de firmă.
- **Lead-uri nepreluate (neconectate)** — apeluri care nu au fost răspunse (durată 0, status `initiated` / `no-answer` / `busy` / `failed`).
- **Lead-uri fără răspuns administrativ** — apeluri conectate >30s pe care firma nu le-a finalizat deloc.

## 3. Formula de scoring

Scor 0–100, format din trei componente:

```text
Rata de preluare   = lead-uri conectate / lead-uri primite        -> 50 puncte
Rata de soluționare= lead-uri soluționate / lead-uri conectate>30s -> 35 puncte
Rata de procesare  = lead-uri finalizate (orice rezultat) / lead-uri conectate>30s -> 15 puncte

Scor = 50*preluare + 35*soluționare + 15*procesare
```

Firmele cu mai puțin de 5 lead-uri primesc eticheta „date insuficiente" (scor afișat gri, fără clasare).

Praguri de calificare:

| Scor | Etichetă | Culoare |
|---|---|---|
| 85–100 | Excelent | verde |
| 70–84 | Bun | verde deschis |
| 50–69 | Mediu | galben |
| < 50 | Slab | roșu |

Echivalent în stele (1–5) pentru afișarea compactă.

## 4. Unde apare

**Lista „Firme" (admin)** — coloană nouă „Scor" cu badge colorat + stele pe desktop, badge în card pe mobil; sortare după scor și tooltip cu detaliul criteriilor.

**Admin Dashboard — secțiune „Rating firme"** — clasament cu: poziție, firmă, scor, lead-uri primite, preluate, soluționate, nepreluate, rata de preluare și rata de soluționare; sortare pe orice coloană, căutare după nume, evidențiere top 3 și firme sub 50 de puncte.

## Detalii tehnice

- Migrație: coloane noi pe `call_logs` (`outcome`, `contact_person`, `outcome_notes`, `resolved_at`, `resolved_by`), index pe `funeral_home_id`; politici de scriere pentru firma proprietară + admin.
- `src/lib/firmScore.ts` — funcție pură care primește agregările și întoarce scor, componente și etichetă (folosită de ambele ecrane, plus teste ușor de adăugat).
- Agregare printr-o funcție de bază de date `get_firm_scores()` (security definer, doar pentru admini) care returnează într-un singur apel numărătorile per firmă — evită încărcarea tuturor apelurilor în client.
- `src/components/admin/FirmScoreTable.tsx` — noua secțiune din Admin Dashboard; badge reutilizabil `FirmScoreBadge` folosit și în lista de firme.
- `FinalizeCallDialog.tsx` + `DashboardPage.tsx` trec de la starea locală la scriere/citire din baza de date.
