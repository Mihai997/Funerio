# Plan: Pictogramă tab browser (favicon) pentru Funerio

## Situația actuală
- `public/favicon.png` (64×64, porumbelul alb Funerio) există deja și este legat în `index.html`.
- Problema: browserul cachează faviconul vechi, iar `<link>`-ul nu forțează reîmprospătarea; lipsesc și variantele pentru touch/scurtături.

## Modificări
1. **`index.html`**
   - Actualizează linkul favicon cu parametru de versionare pentru cache-busting:
     `<link rel="icon" type="image/png" href="/favicon.png?v=2" />`
   - Adaugă `apple-touch-icon` (180×180) pentru iOS / Scurtături ecran start.
   - Adaugă web app manifest inline-uri necesare (theme-color) pentru consistent tab/pinned look.
2. **`public/`**
   - Generează `public/apple-touch-icon.png` (180×180) din același logo sursă (`src/assets/funerio-dove.png`).
   - Păstrează `favicon.png` ca sursă principală.
3. **Verificare**
   - Confirm că `/favicon.png` răspunde 200 și conține logo-ul corect.
   - Typecheck + verificare preview (hard refresh) pentru iconița din tab.

## Note
- Dacă tab-ul pare vechi după deploy, e cache de browser — hard refresh (Ctrl+Shift+R) rezolvă; versiunea `?v=2` previne reapariția problemei.
