# Apel de revenire (callback) prin Twilio pentru lead-uri „Nepreluat”

Firma poate suna clientul direct din aplicație, fără să vadă numărul complet. Apelul pleacă prin Twilio: sună mai întâi telefonul firmei, iar la răspuns se conectează automat clientul, cu numărul de tracking al firmei ca identificator afișat.

## Cum funcționează pentru firmă

1. În lista de apeluri, lead-urile cu status **Nepreluat** primesc un buton „Sună clientul”.
2. Numărul clientului este afișat mascat (ex. `07xx xxx 123`) în dashboard și în lista de apeluri.
3. La apăsare apare o confirmare: „Vei fi sunat pe numărul firmei, apoi te conectăm cu clientul.”
4. Twilio sună numărul firmei; după preluare, se anunță în limba română și se conectează clientul.
5. Când apelul se termină, lead-ul existent se actualizează automat: durata reală și statusul recalculat (Apel scurt sub 40s, Lead calificat de la 40s în sus). Dacă nici clientul nu răspunde, lead-ul rămâne Nepreluat.

## Detalii tehnice

**Edge function nouă: `firm-callback`** (`verify_jwt = false`, validare JWT în cod)
- POST `{ callLogId }`, validat cu Zod.
- Verifică sesiunea utilizatorului și că `funeral_home_id` al lead-ului corespunde firmei sale (`get_user_funeral_home`) sau că e admin.
- Refuză dacă statusul derivat al lead-ului nu este „Nepreluat” (durată 0 și outcome ≠ resolved).
- Citește `caller_phone` cu service role (nu ajunge niciodată în browser), plus `phone` și `tracking_phone` ale firmei.
- Creează apelul Twilio (`/Calls.json`) prin gateway/REST: `To` = telefonul firmei, `From` = tracking phone, `Url` = TwiML din aceeași funcție, `StatusCallback` pentru finalizare.
- Răspunde doar cu `{ ok: true }` — fără numere de telefon.

**TwiML + status callback** (aceeași funcție, pe query params)
- `?twiml=1&log=<id>`: `<Say language="ro-RO">` scurt + `<Dial callerId=tracking timeout=30 action=...>` către client.
- `?status=1&log=<id>`: primește `DialCallStatus` și `DialCallDuration`, actualizează `call_logs` pentru lead-ul original: `call_duration`, `call_status`, `ended_at`. Statusul de business se derivă deja din durată prin `src/lib/leadStatus.ts`, deci nu e nevoie de câmpuri noi.

**Frontend**
- `src/lib/phoneMask.ts` (nou): `maskPhone()` — păstrează prefixul și ultimele 3 cifre.
- `src/pages/DashboardPage.tsx` și `src/components/CallLogsTable.tsx`: afișează numărul mascat pentru firme (adminul vede în continuare numărul complet în tabelul admin) și adaugă butonul „Sună clientul” pe lead-urile Nepreluat, cu stare de încărcare și toast de confirmare/eroare.
- `src/lib/exportStats.ts`: exportă numărul mascat pentru firme.
- După apel, lista se reîmprospătează (refetch la interval scurt sau buton de reîncărcare) ca statusul actualizat să fie vizibil.

**Config**: adaug `[functions.firm-callback] verify_jwt = false` în `supabase/config.toml`. Se folosesc secretele Twilio existente (`TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`). Nu sunt necesare modificări de schemă în baza de date.

## Limitări

- Funcționează doar pentru firmele care au `tracking_phone` configurat; altfel butonul e dezactivat cu explicație.
- Costul apelului este suportat de contul Twilio al platformei, ca la fluxul secvențial existent.
