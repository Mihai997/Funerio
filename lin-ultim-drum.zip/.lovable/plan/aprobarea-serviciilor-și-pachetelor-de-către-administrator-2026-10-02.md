# Aprobarea serviciilor și pachetelor de către administrator

## Ce se schimbă pentru utilizatori

**Firmă (Servicii & Pachete)**
- Orice serviciu sau pachet nou apare cu eticheta galbenă „În așteptare”.
- Dacă îl modifici (preț, nume, descriere, servicii incluse), revine la „În așteptare” și dispare de pe site până la noua aprobare.
- Aprobat: eticheta verde „Aprobat”.
- Refuzat: eticheta roșie „Refuzat”, cu motivul scris de administrator dedesubt. După corectare, se trimite automat din nou la verificare.
- Un mesaj scurt deasupra listei explică faptul că modificările sunt verificate înainte de publicare.

**Administrator – tab nou „De aprobat”**
- Listă cu servicii și pachete în așteptare: firma, nume, categorie, preț, descriere, data trimiterii (la pachete și serviciile incluse).
- Filtru după tip (Servicii / Pachete) și după firmă, plus căutare.
- Buton „Aprobă” și buton „Refuză” care deschide o fereastră în care motivul este obligatoriu.
- Un număr pe tab arată câte elemente așteaptă verificarea.
- Pe telefon: carduri compacte; pe calculator: tabel.

**Vizitatori**
- Pe paginile firmelor, în prețurile „de la X RON”, în coș și la pachetul personalizat apar doar serviciile și pachetele aprobate.

## Reguli stabilite
- Pachetele trec și ele prin aprobare.
- Orice modificare a unui element aprobat îl trimite din nou la verificare.
- Tot ce există acum pe site devine automat „Aprobat”, nimic nu dispare.
- Ce adaugă administratorul este aprobat direct.

## Detalii tehnice
- Migrare: coloane pe `services` și `packages`: `approval_status` (`pending`/`approved`/`rejected`, implicit `pending`), `rejection_reason`, `reviewed_at`, `reviewed_by`. Rândurile existente se setează pe `approved`.
- Trigger `BEFORE INSERT/UPDATE`: dacă utilizatorul nu e admin, forțează `approval_status='pending'`, golește motivul/recenzia (firmele nu se pot auto-aproba). Modificările în `package_services` resetează pachetul părinte la `pending`.
- RLS: politicile publice de citire devin `approval_status='approved'`; proprietarii își văd toate rândurile; adminii văd tot. `package_services` public doar pentru pachete aprobate.
- Frontend: filtrare pe `approved` în `useFuneralHomes.ts`, `FuneralHomesPage.tsx`, `FuneralHomeDetailPage.tsx`, `CheckoutPage.tsx`; edge function `submit-custom-package` validează doar servicii aprobate.
- Badge-uri și motiv în `ManageServicesPage.tsx` / `ManageServicesEmbed.tsx`.
- Tab nou în `AdminDashboardPage.tsx` cu componentă de revizuire (aprobă/refuză cu motiv obligatoriu).
- Opțional ulterior: email către firmă la aprobare/refuz (Resend).
