# Statusuri clare pentru lead-uri

Un singur set de statusuri pentru fiecare lead (apel), afișat identic în dashboard-ul firmei și în zona de administrare.

## Statusurile

| Status | Când se aplică | Culoare |
|---|---|---|
| Nepreluat | Firma a fost sunată dar nu a răspuns (durată 0, apel eșuat/ocupat/fără răspuns) | roșu |
| Apel scurt | A răspuns, dar sub 40 de secunde — considerat informativ, nefacturabil | gri |
| Lead calificat | Apel de peste 40 de secunde — lead real, facturabil, așteaptă procesare | albastru |
| Finalizat | Firma a marcat manual comanda ca dusă la final | verde |

Primele trei se calculează automat din apel; ultimul se setează manual de firmă, într-un singur pas, din dialogul „Finalizare apel". Nu există status „Pierdut" — un lead nefinalizat rămâne „Lead calificat".

## Trecerea pragului de la 30s la 40s

Pragul de lead valid devine 40 de secunde peste tot:

- facturare (30 lei / lead valid) în secțiunea Financiar din administrare;
- scorul firmelor (lead-uri valide, lead-uri neprocesate);
- statisticile firmei („Potențiali clienți", rata de conversie, export Excel);
- dashboard-ul „Rezultate" (ROI).

## Unde apar statusurile

- **Dashboard firmă → Apeluri**: badge de status pe fiecare apel; acțiunea de finalizare apare doar pentru lead-urile calificate încă nefinalizate (butonul de renunțare/„pierdut" dispare).
- **Admin → tabelul de lead-uri**: aceeași coloană de status, iar filtrul multiselect de status trece de la statusurile tehnice Twilio la aceste patru statusuri de business.
- **Admin → Statistici**: numărătorile pe lead-uri folosesc aceleași definiții.

## Detalii tehnice

- `src/lib/leadStatus.ts` (nou): constanta `QUALIFIED_LEAD_SECONDS = 40`, funcție `getLeadStatus(call)` care întoarce cheia, eticheta și tonul; folosită de toate ecranele.
- Migrație: actualizarea funcției `get_firm_scores()` să folosească pragul 40s și să nu mai numere lead-uri „pierdute"; fără coloane noi — `outcome` rămâne `pending` / `resolved`.
- Componente atinse: `CallLogsTable.tsx` (badge + filtru pe status de business, filtrare client-side pe durată/outcome), `DashboardPage.tsx`, `RoiDashboard.tsx`, `AdminStatisticsPage.tsx`, `AdminDashboardPage.tsx` (financiar), `src/lib/exportStats.ts`, `src/lib/firmScore.ts` (comentarii/praguri).
- Badge-ul de status reutilizabil: `src/components/LeadStatusBadge.tsx`.
