# Plan: Identitate vizuală Funerio bazată pe porumbel

## Obiectiv
Transformăm porumbelul din logo într-un simbol recognoscibil al aplicației, fără să încărcăm vizual interfața. Direcția aleasă este o animație scurtă de „zbor discret”, afișată la fiecare deschidere de pagină și popup, iar simbolul va apărea și în stările goale sau de succes.

## Implementare

1. **Pregătirea simbolului de brand**
   - Extragem porumbelul din logo-ul existent într-un asset separat, cu fundal transparent și proporții potrivite pentru animații.
   - Păstrăm logo-ul complet existent în navigație; noul asset este folosit doar ca simbol secundar.
   - Derivăm favicon-ul din același porumbel pentru identitate coerentă în browser.

2. **Componentă animată reutilizabilă**
   - Construim o componentă `DoveLoader` cu variante pentru pagină, popup și element inline.
   - Mișcarea va combina o ridicare foarte mică, o înclinare discretă și estompare, timp de aproximativ 400 ms.
   - Respectăm `prefers-reduced-motion`, caz în care simbolul apare fără deplasare.

3. **Tranziție la deschiderea paginilor**
   - La fiecare schimbare de rută afișăm animația scurtă peste conținut, fără să întârziem încărcarea datelor sau navigarea.
   - Înlocuim fallback-ul generic al paginilor lazy și principalele spinnere de pagină cu loader-ul Funerio.
   - Loader-ele mici din butoane rămân compacte, dar folosesc varianta inline a porumbelului pentru consistență.

4. **Identitate în popup-uri**
   - Adăugăm automat simbolul animat în componenta comună de dialog, astfel încât popup-urile existente să primească identitatea fără modificări repetitive.
   - Aplicăm același tratament dialogurilor de confirmare; meniul lateral mobil rămâne neschimbat, deoarece nu este un popup de acțiune.
   - Animația nu blochează interacțiunea și nu mută conținutul când se termină.

5. **Stări goale și de succes**
   - Creăm componente comune pentru stări goale și succes, cu porumbelul static sau animat subtil.
   - Le aplicăm în listele și dashboard-urile unde apar acum mesaje simple precum „Nu există date”, „Nu există apeluri” sau „Nu am găsit rezultate”.
   - Stările de succes vizibile în pagină, precum trimiterea cererii de ofertă, primesc simbolul de brand; notificările toast rămân compacte.

6. **Verificare**
   - Verificăm tranzițiile pe rutele publice, dashboard și admin.
   - Testăm deschiderea dialogurilor și stările goale/succes pe desktop și mobil, inclusiv că animația nu declanșează tastatura și nu produce salturi de layout.

## Detalii tehnice
- Culorile rămân în sistemul semantic monocrom existent, inspirate din paleta aleasă: `#171717`, `#404040`, `#D4D4D4`, `#F5F5F5`.
- Animațiile vor fi definite în design system și reutilizate prin componente, nu duplicate în pagini.
- Nu modificăm fluxurile, datele sau logica popup-urilor; schimbarea este strict de identitate vizuală și feedback de interfață.

