# Wizard principal Funerio în 3 pași

## Obiectiv

Înlocuim cele două acțiuni și lista de firme de pe pagina principală cu un singur flux ghidat, optimizat pentru mobil:

```text
1. Locație → 2. Mod de contact → 3. Date personale / acțiune
```

## Experiența utilizatorului

### Pasul 1 — Locație
- Dropdown pentru județ, urmat de un dropdown căutabil pentru localitățile județului selectat.
- Schimbarea județului resetează localitatea.
- Utilizatorul poate continua numai după completarea ambelor câmpuri.

### Pasul 2 — Cum dorește ajutor
- Trei opțiuni mari, ușor de apăsat pe telefon, fiecare cu icon și explicație:
  - **Contactează acum o firmă** — „Veți fi pus în legătură imediat cu firmele disponibile.”
  - **Cere ofertă** — „Firmele vă vor contacta pentru a vă face o ofertă.”
  - **Descoperă ofertele** — „Puteți vedea serviciile firmelor și să contactați firma dorită.”
- Se păstrează o singură selecție, evidențiată clar.

### Pasul 3 — Finalizare
- Pentru **Contactează acum o firmă** și **Cere ofertă**, afișăm nume complet și telefon, plus un rezumat al locației și opțiunii.
- Câmpurile au limite, validare pentru nume și număr românesc, mesaje clare și nu primesc focus automat pe mobil.
- Pentru **Contactează acum**, confirmarea inițiază apelul automat și afișează starea de succes existentă.
- Pentru **Cere ofertă**, confirmarea creează cereri pentru maximum 3 firme eligibile și afișează câte firme au primit cererea.
- Pentru **Descoperă ofertele**, pasul 2 continuă direct spre `/firme`, cu județul și localitatea păstrate în URL pentru prefiltrarea listei.
- Buton „Înapoi” între pași, progres vizibil și păstrarea datelor introduse când utilizatorul revine.

## Reguli de distribuire

- Se caută mai întâi firme din localitatea și județul selectate.
- Dacă nu există firme eligibile în localitate, căutarea se extinde automat la întreg județul.
- **Cere ofertă** distribuie automat către maximum 3 firme; utilizatorul nu mai alege manual firmele în acest flux.
- **Contactează acum** încearcă secvențial firmele care pot primi apeluri, mai întâi local, apoi la nivel de județ dacă nu există rezultate locale.
- Mesajele de confirmare precizează când selecția a fost extinsă la nivel de județ.

## Integrarea în aplicație

- Construim o componentă dedicată pentru wizard și o folosim drept experiență principală în pagina Acasă.
- Eliminăm din Acasă cele două butoane actuale, popup-ul separat de apel, lista de firme și filtrele; footer-ul și identitatea Funerio rămân.
- Pagina `/firme` rămâne disponibilă pentru „Descoperă ofertele” și va citi locația din URL. Filtrarea va include și localitatea, nu doar județul.
- Ruta existentă `/cere-oferta` poate rămâne disponibilă pentru linkuri vechi, dar noul flux principal nu va depinde de selecția manuală de firme de acolo.
- Refolosim lista completă existentă de județe și localități și componentele vizuale/loader-ele cu porumbelul Funerio.

## Backend și siguranța datelor

- Extindem funcția de apel cu `county`, `city`, `name` și `phone`; validăm toate valorile și lungimile și pe server înainte de interogare sau apel.
- Adăugăm numele apelantului în lead-urile de apel, astfel încât firma să vadă în dashboard numele și telefonul furnizate în wizard.
- Creăm o funcție backend pentru cererile de ofertă care validează datele, alege maximum 3 firme conform regulilor de mai sus, creează cererile și trimite notificările. Browserul nu va putea decide arbitrar destinatarii.
- Migrarea bazei de date va include coloana necesară pentru numele apelantului, permisiunile explicite și păstrarea politicilor de acces existente.
- Erorile parțiale vor fi tratate fără a raporta succes fals; butonul de trimitere va fi blocat cât timp cererea este procesată.

## Verificare

- Testăm toate cele trei ramuri, navigarea înainte/înapoi, validările și stările de succes/eroare.
- Verificăm selecția locală și fallback-ul la județ pentru apel și ofertă.
- Confirmăm că cererile apar pe dashboard-urile firmelor și că lead-urile telefonice afișează numele.
- Verificăm vizual la dimensiuni mobile și desktop, inclusiv dropdown-uri lungi, tastatura mobilă, bara de progres și lipsa suprapunerilor.