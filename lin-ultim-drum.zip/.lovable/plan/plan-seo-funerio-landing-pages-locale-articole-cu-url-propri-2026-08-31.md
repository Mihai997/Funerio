# Plan SEO Funerio: landing pages locale + articole cu URL propriu

## Obiectiv
Să apărem în Google pe căutările reale ale oamenilor ("servicii funerare Craiova", "transport funerar Craiova", "pompe funebre non stop", "ajutor de deces 2026") prin pagini dedicate, fiecare cu URL, titlu, descriere și conținut propriu.

## 1. Articole: pagină separată per articol
Azi articolele se expandează în `/articole` — Google vede o singură pagină.

- Rută nouă `/articole/:slug` (ex. `/articole/ajutor-de-deces-2026`).
- Slug-uri optimizate pe intenția de căutare, nu pe titlu literal.
- `/articole` devine listă (card + buton "Citește articolul" → link real, nu expand).
- Fiecare articol primește: H1 unic, title < 60 caractere, meta description < 160, canonical propriu, JSON-LD `Article` + `BreadcrumbList`, dată publicare/actualizare, breadcrumb vizibil, secțiune "Articole similare" + CTA către `/cere-oferta` sau firme.
- Conținutul se mută din blocuri de text simple în structură cu H2/H3, liste, tabele (ex. valoare ajutor de deces), astfel încât să fie util și citabil.
- Redirecționăm vechile ancore (`/articole#id`) către noul URL.

Exemplu articol nou propus: **/articole/ajutor-de-deces-2026** — "Ajutorul de deces în 2026: cine îl primește, valoare, acte și procedură" (cu tabel valori, listă acte, pași depunere, surse oficiale CNPP/Casa de Pensii).

## 2. Landing pages pe serviciu + oraș
Sistem de pagini generate dintr-un fișier de configurare (serviciu × localitate), nu pagini scrise manual una câte una.

Tipare de URL:
```text
/servicii-funerare/craiova
/servicii-funerare-non-stop/craiova
/servicii/transport-funerar/craiova
/servicii/repatriere-decedati/craiova
/servicii/incinerare/craiova
/pompe-funebre/craiova
```
Plus pagini-hub de județ: `/servicii-funerare/dolj`, și hub-uri de serviciu la nivel național: `/servicii/transport-funerar`.

Fiecare landing page conține:
- H1 cu serviciu + oraș, intro cu context local (nu text duplicat între orașe: variem prin date reale — număr firme, preț minim din pachete, județ, localități învecinate).
- Lista firmelor reale din oraș/județ (date live din backend) — asta e conținutul unic care ne diferențiază de paginile-șablon.
- Bloc preț: "Preț de la X RON" calculat din pachetele firmelor.
- CTA: sună acum / cere ofertă (pre-completat cu județul și localitatea din URL).
- FAQ local (3-5 întrebări) + JSON-LD `LocalBusiness`/`Service` + `BreadcrumbList`.
- Linkuri interne către orașele apropiate, hub-ul de județ și articolele relevante.
- Dacă nu există firme în oraș: afișăm firmele din județ și marcăm pagina `noindex` până apar firme (evităm pagini goale penalizate).

**Acoperire propusă la start:** ~40 orașe mari (reședințe de județ + orașe > 50k locuitori) × 5-6 servicii ≈ 200-240 pagini, extinse ulterior. Alternativ putem porni doar cu 10 orașe pilot.

## 3. Îmbunătățiri SEO tehnice și de conținut (restul listei)
- **Sitemap dinamic**: generat la build din rute + articole + landing pages; `lastmod` corect; înregistrat în robots.txt (deja e).
- **Pagini firmă**: `/firme/:id` → URL cu slug (`/firme/nume-firma-craiova`), title/description/canonical per firmă, JSON-LD `FuneralHome` (LocalBusiness) cu adresă, telefon, program 24/7, rating.
- **Filtre indexabile**: `/firme?county=Dolj` → variantă canonică `/servicii-funerare/dolj`; parametrii rămân `noindex`.
- **Head per rută** peste tot (componenta `Seo` există deja) + `og:title/description/url` corecte, canonical self-referencing.
- **JSON-LD sitewide**: Organization + WebSite cu `SearchAction`; `FAQPage` pe /faq.
- **Structură internă de linkuri**: footer cu top orașe + servicii, hub `/servicii`, hub `/localitati`.
- **Performanță (Core Web Vitals)**: imagini lazy + dimensiuni fixe, preload font, reducerea JS pe homepage.
- **Accesibilitate/semantică**: un singur H1 per pagină, `alt` pe imagini, heading-uri ierarhice.
- **Conținut nou recomandat** (după validare cu date de căutare): costuri înmormântare 2026, acte necesare deces, ce faci în primele 24 de ore, incinerare vs. înmormântare, repatriere din străinătate — fiecare cu landing page propriu.
- **Validare cu Semrush** înainte de a scrie: volume și dificultate pentru fiecare tipar de URL, ca să prioritizăm orașele și serviciile care aduc trafic real.
- **Google Search Console**: verificare proprietate + trimitere sitemap, apoi monitorizare indexare.
- **Mentenanță**: `MAINTENANCE_MODE` e activ în `App.tsx` — cât timp e pornit, Google nu poate indexa nimic. Trebuie oprit înainte ca planul să aibă efect.

## Detalii tehnice
- Rute noi în `src/App.tsx`, lazy-loaded: `/articole/:slug`, `/servicii`, `/servicii/:serviceSlug`, `/servicii/:serviceSlug/:citySlug`, `/servicii-funerare/:slug`, `/servicii-funerare-non-stop/:citySlug`.
- Conținutul articolelor se mută din `ArticlesPage.tsx` într-un modul `src/content/articles/` (un fișier per articol, cu `slug`, `title`, `metaTitle`, `metaDescription`, `date`, `updated`, `body`).
- Configurația landing pages: `src/content/serviceLandings.ts` (serviciu → slug, H1, descriere, FAQ) combinată cu `src/data/romanianLocalities.ts`; slugify cu diacritice→ASCII.
- Componentă comună `ServiceCityLandingPage` care preia firmele din backend filtrate pe județ/localitate.
- Sitemap generat de un script Node rulat în `build` (scrie `public/sitemap.xml`).
- Limită de stack: aplicația e SPA (fără randare pe server). Googlebot execută JS și vede aceste pagini, dar preview-urile pe Facebook/LinkedIn arată doar tag-urile din `index.html`. Dacă vrem head real pe server pentru fiecare pagină, aplicația poate fi migrată la template-ul nou cu SSR ([ce aduce upgrade-ul](https://lovable.dev/blog/building-apps-using-tanstack-start)).

## Etape de implementare
1. Articole cu URL propriu + articolul "Ajutor de deces 2026" (impact rapid).
2. Infrastructura de landing pages + 10 orașe pilot × 5 servicii, validate cu Semrush.
3. Slug-uri pentru paginile de firmă + JSON-LD LocalBusiness.
4. Sitemap dinamic, hub-uri, linkuri interne, performanță.
5. Extindere la 40+ orașe.
