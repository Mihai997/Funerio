# Pagină de statistici pentru administrator

Pagină nouă `/admin/statistici`, accesibilă doar administratorilor, cu trei secțiuni: Cerere, Firme, Lead-uri.

## Ce lipsește azi

Platforma nu înregistrează nicăieri vizitatorii sau pașii parcurși în wizard-ul de pe prima pagină. Apelurile și cererile de ofertă se salvează (apeluri în jurnalul de apeluri, cererile de ofertă ca și comenzi), dar pâlnia „vizitator → wizard → acțiune" nu poate fi calculată fără o urmărire nouă.

Adăugăm deci o urmărire proprie, anonimă, a evenimentelor din aplicație.

## 1. Urmărirea evenimentelor (anonim)

Tabel nou de evenimente care reține: tipul evenimentului, un identificator anonim de sesiune (generat în browser, fără date personale), pagina, județul/localitatea alese și momentul.

Evenimente înregistrate:

| Eveniment | Când |
|---|---|
| `page_view` | la fiecare schimbare de pagină |
| `wizard_start` | la prima interacțiune cu wizard-ul (alegerea județului) |
| `wizard_step_2` / `wizard_step_3` | la avansarea între pași |
| `wizard_complete` | la trimiterea cu succes (apel inițiat sau ofertă trimisă) |
| `view_firms` | la alegerea „Descoperă ofertele" sau la deschiderea listei de firme |
| `call_requested` | la alegerea „Contactează acum o firmă" și inițierea apelului |
| `quote_requested` | la trimiterea unei cereri de ofertă (wizard sau pagina dedicată) |

Vizitatorii se numără ca sesiuni unice, nu ca afișări de pagină.

## 2. Secțiunile paginii

**Cerere** (pâlnie, cu procent de trecere între pași)
- Vizitatori
- Persoane care au început wizard-ul
- Persoane care l-au finalizat
- Persoane care au văzut firme
- Persoane care au sunat
- Persoane care au cerut ofertă

Afișată ca listă de bare orizontale, fiecare cu valoare absolută și „% din vizitatori", plus rata de conversie totală.

**Firme**
- Firme înscrise (total)
- Active / Inactive (după starea abonamentului)
- Firme care au primit cel puțin un lead în perioada selectată

**Lead-uri**
- Total lead-uri (apeluri primite + cereri de ofertă)
- Lead-uri valide (apeluri peste 30 de secunde + cereri de ofertă)
- Apeluri
- Cereri de ofertă

## 3. Comportament

- Filtru de perioadă în antet: 7 zile / 30 zile / luna curentă / total. Datele istorice de pâlnie încep de la momentul activării urmăririi (afișăm o notă discretă).
- Layout responsive: carduri pe 2 coloane pe mobil, 3–4 pe desktop.
- Acces din meniul Admin, alături de Firme și Utilizatori.

## Detalii tehnice

- Migrație: tabel `public.site_events` (`event_name`, `session_id`, `path`, `county`, `city`, `metadata jsonb`, `created_at`), index pe `(event_name, created_at)`; inserare permisă vizitatorilor nelogați, citire doar pentru administratori; funcție `get_site_funnel(_from timestamptz, _to timestamptz)` security definer, restricționată la administratori, care întoarce numărul de sesiuni distincte per eveniment.
- `src/lib/tracking.ts` — `trackEvent(name, payload)` cu `session_id` păstrat în `sessionStorage`, apeluri fire-and-forget care nu blochează UI-ul.
- Instrumentare: `ScrollToTop`/`App` pentru `page_view`, `HomeWizard.tsx` pentru pașii wizard-ului și acțiuni, `RequestQuotePage.tsx` pentru `quote_requested`, `FuneralHomesPage.tsx` pentru `view_firms`.
- Pagină nouă `src/pages/AdminStatisticsPage.tsx` + rută `/admin/statistici` în `App.tsx`, protejată cu aceeași verificare de rol ca celelalte pagini admin; link în `Navigation.tsx`.
- Secțiunile Firme și Lead-uri se calculează din `funeral_homes`, `call_logs` (apeluri, prag 30s) și `orders` (cereri de ofertă), fără date noi.
