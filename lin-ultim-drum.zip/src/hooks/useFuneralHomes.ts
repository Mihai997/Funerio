import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { FuneralHome } from "@/types/funeral";
import { PUBLIC_FIRM_COLUMNS, publicPhone } from "@/lib/publicFirm";

export const useFuneralHomes = () => {
  const [funeralHomes, setFuneralHomes] = useState<FuneralHome[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;

    const load = async () => {
      try {
        const [homesRes, servicesRes, packagesRes] = await Promise.all([
          supabase.from("funeral_homes").select(PUBLIC_FIRM_COLUMNS),
          supabase.from("services").select("*").eq("approval_status", "approved"),
          supabase.from("packages").select(`*, package_services ( service_id )`).eq("approval_status", "approved"),
        ]);
        if (homesRes.error) throw homesRes.error;
        if (servicesRes.error) throw servicesRes.error;
        if (packagesRes.error) throw packagesRes.error;

        const services = servicesRes.data || [];
        const packages = packagesRes.data || [];

        const mapped: FuneralHome[] = (homesRes.data || []).map((home) => ({
          id: home.id,
          name: home.name,
          logo: home.logo || "🕊️",
          description: home.description,
          location: { county: home.county, city: home.city },
          priceRange: home.price_range as "€" | "€€" | "€€€",
          rating: Number(home.rating) || 0,
          reviewCount: home.review_count || 0,
          phone: publicPhone(home.tracking_phone),
          email: home.email,
          services: services
            .filter((s) => s.funeral_home_id === home.id)
            .map((s) => ({
              id: s.id,
              name: s.name,
              category: s.category,
              description: s.description,
              price: Number(s.price),
              priceUnit: s.price_unit,
            })),
          packages: packages
            .filter((p) => p.funeral_home_id === home.id)
            .map((p) => ({
              id: p.id,
              name: p.name,
              description: p.description,
              price: Number(p.price),
              includedServices: (p.package_services || []).map((ps: any) => ps.service_id),
            })),
        }));

        if (active) setFuneralHomes(mapped);
      } catch (error) {
        console.error("Error loading funeral homes:", error);
      } finally {
        if (active) setLoading(false);
      }
    };

    load();
    return () => {
      active = false;
    };
  }, []);

  return { funeralHomes, loading };
};
