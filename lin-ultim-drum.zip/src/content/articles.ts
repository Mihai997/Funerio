export interface Article {
  slug: string;
  legacyId?: string;
  title: string;
  metaTitle: string;
  metaDescription: string;
  excerpt: string;
  category: string;
  readTime: number;
  date: string;
  updated?: string;
  body: string;
}

export const articles: Article[] = [
  {
    slug: "ajutor-de-deces-2026",
    title: "Ajutorul de deces în 2026: cine îl primește, valoare, acte și procedură",
    metaTitle: "Ajutor de deces 2026: valoare, acte și procedură",
    metaDescription:
      "Cât este ajutorul de deces în 2026, cine îl poate solicita, ce acte sunt necesare și în cât timp se primește. Ghid pas cu pas pentru familii.",
    excerpt:
      "Cât este ajutorul de deces, cine îl poate cere, ce acte trebuie depuse și în cât timp se primește banii. Ghid actualizat pentru 2026.",
    category: "Financiar",
    readTime: 7,
    date: "2026-01-10",
    updated: "2026-08-31",
    body: `
Ajutorul de deces este o sumă acordată de stat familiei sau persoanei care suportă cheltuielile de înmormântare. Se acordă o singură dată, pentru fiecare deces, și este cel mai rapid sprijin financiar disponibil în această situație.

## Cine poate primi ajutorul de deces

- Soțul supraviețuitor, copilul, părintele, tutorele sau curatorul persoanei decedate.
- Moștenitorul, în condițiile dreptului comun.
- Orice altă persoană care dovedește, cu documente, că a suportat cheltuielile ocazionate de deces.

Ajutorul se acordă atât la decesul asiguratului sau pensionarului, cât și la decesul unui membru de familie aflat în întreținerea acestuia (soț/soție, copii până la 18 ani sau până la 26 de ani dacă urmează studii, părinți fără venituri proprii).

## Valoarea ajutorului de deces

Valoarea este stabilită anual prin legea bugetului asigurărilor sociale de stat și se raportează la câștigul salarial mediu brut utilizat la fundamentarea bugetului.

| Situație | Cuantum |
| --- | --- |
| Deces asigurat / pensionar | Un câștig salarial mediu brut |
| Deces membru de familie aflat în întreținere | Jumătate din câștigul salarial mediu brut |

Verifică valoarea exactă valabilă în anul curent pe site-ul Casei Naționale de Pensii Publice (cnpp.ro) sau la casa teritorială de pensii, pentru că suma se actualizează în fiecare an.

## Acte necesare

1. Cerere pentru acordarea ajutorului de deces (formular tipizat).
2. Certificatul de deces, în original și copie.
3. Actul de identitate al solicitantului.
4. Acte de stare civilă care dovedesc gradul de rudenie (certificat de căsătorie, certificat de naștere).
5. Dovada că solicitantul a suportat cheltuielile: factură fiscală sau chitanță de la firma de servicii funerare.
6. Pentru decesul unui membru de familie aflat în întreținere: acte care dovedesc calitatea de întreținut (adeverință de elev/student, declarație privind lipsa veniturilor).

## Unde se depune cererea

- La casa teritorială de pensii, dacă persoana decedată era pensionar sau asigurat.
- La angajator, dacă persoana decedată era salariat (angajatorul plătește ajutorul și îl recuperează ulterior).
- La agenția județeană pentru ocuparea forței de muncă, dacă persoana era beneficiară de indemnizație de șomaj.

## În cât timp se primesc banii

Ajutorul de deces se achită în termen de 24 de ore de la solicitare, dacă dosarul este complet. Dreptul de a cere ajutorul se prescrie în 3 ani de la data decesului.

## Sfaturi practice

- Cere firmei de servicii funerare factura pe numele persoanei care va depune cererea; fără acest document, plata poate fi refuzată.
- Fă mai multe copii ale certificatului de deces — vei avea nevoie de ele și la bancă, notar sau asigurări.
- Ajutorul de deces nu acoperă, de regulă, întregul cost al înmormântării. Compară ofertele mai multor firme înainte de a semna un contract.

## Surse oficiale

- Casa Națională de Pensii Publice (cnpp.ro)
- Legea nr. 263/2010 privind sistemul unitar de pensii publice, cu modificările ulterioare
- Legea anuală a bugetului asigurărilor sociale de stat
`,
  },
  {
    slug: "cum-alegi-firma-de-pompe-funebre",
    legacyId: "cum-alegi-firma-pompe-funebre",
    title: "Cum să alegi firma de pompe funebre potrivită",
    metaTitle: "Cum alegi firma de pompe funebre: 5 criterii",
    metaDescription:
      "Ghid practic pentru a alege o firmă de pompe funebre de încredere: autorizații, prețuri, servicii incluse și întrebările pe care trebuie să le pui.",
    excerpt:
      "Ghid complet pentru a face alegerea corectă într-un moment dificil. Află ce criterii sunt importante și ce întrebări să adresezi.",
    category: "Ghid",
    readTime: 5,
    date: "2025-01-15",
    body: `
Alegerea unei firme de pompe funebre este o decizie importantă, luată de cele mai multe ori într-un moment emoțional dificil și sub presiunea timpului. Următoarele criterii te ajută să decizi rapid, dar corect.

## 1. Verifică licențele și autorizațiile

Asigură-te că firma deține toate autorizațiile legale necesare pentru a opera. O firmă de încredere va fi transparentă în privința documentelor sale și îți va prezenta contractul înainte de plată.

## 2. Compară prețurile

Solicită oferte detaliate de la mai multe firme. Prețurile pot varia semnificativ pentru aceleași servicii, iar transparența costurilor este esențială.

## 3. Citește recenziile

Feedback-ul altor familii oferă informații valoroase despre calitatea serviciilor și profesionalismul echipei.

## 4. Verifică serviciile incluse

Cere lista exactă a serviciilor din pachet și costurile suplimentare: transport, îmbălsămare, acte, capelă, sicriu, flori.

## 5. Evaluează comunicarea

O firmă de calitate răspunde prompt, disponibilă non-stop, și oferă sprijin real în organizarea formalităților.

## Întrebări pe care merită să le pui

- Ce include exact prețul afișat și ce se plătește separat?
- Cine se ocupă de documentele de la starea civilă?
- Sunt disponibili 24/7 pentru ridicarea decedatului?
- Ce se întâmplă dacă apar costuri neprevăzute?
`,
  },
  {
    slug: "tipuri-de-servicii-funerare",
    legacyId: "tipuri-servicii-funerare",
    title: "Tipuri de servicii funerare: ce opțiuni ai în România",
    metaTitle: "Tipuri de servicii funerare în România",
    metaDescription:
      "Înmormântare tradițională, incinerare, înmormântare ecologică, repatriere sau ceremonie civilă: diferențe, costuri și când se potrivește fiecare opțiune.",
    excerpt:
      "Descoperă diferitele tipuri de servicii funerare disponibile în România, de la înmormântări tradiționale la cremații.",
    category: "Informații",
    readTime: 4,
    date: "2025-01-12",
    body: `
Există mai multe tipuri de servicii funerare disponibile în România, fiecare cu particularitățile și costurile sale.

## Înmormântare tradițională

Cea mai comună formă. Include priveghiul, slujba religioasă și înhumarea în cimitir. Necesită loc de veci și implică cele mai multe costuri conexe (pomeni, monument).

## Incinerare (cremație)

O alternativă tot mai populară, disponibilă în orașele cu crematoriu. Oferă flexibilitate în privința păstrării urnei sau dispersării cenușii.

## Înmormântare ecologică

Pentru cei preocupați de mediu: sicrie biodegradabile, urne solubile, ceremonii cu impact redus.

## Servicii de repatriere

Pentru persoanele decedate în străinătate, firmele oferă transport internațional, documentație consulară și sicriu conform normelor de transport.

## Ceremonie civilă

Pentru familiile care preferă o ceremonie non-religioasă, personalizată după dorințele defunctului.
`,
  },
  {
    slug: "acte-necesare-in-caz-de-deces",
    legacyId: "documente-necesare-deces",
    title: "Acte necesare în caz de deces: lista completă și pașii de urmat",
    metaTitle: "Acte necesare în caz de deces: listă completă",
    metaDescription:
      "Ce documente sunt necesare la deces, cum obții certificatul de deces și adeverința de înhumare, plus termenele legale pe care trebuie să le respecți.",
    excerpt:
      "Lista completă a documentelor necesare și pașii de urmat pentru obținerea certificatului de deces și organizarea înmormântării.",
    category: "Documente",
    readTime: 6,
    date: "2025-01-10",
    body: `
În momentul decesului unei persoane dragi există mai multe formalități legale care trebuie îndeplinite, unele cu termene stricte.

## Documente necesare

- Certificatul medical constatator al decesului (eliberat de medic)
- Actul de identitate al defunctului
- Certificatul de naștere al defunctului
- Certificatul de căsătorie, dacă este cazul
- Actul de identitate al declarantului

## Pași de urmat

1. Obținerea certificatului medical constatator al decesului.
2. Declararea decesului la starea civilă, în termen de 3 zile de la deces.
3. Obținerea certificatului de deces.
4. Obținerea adeverinței de înhumare sau incinerare.
5. Contactarea firmei de pompe funebre pentru organizarea ceremoniei.

## Sfaturi utile

- Păstrează mai multe copii ale certificatului de deces: îți vor fi cerute la bancă, notar, casa de pensii.
- Majoritatea firmelor de pompe funebre te pot ajuta cu formalitățile, inclusiv cu depunerea documentelor.
- Nu ezita să ceri ajutor familiei sau prietenilor pentru drumurile administrative.
`,
  },
  {
    slug: "cum-organizezi-o-pomenire",
    legacyId: "cum-organizezi-pomenire",
    title: "Cum să organizezi o pomenire: tradiții și sfaturi practice",
    metaTitle: "Cum organizezi o pomenire: tradiții și pași",
    metaDescription:
      "Când se fac pomenirile, ce se pregătește (colivă, colaci, pomeni) și cum organizezi masa de pomenire respectând tradițiile românești.",
    excerpt:
      "Ghid complet despre tradițiile de pomenire în România și cum să le organizezi respectând obiceiurile locale.",
    category: "Tradiții",
    readTime: 5,
    date: "2025-01-08",
    body: `
Pomenirile sunt o parte importantă a tradițiilor funerare românești și se organizează la momente precise după deces.

## Când se fac pomenirile

- La 3 zile, imediat după înmormântare
- La 9 zile
- La 40 de zile (parastasul mare)
- La 6 luni
- La 1 an, apoi anual

## Ce se pregătește

- Colivă
- Colaci
- Lumânări
- Mâncare pentru masa de pomenire
- Pachete de pomană

## Sfaturi practice

- Discută din timp cu preotul despre ceremonia religioasă.
- Stabilește numărul de invitați înainte de a rezerva locul mesei.
- Alege un local sau o sală apropiată de biserică sau cimitir.
- Multe firme de servicii funerare oferă și organizarea mesei de pomenire.
`,
  },
  {
    slug: "cat-costa-o-inmormantare",
    legacyId: "buget-inmormantare",
    title: "Cât costă o înmormântare: bugetul și costurile de anticipat",
    metaTitle: "Cât costă o înmormântare în România",
    metaDescription:
      "Costurile unei înmormântări în România: sicriu, transport funerar, ceremonie, loc de veci, monument și masă de pomenire, cu intervale de preț orientative.",
    excerpt:
      "Informații transparente despre costurile serviciilor funerare și cum să planifici bugetul necesar.",
    category: "Financiar",
    readTime: 7,
    date: "2025-01-05",
    body: `
Costurile unei înmormântări variază semnificativ în funcție de oraș, de tipul ceremoniei și de serviciile alese. Mai jos, intervale orientative.

## Costuri principale

| Serviciu | Interval orientativ |
| --- | --- |
| Sicriu | 800 – 5.000+ RON |
| Transport funerar | 500 – 2.000 RON |
| Îmbălsămare / tanatopraxie | 300 – 800 RON |
| Ceremonie religioasă | 200 – 1.000 RON |
| Loc de veci | 1.000 – 10.000+ RON |
| Monument funerar | 2.000 – 15.000+ RON |

## Costuri suplimentare

- Flori și aranjamente: 300 – 1.500 RON
- Masă de pomenire: 1.000 – 5.000+ RON
- Anunțuri mortuare: 100 – 500 RON
- Fotografii și filmare: 200 – 1.000 RON

## Cum reduci costurile

- Compară ofertele mai multor firme din același oraș.
- Întreabă despre pachete complete, adesea mai ieftine decât serviciile separate.
- Verifică ce este inclus în preț, ca să eviți costuri surpriză.
- Solicită ajutorul de deces de la casa de pensii sau de la angajator.
`,
  },
  {
    slug: "cum-treci-peste-doliu",
    legacyId: "sprijin-emotional-doliu",
    title: "Cum să faci față doliului: sprijin emoțional și resurse",
    metaTitle: "Cum faci față doliului: sprijin și resurse",
    metaDescription:
      "Etapele doliului, sfaturi pentru a trece prin pierdere și semnele care arată că ai nevoie de ajutor profesionist.",
    excerpt:
      "Sfaturi pentru gestionarea durerii și resurse de sprijin pentru cei care trec prin pierderea unei persoane dragi.",
    category: "Sprijin",
    readTime: 6,
    date: "2025-01-03",
    body: `
Doliul este un proces natural și profund personal. Nu există un calendar corect al vindecării.

## Etapele doliului

1. Negarea — dificultatea de a accepta pierderea
2. Furia — sentimente de nedreptate
3. Negocierea — gândurile de tipul „dacă aș fi…"
4. Tristețea profundă
5. Acceptarea — adaptarea la noua realitate

## Ce te poate ajuta

- Acordă-ți timp să jelești, fără termene impuse.
- Nu te izola de familie și prieteni.
- Vorbește despre ce simți, cu cineva în care ai încredere.
- Menține o rutină zilnică simplă.
- Ai grijă de somn, alimentație și mișcare.

## Când să ceri ajutor profesionist

- Când doliul afectează major viața cotidiană pe termen lung.
- Când apar gânduri de auto-vătămare.
- Când simți că nu poți face față singur.

## Resurse de sprijin

- Grupuri de suport pentru persoane în doliu
- Consilieri și psihoterapeuți
- Linii telefonice de ajutor
`,
  },
  {
    slug: "cum-alegi-sicriul-sau-urna",
    legacyId: "alegere-sicriu-urna",
    title: "Ghid pentru alegerea sicriului sau a urnei funerare",
    metaTitle: "Cum alegi sicriul sau urna funerară",
    metaDescription:
      "Tipuri de sicrie și urne funerare, materiale, finisaje și criterii de alegere în funcție de buget, tradiție și tipul ceremoniei.",
    excerpt:
      "Tot ce trebuie să știi despre tipurile de sicrie și urne disponibile, materiale și criterii de selecție.",
    category: "Ghid",
    readTime: 5,
    date: "2025-01-01",
    body: `
Alegerea sicriului sau a urnei este una dintre deciziile cu cel mai mare impact asupra bugetului.

## Tipuri de sicrie

- Din lemn masiv (stejar, nuc, brad)
- Din MDF sau PAL
- Metalice
- Ecologice, din materiale biodegradabile

## Materiale și finisaje

- Lemn natural sau vopsit
- Tapiserie interioară
- Ornamente și mânere
- Gravuri personalizate

## Urne funerare

- Din ceramică
- Din metal (bronz, alamă)
- Din lemn
- Biodegradabile, pentru dispersare

## Criterii de alegere

- Bugetul disponibil
- Preferințele familiei
- Tradițiile religioase
- Dimensiunile necesare
- Stilul ceremoniei
`,
  },
  {
    slug: "flori-funerare-semnificatii",
    legacyId: "flori-funerare-semnificatii",
    title: "Florile funerare și semnificațiile lor",
    metaTitle: "Flori funerare: semnificații și aranjamente",
    metaDescription:
      "Ce semnifică florile folosite la înmormântări, ce tipuri de aranjamente există și cum alegi coroana sau jerba potrivită.",
    excerpt:
      "Descoperă semnificația diferitelor flori folosite la înmormântări și cum să alegi aranjamentul potrivit.",
    category: "Tradiții",
    readTime: 4,
    date: "2024-12-28",
    body: `
Florile joacă un rol important în ceremoniile funerare, iar alegerea lor comunică respect și amintire.

## Semnificații

- Crizanteme — respect și doliu
- Trandafiri albi — puritate și inocență
- Trandafiri roșii — dragoste și respect
- Crini — sufletul care se înalță
- Garoafe — amintire și devotament
- Gladiole — caracter și integritate

## Tipuri de aranjamente

- Coroane funerare
- Buchete
- Jerbe
- Aranjamente pentru sicriu
- Coșuri cu flori

## Sfaturi pentru alegere

- Ține cont de florile preferate ale defunctului.
- Respectă tradițiile familiei și ale zonei.
- Alege culori potrivite: alb, mov, roșu închis.
- Comandă din timp pentru ceremoniile mari.
`,
  },
];

export const getArticleBySlug = (slug: string) => articles.find((a) => a.slug === slug);

export const getArticleByLegacyId = (id: string) => articles.find((a) => a.legacyId === id);

export const articleCategories = [
  "Toate",
  ...Array.from(new Set(articles.map((a) => a.category))),
];
