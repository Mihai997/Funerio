import { ServiceCategory } from "@/types/funeral";
import { slugify } from "@/lib/slug";

export interface ServiceLanding {
  /** Unique key, used in routes */
  slug: string;
  /** URL base, e.g. "/servicii-funerare" or "/servicii/transport-funerar" */
  base: string;
  /** Short label for links */
  label: string;
  /** Heading template, {city} replaced */
  h1: string;
  metaTitle: string;
  metaDescription: string;
  intro: string;
  /** Optional filter over firm service categories */
  category?: ServiceCategory;
  faq: { q: string; a: string }[];
}

export const serviceLandings: ServiceLanding[] = [
  {
    slug: "servicii-funerare",
    base: "/servicii-funerare",
    label: "Servicii funerare",
    h1: "Servicii funerare în {city}",
    metaTitle: "Servicii funerare {city} — firme verificate | Funerio",
    metaDescription:
      "Firme de servicii funerare din {city}, cu prețuri transparente și disponibilitate non-stop. Compară ofertele și cere o ofertă în câteva minute.",
    intro:
      "Compară firmele de servicii funerare din {city} ({county}): prețuri, pachete complete și disponibilitate. Poți suna direct sau poți cere o ofertă, iar firmele te contactează.",
    faq: [
      {
        q: "Cât costă serviciile funerare în {city}?",
        a: "Costul depinde de pachetul ales. Un pachet complet pornește de regulă de la câteva mii de lei și include sicriu, transport, pregătirea decedatului și formalitățile. Cere oferte de la mai multe firme pentru a compara.",
      },
      {
        q: "Ce fac în primele ore după deces în {city}?",
        a: "Se solicită constatarea medicală a decesului, apoi se contactează o firmă de servicii funerare pentru ridicarea și pregătirea decedatului. Firma te poate ajuta și cu actele de la starea civilă.",
      },
      {
        q: "Firmele din {city} sunt disponibile non-stop?",
        a: "Majoritatea firmelor listate pe Funerio oferă disponibilitate 24/7, inclusiv în weekend și de sărbători.",
      },
    ],
  },
  {
    slug: "servicii-funerare-non-stop",
    base: "/servicii-funerare-non-stop",
    label: "Servicii funerare non-stop",
    h1: "Servicii funerare non-stop în {city}",
    metaTitle: "Servicii funerare non-stop {city} 24/7 | Funerio",
    metaDescription:
      "Firme de pompe funebre disponibile non-stop în {city}. Ridicare decedat 24/7, transport funerar și acte. Sună direct sau cere ofertă.",
    intro:
      "Ai nevoie de ajutor imediat în {city}? Firmele de mai jos oferă intervenție non-stop: ridicarea decedatului, transport funerar și sprijin cu formalitățile, la orice oră.",
    faq: [
      {
        q: "Pot suna la orice oră în {city}?",
        a: "Da. Firmele de servicii funerare din {city} listate aici răspund 24 de ore din 24, inclusiv noaptea și în zilele de sărbătoare.",
      },
      {
        q: "Cât durează până ajunge echipa?",
        a: "În mediul urban, timpul mediu de intervenție este de 30-60 de minute de la apel, în funcție de distanță și trafic.",
      },
    ],
  },
  {
    slug: "pompe-funebre",
    base: "/pompe-funebre",
    label: "Pompe funebre",
    h1: "Pompe funebre în {city}",
    metaTitle: "Pompe funebre {city} — prețuri și firme | Funerio",
    metaDescription:
      "Lista firmelor de pompe funebre din {city}, cu servicii, pachete și prețuri de la. Alege firma potrivită și cere o ofertă gratuită.",
    intro:
      "Firme de pompe funebre din {city} ({county}), verificate și cu prețuri afișate transparent. Vezi ce include fiecare pachet și contactează direct firma aleasă.",
    faq: [
      {
        q: "Ce include un pachet de pompe funebre?",
        a: "De obicei: sicriu, transport funerar, pregătirea decedatului, accesorii de ceremonie și sprijin pentru obținerea actelor. Detaliile diferă de la o firmă la alta.",
      },
      {
        q: "Pot compara prețurile firmelor din {city}?",
        a: "Da, fiecare firmă are afișat un preț de pornire calculat din pachetele sale, iar prin formularul de ofertă primești propuneri personalizate.",
      },
    ],
  },
  {
    slug: "transport-funerar",
    base: "/servicii/transport-funerar",
    label: "Transport funerar",
    h1: "Transport funerar în {city}",
    metaTitle: "Transport funerar {city} — preț și firme | Funerio",
    metaDescription:
      "Transport funerar în {city} și în țară: ridicare decedat, dric autorizat, transport intern și internațional. Compară firmele și prețurile.",
    intro:
      "Transport funerar autorizat în {city} și în județul {county}: ridicarea decedatului, transport către capelă, biserică sau cimitir, precum și transport intern și internațional.",
    category: "transport",
    faq: [
      {
        q: "Cât costă transportul funerar în {city}?",
        a: "Transportul local pornește de regulă de la câteva sute de lei, iar transportul între localități se calculează per kilometru. Cere o ofertă pentru distanța ta exactă.",
      },
      {
        q: "Se poate face transport funerar în afara țării?",
        a: "Da, cu sicriu conform normelor de transport internațional și documentație consulară. Firmele specializate se ocupă de întreaga procedură.",
      },
    ],
  },
  {
    slug: "repatriere-decedati",
    base: "/servicii/repatriere-decedati",
    label: "Repatriere decedați",
    h1: "Repatriere decedați în {city}",
    metaTitle: "Repatriere decedați {city} — firme și acte | Funerio",
    metaDescription:
      "Servicii de repatriere decedați către {city}: transport internațional, sicriu de zinc, documentație consulară și formalități complete.",
    intro:
      "Repatrierea unei persoane decedate în străinătate către {city} presupune transport internațional autorizat, sicriu conform normelor și documente consulare. Firmele de mai jos pot prelua întreaga procedură.",
    category: "transport",
    faq: [
      {
        q: "Cât durează o repatriere?",
        a: "În general între 3 și 10 zile, în funcție de țară, de rapiditatea autorităților locale și de documentele necesare.",
      },
      {
        q: "Ce documente sunt necesare pentru repatriere?",
        a: "Certificatul de deces din țara respectivă, pașaportul de mortuar, avizul consular și documentele de îmbălsămare.",
      },
    ],
  },
  {
    slug: "incinerare",
    base: "/servicii/incinerare",
    label: "Incinerare",
    h1: "Incinerare în {city}",
    metaTitle: "Incinerare {city} — preț, acte și firme | Funerio",
    metaDescription:
      "Servicii de incinerare pentru {city}: acte necesare, costuri orientative, urne și ceremonie. Compară firmele care se ocupă de întreaga procedură.",
    intro:
      "Incinerarea este o alternativă la înmormântarea tradițională, aleasă tot mai des în {city}. Firmele de mai jos se ocupă de acte, transport la crematoriu, ceremonie și urnă.",
    category: "crematoriu",
    faq: [
      {
        q: "Ce acte sunt necesare pentru incinerare?",
        a: "Certificatul de deces, adeverința de incinerare eliberată de starea civilă și, uneori, o declarație a familiei privind dorința defunctului.",
      },
      {
        q: "Cât costă o incinerare?",
        a: "Costul total, incluzând transportul, procedura și urna, este de regulă comparabil sau mai mic decât al unei înmormântări tradiționale.",
      },
    ],
  },
];

export const getLanding = (slug: string) => serviceLandings.find((s) => s.slug === slug);

export interface LandingCity {
  city: string;
  county: string;
}

/** Cities covered by generated landing pages (county seats + large towns). */
export const landingCities: LandingCity[] = [
  { city: "București", county: "București" },
  { city: "Cluj-Napoca", county: "Cluj" },
  { city: "Timișoara", county: "Timiș" },
  { city: "Iași", county: "Iași" },
  { city: "Constanța", county: "Constanța" },
  { city: "Craiova", county: "Dolj" },
  { city: "Brașov", county: "Brașov" },
  { city: "Galați", county: "Galați" },
  { city: "Ploiești", county: "Prahova" },
  { city: "Oradea", county: "Bihor" },
  { city: "Brăila", county: "Brăila" },
  { city: "Arad", county: "Arad" },
  { city: "Pitești", county: "Argeș" },
  { city: "Sibiu", county: "Sibiu" },
  { city: "Bacău", county: "Bacău" },
  { city: "Târgu Mureș", county: "Mureș" },
  { city: "Baia Mare", county: "Maramureș" },
  { city: "Buzău", county: "Buzău" },
  { city: "Botoșani", county: "Botoșani" },
  { city: "Satu Mare", county: "Satu Mare" },
  { city: "Râmnicu Vâlcea", county: "Vâlcea" },
  { city: "Suceava", county: "Suceava" },
  { city: "Piatra Neamț", county: "Neamț" },
  { city: "Drobeta-Turnu Severin", county: "Mehedinți" },
  { city: "Târgu Jiu", county: "Gorj" },
  { city: "Târgoviște", county: "Dâmbovița" },
  { city: "Focșani", county: "Vrancea" },
  { city: "Bistrița", county: "Bistrița-Năsăud" },
  { city: "Reșița", county: "Caraș-Severin" },
  { city: "Tulcea", county: "Tulcea" },
  { city: "Slatina", county: "Olt" },
  { city: "Călărași", county: "Călărași" },
  { city: "Alba Iulia", county: "Alba" },
  { city: "Giurgiu", county: "Giurgiu" },
  { city: "Deva", county: "Hunedoara" },
  { city: "Hunedoara", county: "Hunedoara" },
  { city: "Zalău", county: "Sălaj" },
  { city: "Sfântu Gheorghe", county: "Covasna" },
  { city: "Vaslui", county: "Vaslui" },
  { city: "Slobozia", county: "Ialomița" },
  { city: "Alexandria", county: "Teleorman" },
  { city: "Miercurea Ciuc", county: "Harghita" },
];

export const getCityBySlug = (slug: string) =>
  landingCities.find((c) => slugify(c.city) === slug);

export const getCountyBySlug = (slug: string) => {
  const match = landingCities.find((c) => slugify(c.county) === slug);
  return match?.county;
};

export const citiesInCounty = (county: string) =>
  landingCities.filter((c) => c.county === county);
