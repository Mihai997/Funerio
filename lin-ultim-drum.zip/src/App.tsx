import { lazy, Suspense } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import CookieConsent from "./components/CookieConsent";
import DoveLoader from "@/components/brand/DoveLoader";
import PageTransition from "@/components/brand/PageTransition";
import ScrollToTop from "@/components/ScrollToTop";

const Index = lazy(() => import("./pages/Index"));
const FuneralHomesPage = lazy(() => import("./pages/FuneralHomesPage"));
const FuneralHomeDetailPage = lazy(() => import("./pages/FuneralHomeDetailPage"));
const CheckoutPage = lazy(() => import("./pages/CheckoutPage"));
const ContactPage = lazy(() => import("./pages/ContactPage"));
const PartnersPage = lazy(() => import("./pages/PartnersPage"));
const AuthPage = lazy(() => import("./pages/AuthPage"));
const DashboardPage = lazy(() => import("./pages/DashboardPage"));
const ManageServicesPage = lazy(() => import("./pages/ManageServicesPage"));
const AdminPage = lazy(() => import("./pages/AdminPage"));
const AdminDashboardPage = lazy(() => import("./pages/AdminDashboardPage"));
const AdminManageServicesPage = lazy(() => import("./pages/AdminManageServicesPage"));
const AdminApprovalsPage = lazy(() => import("./pages/AdminApprovalsPage"));
const AdminManageUsersPage = lazy(() => import("./pages/AdminManageUsersPage"));
const AdminStatisticsPage = lazy(() => import("./pages/AdminStatisticsPage"));

const AdminManageFuneralHomesPage = lazy(() => import("./pages/AdminManageFuneralHomesPage"));
const SettingsPage = lazy(() => import("./pages/SettingsPage"));
const NotFound = lazy(() => import("./pages/NotFound"));
const MaintenancePage = lazy(() => import("./pages/MaintenancePage"));
const TermsPage = lazy(() => import("./pages/TermsPage"));
const PrivacyPage = lazy(() => import("./pages/PrivacyPage"));
const FAQPage = lazy(() => import("./pages/FAQPage"));
const ReturnPolicyPage = lazy(() => import("./pages/ReturnPolicyPage"));
const GDPRPage = lazy(() => import("./pages/GDPRPage"));
const ArticlesPage = lazy(() => import("./pages/ArticlesPage"));
const ArticlePage = lazy(() => import("./pages/ArticlePage"));
const ServicesIndexPage = lazy(() => import("./pages/ServicesIndexPage"));
const ServiceHubPage = lazy(() => import("./pages/ServiceHubPage"));
const ServiceLandingPage = lazy(() => import("./pages/ServiceLandingPage"));
const FuneralServicesLocationPage = lazy(() => import("./pages/FuneralServicesLocationPage"));
const RequestQuotePage = lazy(() => import("./pages/RequestQuotePage"));

const PageFallback = () => (
  <div className="flex min-h-screen items-center justify-center bg-background">
    <DoveLoader label="Se încarcă pagina" />
  </div>
);

const queryClient = new QueryClient();

// Modul de mentenanță dezactivat - aplicația este accesibilă public
const MAINTENANCE_MODE = false;

const App = () => {
  const hostname = window.location.hostname;
  const isLovablePreview = hostname.includes("lovable.app") || hostname.includes("lovableproject.com");
  const hasAccess = sessionStorage.getItem("maintenance_bypass") === "true" || isLovablePreview;

  if (MAINTENANCE_MODE && !hasAccess) {
    return (
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <PageTransition />
            <ScrollToTop />
            <CookieConsent />
            <Suspense fallback={<PageFallback />}>
              <Routes>
                <Route path="*" element={<MaintenancePage />} />
              </Routes>
            </Suspense>
          </BrowserRouter>
        </TooltipProvider>
      </QueryClientProvider>
    );
  }

  return (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <PageTransition />
        <ScrollToTop />
        <CookieConsent />
        <Suspense fallback={<PageFallback />}>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/firme" element={<FuneralHomesPage />} />
            <Route path="/firme/:id" element={<FuneralHomeDetailPage />} />
            <Route path="/firme/:id/checkout" element={<CheckoutPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/parteneri" element={<PartnersPage />} />
            <Route path="/auth" element={<AuthPage />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/manage-services" element={<ManageServicesPage />} />
            <Route path="/admin" element={<AdminPage />} />
            <Route path="/admin/users" element={<AdminManageUsersPage />} />
            <Route path="/admin/statistici" element={<AdminStatisticsPage />} />
            <Route path="/admin/aprobari" element={<AdminApprovalsPage />} />

            <Route path="/admin/funeral-homes" element={<AdminManageFuneralHomesPage />} />
            <Route path="/admin/funeral-home/:funeralHomeId/dashboard" element={<AdminDashboardPage />} />
            <Route path="/admin/funeral-home/:funeralHomeId/manage-services" element={<AdminManageServicesPage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="/terms" element={<TermsPage />} />
            <Route path="/privacy" element={<PrivacyPage />} />
            <Route path="/faq" element={<FAQPage />} />
            <Route path="/return-policy" element={<ReturnPolicyPage />} />
            <Route path="/gdpr" element={<GDPRPage />} />
            <Route path="/articole" element={<ArticlesPage />} />
            <Route path="/articole/:slug" element={<ArticlePage />} />
            <Route path="/servicii" element={<ServicesIndexPage />} />
            <Route path="/servicii-funerare" element={<ServiceHubPage landingSlug="servicii-funerare" />} />
            <Route path="/servicii-funerare/:slug" element={<FuneralServicesLocationPage />} />
            <Route path="/servicii-funerare-non-stop" element={<ServiceHubPage landingSlug="servicii-funerare-non-stop" />} />
            <Route path="/servicii-funerare-non-stop/:citySlug" element={<ServiceLandingPage landingSlug="servicii-funerare-non-stop" />} />
            <Route path="/pompe-funebre" element={<ServiceHubPage landingSlug="pompe-funebre" />} />
            <Route path="/pompe-funebre/:citySlug" element={<ServiceLandingPage landingSlug="pompe-funebre" />} />
            <Route path="/servicii/:serviceSlug" element={<ServiceHubPage />} />
            <Route path="/servicii/:serviceSlug/:citySlug" element={<ServiceLandingPage />} />
            <Route path="/cere-oferta" element={<RequestQuotePage />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Suspense>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
  );
};

export default App;
