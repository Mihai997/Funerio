export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      call_logs: {
        Row: {
          call_duration: number | null
          call_sid: string | null
          call_status: string
          caller_name: string | null
          caller_phone: string | null
          contact_person: string | null
          created_at: string
          ended_at: string | null
          funeral_home_id: string
          id: string
          outcome: string
          outcome_amount: number | null
          outcome_notes: string | null
          real_phone: string
          recording_url: string | null
          resolved_at: string | null
          resolved_by: string | null
          started_at: string
          tracking_phone: string
        }
        Insert: {
          call_duration?: number | null
          call_sid?: string | null
          call_status?: string
          caller_name?: string | null
          caller_phone?: string | null
          contact_person?: string | null
          created_at?: string
          ended_at?: string | null
          funeral_home_id: string
          id?: string
          outcome?: string
          outcome_amount?: number | null
          outcome_notes?: string | null
          real_phone: string
          recording_url?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          started_at?: string
          tracking_phone: string
        }
        Update: {
          call_duration?: number | null
          call_sid?: string | null
          call_status?: string
          caller_name?: string | null
          caller_phone?: string | null
          contact_person?: string | null
          created_at?: string
          ended_at?: string | null
          funeral_home_id?: string
          id?: string
          outcome?: string
          outcome_amount?: number | null
          outcome_notes?: string | null
          real_phone?: string
          recording_url?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          started_at?: string
          tracking_phone?: string
        }
        Relationships: [
          {
            foreignKeyName: "call_logs_funeral_home_id_fkey"
            columns: ["funeral_home_id"]
            isOneToOne: false
            referencedRelation: "funeral_homes"
            referencedColumns: ["id"]
          },
        ]
      }
      funeral_homes: {
        Row: {
          city: string
          county: string
          created_at: string
          description: string
          email: string
          id: string
          logo: string | null
          name: string
          owner_id: string | null
          phone: string
          price_range: string
          rating: number | null
          review_count: number | null
          subscription_active: boolean
          tracking_phone: string | null
          updated_at: string
        }
        Insert: {
          city: string
          county: string
          created_at?: string
          description: string
          email: string
          id?: string
          logo?: string | null
          name: string
          owner_id?: string | null
          phone: string
          price_range: string
          rating?: number | null
          review_count?: number | null
          subscription_active?: boolean
          tracking_phone?: string | null
          updated_at?: string
        }
        Update: {
          city?: string
          county?: string
          created_at?: string
          description?: string
          email?: string
          id?: string
          logo?: string | null
          name?: string
          owner_id?: string | null
          phone?: string
          price_range?: string
          rating?: number | null
          review_count?: number | null
          subscription_active?: boolean
          tracking_phone?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "funeral_homes_owner_id_fkey"
            columns: ["owner_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      order_items: {
        Row: {
          created_at: string
          id: string
          item_name: string
          item_price: number
          order_id: string
          package_id: string | null
          quantity: number
          service_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          item_name: string
          item_price: number
          order_id: string
          package_id?: string | null
          quantity?: number
          service_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          item_name?: string
          item_price?: number
          order_id?: string
          package_id?: string | null
          quantity?: number
          service_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "order_items_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_items_package_id_fkey"
            columns: ["package_id"]
            isOneToOne: false
            referencedRelation: "packages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_items_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          created_at: string
          customer_email: string
          customer_name: string
          customer_phone: string
          funeral_home_id: string
          id: string
          lead_source: string
          notes: string | null
          order_type: string
          status: string
          total_price: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          customer_email: string
          customer_name: string
          customer_phone: string
          funeral_home_id: string
          id?: string
          lead_source?: string
          notes?: string | null
          order_type?: string
          status?: string
          total_price?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          customer_email?: string
          customer_name?: string
          customer_phone?: string
          funeral_home_id?: string
          id?: string
          lead_source?: string
          notes?: string | null
          order_type?: string
          status?: string
          total_price?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "orders_funeral_home_id_fkey"
            columns: ["funeral_home_id"]
            isOneToOne: false
            referencedRelation: "funeral_homes"
            referencedColumns: ["id"]
          },
        ]
      }
      package_services: {
        Row: {
          package_id: string
          service_id: string
        }
        Insert: {
          package_id: string
          service_id: string
        }
        Update: {
          package_id?: string
          service_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "package_services_package_id_fkey"
            columns: ["package_id"]
            isOneToOne: false
            referencedRelation: "packages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "package_services_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      packages: {
        Row: {
          approval_status: string
          created_at: string
          description: string
          funeral_home_id: string
          id: string
          name: string
          price: number
          rejection_reason: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          updated_at: string
        }
        Insert: {
          approval_status?: string
          created_at?: string
          description: string
          funeral_home_id: string
          id?: string
          name: string
          price: number
          rejection_reason?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          updated_at?: string
        }
        Update: {
          approval_status?: string
          created_at?: string
          description?: string
          funeral_home_id?: string
          id?: string
          name?: string
          price?: number
          rejection_reason?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "packages_funeral_home_id_fkey"
            columns: ["funeral_home_id"]
            isOneToOne: false
            referencedRelation: "funeral_homes"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          full_name: string
          id: string
          phone: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          full_name: string
          id: string
          phone?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          full_name?: string
          id?: string
          phone?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      services: {
        Row: {
          approval_status: string
          category: Database["public"]["Enums"]["service_category"]
          created_at: string
          description: string
          funeral_home_id: string
          id: string
          name: string
          price: number
          price_unit: string
          rejection_reason: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          updated_at: string
        }
        Insert: {
          approval_status?: string
          category: Database["public"]["Enums"]["service_category"]
          created_at?: string
          description: string
          funeral_home_id: string
          id?: string
          name: string
          price: number
          price_unit: string
          rejection_reason?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          updated_at?: string
        }
        Update: {
          approval_status?: string
          category?: Database["public"]["Enums"]["service_category"]
          created_at?: string
          description?: string
          funeral_home_id?: string
          id?: string
          name?: string
          price?: number
          price_unit?: string
          rejection_reason?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "services_funeral_home_id_fkey"
            columns: ["funeral_home_id"]
            isOneToOne: false
            referencedRelation: "funeral_homes"
            referencedColumns: ["id"]
          },
        ]
      }
      site_events: {
        Row: {
          city: string | null
          county: string | null
          created_at: string
          event_name: string
          id: string
          metadata: Json | null
          path: string | null
          session_id: string
        }
        Insert: {
          city?: string | null
          county?: string | null
          created_at?: string
          event_name: string
          id?: string
          metadata?: Json | null
          path?: string | null
          session_id: string
        }
        Update: {
          city?: string | null
          county?: string | null
          created_at?: string
          event_name?: string
          id?: string
          metadata?: Json | null
          path?: string | null
          session_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_roles_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_firm_priority_scores: {
        Args: { _ids: string[] }
        Returns: {
          final_score: number
          funeral_home_id: string
          real_score: number
          total_calls: number
        }[]
      }
      get_firm_scores: {
        Args: never
        Returns: {
          answered_leads: number
          funeral_home_id: string
          funeral_home_name: string
          lost_leads: number
          missed_leads: number
          resolved_leads: number
          speed_points: number
          subscription_active: boolean
          total_leads: number
          unprocessed_leads: number
          valid_leads: number
        }[]
      }
      get_site_funnel: {
        Args: { _from: string; _to: string }
        Returns: {
          event_name: string
          events: number
          sessions: number
        }[]
      }
      get_user_funeral_home: { Args: { _user_id: string }; Returns: string }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "funeral_home_owner"
      service_category:
        | "transport"
        | "sicriu"
        | "flori"
        | "masa"
        | "pomeni"
        | "ceremonie"
        | "documente"
        | "crematoriu"
        | "altele"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "funeral_home_owner"],
      service_category: [
        "transport",
        "sicriu",
        "flori",
        "masa",
        "pomeni",
        "ceremonie",
        "documente",
        "crematoriu",
        "altele",
      ],
    },
  },
} as const
