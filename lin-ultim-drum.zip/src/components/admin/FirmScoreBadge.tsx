import { Star } from "lucide-react";
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { SCORE_TONE_CLASS, type FirmScoreResult } from "@/lib/firmScore";
import { QUALIFIED_LEAD_SECONDS } from "@/lib/leadStatus";

interface FirmScoreBadgeProps {
  score: FirmScoreResult;
  showStars?: boolean;
  className?: string;
}

const pct = (v: number) => `${Math.round(v * 100)}%`;

const FirmScoreBadge = ({ score, showStars = true, className }: FirmScoreBadgeProps) => {
  const content = (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold",
        SCORE_TONE_CLASS[score.tone],
        className
      )}
    >
      {score.insufficientData ? "—" : score.score}
      <span className="font-normal opacity-80">{score.label}</span>
      {showStars && !score.insufficientData && (
        <span className="flex items-center gap-0.5">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star key={i} className={cn("h-3 w-3", i < score.stars ? "fill-current" : "opacity-30")} />
          ))}
        </span>
      )}
    </span>
  );

  return (
    <TooltipProvider delayDuration={150}>
      <Tooltip>
        <TooltipTrigger asChild>
          <span className="cursor-default">{content}</span>
        </TooltipTrigger>
        <TooltipContent className="max-w-xs">
          <div className="space-y-1 text-xs">
            <p className="font-semibold">Detaliu scor (ultimele 90 de zile)</p>
            <p>Lead-uri primite: {score.totalLeads}</p>
            <p>Preluate: {score.answeredLeads} ({pct(score.answerRate)})</p>
            <p>Lead-uri valide (minimum {QUALIFIED_LEAD_SECONDS}s): {score.validLeads}</p>
            <p>Soluționate: {score.resolvedLeads} ({pct(score.resolveRate)})</p>
            <p>Nefinalizate: {score.unprocessedLeads}</p>
            <p>Nepreluate: {score.missedLeads}</p>
            <p>Rapiditate finalizare: {pct(score.speedRate)}</p>
            {score.isNew && <p className="opacity-80">Firmă nouă: pornește de la 80 și trece treptat la scorul real ({score.realScore}) în primele 10 apeluri.</p>}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default FirmScoreBadge;
