import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Building2, Users, TrendingUp, Wallet } from "lucide-react";
import DoveLoader from "@/components/brand/DoveLoader";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { QUALIFIED_LEAD_SECONDS } from "@/lib/leadStatus";

const SUBSCRIPTION_PRICE = 150;
const LEAD_PRICE = 30;
const LEAD_MIN_DURATION = QUALIFIED_LEAD_SECONDS;

interface DailyPoint {
  date: string;
  label: string;
  leads: number;
  revenue: number;
}

const AdminStats = () => {
  const [loading, setLoading] = useState(true);
  const [activeFirms, setActiveFirms] = useState(0);
  const [leadsToday, setLeadsToday] = useState(0);
  const [leads7d, setLeads7d] = useState(0);
  const [leads30d, setLeads30d] = useState(0);
  const [totalCalls30d, setTotalCalls30d] = useState(0);
  const [revenueMonth, setRevenueMonth] = useState(0);
  const [chartData, setChartData] = useState<DailyPoint[]>([]);

  useEffect(() => {
    void loadStats();
  }, []);

  const loadStats = async () => {
    setLoading(true);
    try {
      const now = new Date();
      const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const start7d = new Date(startOfToday);
      start7d.setDate(start7d.getDate() - 6);
      const start30d = new Date(startOfToday);
      start30d.setDate(start30d.getDate() - 29);
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const startOfNextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);

      const [
        firmsRes,
        leadsTodayRes,
        leads7Res,
        leads30Res,
        calls30Res,
        leadsMonthRes,
        leadsTrendRes,
      ] = await Promise.all([
        supabase
          .from("funeral_homes")
          .select("id", { count: "exact", head: true })
          .eq("subscription_active", true),
        supabase
          .from("call_logs")
          .select("id", { count: "exact", head: true })
          .gte("call_duration", LEAD_MIN_DURATION)
          .gte("started_at", startOfToday.toISOString()),
        supabase
          .from("call_logs")
          .select("id", { count: "exact", head: true })
          .gte("call_duration", LEAD_MIN_DURATION)
          .gte("started_at", start7d.toISOString()),
        supabase
          .from("call_logs")
          .select("id", { count: "exact", head: true })
          .gte("call_duration", LEAD_MIN_DURATION)
          .gte("started_at", start30d.toISOString()),
        supabase
          .from("call_logs")
          .select("id", { count: "exact", head: true })
          .gte("started_at", start30d.toISOString()),
        supabase
          .from("call_logs")
          .select("id", { count: "exact", head: true })
          .gte("call_duration", LEAD_MIN_DURATION)
          .gte("started_at", startOfMonth.toISOString())
          .lt("started_at", startOfNextMonth.toISOString()),
        // Trend: fetch all qualifying leads in last 30 days, group client-side
        supabase
          .from("call_logs")
          .select("started_at")
          .gte("started_at", start30d.toISOString())
          .gte("call_duration", LEAD_MIN_DURATION)
          .order("started_at", { ascending: true }),
      ]);

      if (firmsRes.error) throw firmsRes.error;
      if (leadsTodayRes.error) throw leadsTodayRes.error;
      if (leads7Res.error) throw leads7Res.error;
      if (leads30Res.error) throw leads30Res.error;
      if (calls30Res.error) throw calls30Res.error;
      if (leadsMonthRes.error) throw leadsMonthRes.error;
      if (leadsTrendRes.error) throw leadsTrendRes.error;

      const activeFirmsCount = firmsRes.count || 0;
      const leadsThisMonth = leadsMonthRes.count || 0;

      setActiveFirms(activeFirmsCount);
      setLeadsToday(leadsTodayRes.count || 0);
      setLeads7d(leads7Res.count || 0);
      setLeads30d(leads30Res.count || 0);
      setTotalCalls30d(calls30Res.count || 0);
      setRevenueMonth(activeFirmsCount * SUBSCRIPTION_PRICE + leadsThisMonth * LEAD_PRICE);

      // Build daily series for last 30 days
      const days: DailyPoint[] = [];
      const leadsByDay = new Map<string, number>();
      for (const row of leadsTrendRes.data || []) {
        const d = new Date(row.started_at as unknown as string);
        const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
        leadsByDay.set(key, (leadsByDay.get(key) || 0) + 1);
      }
      // Subscription revenue split evenly across days of current month for visualization
      const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
      const dailySubscription = (activeFirmsCount * SUBSCRIPTION_PRICE) / daysInMonth;

      for (let i = 29; i >= 0; i--) {
        const d = new Date(startOfToday);
        d.setDate(d.getDate() - i);
        const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
        const dayLeads = leadsByDay.get(key) || 0;
        const isCurrentMonth =
          d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
        const revenue = dayLeads * LEAD_PRICE + (isCurrentMonth ? dailySubscription : 0);
        days.push({
          date: key,
          label: `${d.getDate()}/${d.getMonth() + 1}`,
          leads: dayLeads,
          revenue: Math.round(revenue),
        });
      }
      setChartData(days);
    } catch (err) {
      console.error("Error loading admin stats:", err);
    } finally {
      setLoading(false);
    }
  };

  const conversionRate =
    totalCalls30d > 0 ? Math.round((leads30d / totalCalls30d) * 100) : 0;

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <DoveLoader size="compact" label="Se încarcă statisticile" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Top stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs sm:text-sm font-medium">Firme active</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl sm:text-3xl font-bold">{activeFirms}</div>
            <p className="text-xs text-muted-foreground mt-1">Cu abonament activ</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs sm:text-sm font-medium">Leads</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl sm:text-3xl font-bold">{leadsToday}</div>
            <p className="text-xs text-muted-foreground mt-1">
              azi · {leads7d} (7z) · {leads30d} (30z)
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs sm:text-sm font-medium">Venituri lună</CardTitle>
            <Wallet className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl sm:text-3xl font-bold">
              {revenueMonth.toLocaleString("ro-RO")} RON
            </div>
            <p className="text-xs text-muted-foreground mt-1">Abonamente + leads</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs sm:text-sm font-medium">Rată conversie</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl sm:text-3xl font-bold">{conversionRate}%</div>
            <p className="text-xs text-muted-foreground mt-1">
              {leads30d} leads / {totalCalls30d} apeluri (30z)
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Trend chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Evoluție venituri & leads — ultimele 30 de zile</CardTitle>
          <CardDescription>
            Leads facturabile (apeluri de minimum {LEAD_MIN_DURATION}s) și venituri zilnice estimate
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[280px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="lds" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--muted-foreground))" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(var(--muted-foreground))" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 11 }}
                  interval="preserveStartEnd"
                  minTickGap={20}
                />
                <YAxis
                  yAxisId="left"
                  tick={{ fontSize: 11 }}
                  width={45}
                />
                <YAxis
                  yAxisId="right"
                  orientation="right"
                  tick={{ fontSize: 11 }}
                  width={35}
                />
                <Tooltip
                  contentStyle={{
                    background: "hsl(var(--popover))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                  formatter={(value: number, name: string) => {
                    if (name === "Venituri") return [`${value.toLocaleString("ro-RO")} RON`, name];
                    return [value, name];
                  }}
                />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Area
                  yAxisId="left"
                  type="monotone"
                  dataKey="revenue"
                  name="Venituri"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                  fill="url(#rev)"
                />
                <Area
                  yAxisId="right"
                  type="monotone"
                  dataKey="leads"
                  name="Leads"
                  stroke="hsl(var(--muted-foreground))"
                  strokeWidth={2}
                  fill="url(#lds)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminStats;
