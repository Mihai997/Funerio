import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowUpDown, Search, Trophy } from "lucide-react";
import { cn } from "@/lib/utils";
import FirmScoreBadge from "./FirmScoreBadge";
import { mapScoreRow, type FirmScoreRow } from "@/lib/firmScore";

type SortKey = "score" | "totalLeads" | "answeredLeads" | "resolvedLeads" | "missedLeads" | "unprocessedLeads" | "funeralHomeName";

const pct = (v: number) => `${Math.round(v * 100)}%`;

const FirmScoreTable = () => {
  const [rows, setRows] = useState<FirmScoreRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("score");
  const [sortAsc, setSortAsc] = useState(false);

  useEffect(() => {
    const load = async () => {
      const { data, error } = await supabase.rpc("get_firm_scores");
      if (!error && data) {
        setRows((data as any[]).map(mapScoreRow));
      }
      setLoading(false);
    };
    load();
  }, []);

  const sorted = useMemo(() => {
    const filtered = rows.filter((r) =>
      r.funeralHomeName.toLowerCase().includes(search.trim().toLowerCase())
    );
    return [...filtered].sort((a, b) => {
      if (sortKey === "funeralHomeName") {
        return sortAsc
          ? a.funeralHomeName.localeCompare(b.funeralHomeName)
          : b.funeralHomeName.localeCompare(a.funeralHomeName);
      }
      const av = a[sortKey] as number;
      const bv = b[sortKey] as number;
      return sortAsc ? av - bv : bv - av;
    });
  }, [rows, search, sortKey, sortAsc]);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortAsc((v) => !v);
    else {
      setSortKey(key);
      setSortAsc(key === "funeralHomeName");
    }
  };

  const SortHead = ({ label, k, className }: { label: string; k: SortKey; className?: string }) => (
    <TableHead className={className}>
      <button
        className="inline-flex items-center gap-1 hover:text-foreground transition-colors"
        onClick={() => toggleSort(k)}
      >
        {label}
        <ArrowUpDown className={cn("h-3 w-3", sortKey === k ? "opacity-100" : "opacity-40")} />
      </button>
    </TableHead>
  );

  const rankOf = (row: FirmScoreRow) => sorted.findIndex((r) => r.funeralHomeId === row.funeralHomeId) + 1;

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="h-5 w-5" />
              Rating firme
            </CardTitle>
            <CardDescription>
              Scor 0–100 pe tot istoricul: preluare 50p, soluționare 35p, procesare 15p. Leadurile eligibile au minimum 40s.
            </CardDescription>
          </div>
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Caută firmă..."
              className="pl-9 rounded-full"
            />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <p className="text-sm text-muted-foreground py-6 text-center">Se încarcă scorurile...</p>
        ) : sorted.length === 0 ? (
          <p className="text-sm text-muted-foreground py-6 text-center">Nicio firmă găsită.</p>
        ) : (
          <>
            {/* Mobile */}
            <div className="md:hidden space-y-3">
              {sorted.map((row, i) => (
                <div
                  key={row.funeralHomeId}
                  className={cn(
                    "rounded-lg border p-3 space-y-2",
                    i < 3 && !row.insufficientData && "border-primary/40 bg-primary/5",
                    !row.insufficientData && row.score < 50 && "border-destructive/40 bg-destructive/5"
                  )}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-semibold truncate">
                        <span className="text-muted-foreground mr-1">#{i + 1}</span>
                        {row.funeralHomeName}
                      </p>
                      {!row.subscriptionActive && (
                        <Badge variant="outline" className="text-[10px] mt-1">Abonament inactiv</Badge>
                      )}
                    </div>
                    <FirmScoreBadge score={row} showStars={false} />
                  </div>
                  <div className="grid grid-cols-2 gap-1 text-xs text-muted-foreground">
                    <span>Primite: <b className="text-foreground">{row.totalLeads}</b></span>
                    <span>Preluate: <b className="text-foreground">{row.answeredLeads}</b> ({pct(row.answerRate)})</span>
                    <span>Soluționate: <b className="text-foreground">{row.resolvedLeads}</b> ({pct(row.resolveRate)})</span>
                    <span>Nepreluate: <b className="text-foreground">{row.missedLeads}</b></span>
                    <span>Nefinalizate: <b className="text-foreground">{row.unprocessedLeads}</b></span>
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop */}
            <div className="hidden md:block overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-10">#</TableHead>
                    <SortHead label="Firmă" k="funeralHomeName" />
                    <SortHead label="Scor" k="score" />
                    <SortHead label="Primite" k="totalLeads" />
                    <SortHead label="Preluate" k="answeredLeads" />
                    <SortHead label="Soluționate" k="resolvedLeads" />
                    <SortHead label="Nepreluate" k="missedLeads" />
                    <SortHead label="Nefinalizate" k="unprocessedLeads" />
                    <TableHead>Rată preluare</TableHead>
                    <TableHead>Rată soluționare</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sorted.map((row, i) => (
                    <TableRow
                      key={row.funeralHomeId}
                      className={cn(
                        i < 3 && !row.insufficientData && "bg-primary/5",
                        !row.insufficientData && row.score < 50 && "bg-destructive/5"
                      )}
                    >
                      <TableCell className="text-muted-foreground">{i + 1}</TableCell>
                      <TableCell className="font-medium">
                        {row.funeralHomeName}
                        {!row.subscriptionActive && (
                          <Badge variant="outline" className="ml-2 text-[10px]">inactiv</Badge>
                        )}
                      </TableCell>
                      <TableCell><FirmScoreBadge score={row} /></TableCell>
                      <TableCell>{row.totalLeads}</TableCell>
                      <TableCell>{row.answeredLeads}</TableCell>
                      <TableCell>{row.resolvedLeads}</TableCell>
                      <TableCell>{row.missedLeads}</TableCell>
                      <TableCell>{row.unprocessedLeads}</TableCell>
                      <TableCell>{pct(row.answerRate)}</TableCell>
                      <TableCell>{pct(row.resolveRate)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default FirmScoreTable;
