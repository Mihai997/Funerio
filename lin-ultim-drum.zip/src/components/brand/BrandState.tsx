import funerioDove from "@/assets/funerio-dove.png";
import { cn } from "@/lib/utils";

type BrandStateProps = {
  title: string;
  description?: string;
  kind?: "empty" | "success";
  className?: string;
  children?: React.ReactNode;
};

const BrandState = ({ title, description, kind = "empty", className, children }: BrandStateProps) => (
  <div className={cn("flex flex-col items-center justify-center px-4 py-8 text-center", className)}>
    <div
      className={cn(
        "mb-4 flex h-20 w-20 items-center justify-center rounded-full border bg-secondary/60",
        kind === "success" && "border-primary/40 bg-primary/10",
      )}
    >
      <img
        src={funerioDove}
        alt=""
        aria-hidden="true"
        className={cn("h-14 w-14 object-contain opacity-70", kind === "success" && "animate-dove-arrival opacity-100")}
      />
    </div>
    <p className="font-semibold text-foreground">{title}</p>
    {description && <p className="mt-1 max-w-sm text-sm text-muted-foreground">{description}</p>}
    {children && <div className="mt-5">{children}</div>}
  </div>
);

export default BrandState;