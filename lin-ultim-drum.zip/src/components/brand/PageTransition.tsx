import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import DoveLoader from "./DoveLoader";

const PageTransition = () => {
  const location = useLocation();
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    setVisible(true);
    const timer = window.setTimeout(() => setVisible(false), 450);
    return () => window.clearTimeout(timer);
  }, [location.pathname]);

  return (
    <div
      aria-hidden={!visible}
      className={`pointer-events-none fixed inset-0 z-[100] flex items-center justify-center bg-background/95 backdrop-blur-sm transition-opacity duration-200 motion-reduce:transition-none ${
        visible ? "opacity-100" : "invisible opacity-0"
      }`}
    >
      <DoveLoader label="Se deschide pagina" />
    </div>
  );
};

export default PageTransition;