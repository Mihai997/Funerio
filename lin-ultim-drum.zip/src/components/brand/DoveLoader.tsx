import funerioDove from "@/assets/funerio-dove.png";
import { cn } from "@/lib/utils";

type DoveLoaderProps = {
  className?: string;
  label?: string;
  size?: "inline" | "compact" | "page";
};

const sizes = {
  inline: "h-5 w-5",
  compact: "h-12 w-12",
  page: "h-24 w-24",
};

const DoveLoader = ({ className, label = "Se încarcă", size = "page" }: DoveLoaderProps) => (
  <div
    className={cn("flex flex-col items-center justify-center gap-3", className)}
    role="status"
    aria-label={label}
  >
    <img
      src={funerioDove}
      alt=""
      aria-hidden="true"
      className={cn("object-contain animate-dove-flight motion-reduce:animate-none", sizes[size])}
    />
    {size === "page" && <span className="text-sm text-muted-foreground">{label}</span>}
  </div>
);

export default DoveLoader;