import { useEffect, useState, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Phone, Clock, Calendar, User, Play, Square, Volume2, Filter, Check, ChevronsUpDown, X } from "lucide-react";
import { format } from "date-fns";
import { ro } from "date-fns/locale";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import DoveLoader from "@/components/brand/DoveLoader";
import BrandState from "@/components/brand/BrandState";
import { getLeadStatus, getLeadStatusKey, LEAD_STATUS_OPTIONS } from "@/lib/leadStatus";

interface CallLog {
  id: string;
  caller_name: string | null;
  caller_phone: string | null;
  tracking_phone: string;
  real_phone: string;
  call_status: string;
  call_duration: number;
  started_at: string;
  ended_at: string | null;
  funeral_home_id: string;
  recording_url: string | null;
  outcome?: string | null;
  funeral_homes?: {
    name: string;
  };
}

interface CallLogsTableProps {
  funeralHomeId?: string;
  showFuneralHomeName?: boolean;
  limit?: number;
  title?: string;
  funeralHomes?: { id: string; name: string }[];
}

const STATUS_OPTIONS = LEAD_STATUS_OPTIONS;

const CallLogsTable = ({ 
  funeralHomeId, 
  showFuneralHomeName = false, 
  limit = 10,
  title = "Apeluri Recente (Leads)",
  funeralHomes = [],
}: CallLogsTableProps) => {
  const [callLogs, setCallLogs] = useState<CallLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ total: 0, answered: 0, avgDuration: 0 });
  const [playingId, setPlayingId] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [filterFuneralHomeIds, setFilterFuneralHomeIds] = useState<string[]>([]);
  const [filterStatuses, setFilterStatuses] = useState<string[]>([]);
  const [firmsPopoverOpen, setFirmsPopoverOpen] = useState(false);
  const [statusPopoverOpen, setStatusPopoverOpen] = useState(false);

  useEffect(() => {
    loadCallLogs();
  }, [funeralHomeId, filterFuneralHomeIds, filterStatuses]);

  const loadCallLogs = async () => {
    try {
      // Build query based on whether we need funeral home names
      let query;
      const fields = "id, caller_name, caller_phone, tracking_phone, real_phone, call_status, call_duration, started_at, ended_at, funeral_home_id, recording_url, outcome";
      if (showFuneralHomeName) {
        query = supabase
          .from("call_logs")
          .select(`${fields}, funeral_homes(name)`)
          .order("started_at", { ascending: false })
          .limit(limit);
      } else {
        query = supabase
          .from("call_logs")
          .select(fields)
          .order("started_at", { ascending: false })
          .limit(limit);
      }

      if (funeralHomeId) {
        query = query.eq("funeral_home_id", funeralHomeId);
      } else if (filterFuneralHomeIds.length > 0) {
        query = query.in("funeral_home_id", filterFuneralHomeIds);
      }

      const { data, error } = await query;

      if (error) throw error;

      const logs = (data || []) as unknown as CallLog[];
      const filteredLogs = filterStatuses.length > 0
        ? logs.filter((log) => filterStatuses.includes(getLeadStatusKey(log)))
        : logs;
      setCallLogs(filteredLogs);

      // Calculate stats
      const total = filteredLogs.length;
      const answered = filteredLogs.filter(log =>
        (log.call_duration ?? 0) > 0
      ).length;
      const durations = filteredLogs.filter(log => log.call_duration > 0).map(log => log.call_duration);
      const avgDuration = durations.length > 0 
        ? durations.reduce((a, b) => a + b, 0) / durations.length 
        : 0;

      setStats({ total, answered, avgDuration });
    } catch (error) {
      console.error("Error loading call logs:", error);
    } finally {
      setLoading(false);
    }
  };

  const formatDuration = (seconds: number) => {
    if (seconds === 0) return "-";
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getStatusBadge = (log: CallLog) => {
    const status = getLeadStatus(log);
    return (
      <Badge variant="outline" className={status.className}>
        {status.label}
      </Badge>
    );
  };

  const getProxiedUrl = (originalUrl: string) => {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    return `${supabaseUrl}/functions/v1/get-recording?url=${encodeURIComponent(originalUrl)}`;
  };

  const togglePlayRecording = (logId: string, url: string) => {
    if (playingId === logId) {
      audioRef.current?.pause();
      audioRef.current = null;
      setPlayingId(null);
    } else {
      if (audioRef.current) {
        audioRef.current.pause();
      }
      const proxiedUrl = getProxiedUrl(url);
      const audio = new Audio(proxiedUrl);
      audio.onended = () => setPlayingId(null);
      audio.play();
      audioRef.current = audio;
      setPlayingId(logId);
    }
  };

  const formatPhone = (phone: string | null) => {
    if (!phone) return "Număr ascuns";
    // Format Romanian phone numbers
    if (phone.startsWith("+40")) {
      return phone.replace("+40", "0");
    }
    return phone;
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Phone className="h-5 w-5" />
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <DoveLoader size="compact" label="Se încarcă apelurile" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Phone className="h-5 w-5" />
          {title}
        </CardTitle>
        <CardDescription className="flex flex-wrap gap-2 md:gap-4 mt-2">
          <span className="flex items-center gap-1">
            <Phone className="h-4 w-4" /> Total: {stats.total}
          </span>
          <span className="flex items-center gap-1">
            <User className="h-4 w-4" /> Răspunse: {stats.answered}
          </span>
          <span className="flex items-center gap-1">
            <Clock className="h-4 w-4" /> Durată medie: {formatDuration(Math.round(stats.avgDuration))}
          </span>
        </CardDescription>
      </CardHeader>
      <CardContent>
        {/* Filters */}
        {funeralHomes.length > 0 && (
          <div className="flex flex-col sm:flex-row gap-2 mb-4">
            {/* Funeral homes multi-select with search */}
            <Popover open={firmsPopoverOpen} onOpenChange={setFirmsPopoverOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  className="w-full sm:w-[240px] justify-between font-normal"
                >
                  <span className="truncate">
                    {filterFuneralHomeIds.length === 0
                      ? "Toate firmele"
                      : `${filterFuneralHomeIds.length} ${filterFuneralHomeIds.length === 1 ? "firmă" : "firme"} selectate`}
                  </span>
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[280px] p-0 bg-popover z-50" align="start">
                <Command>
                  <CommandInput placeholder="Caută firmă..." />
                  <CommandList>
                    <CommandEmpty>Nicio firmă găsită.</CommandEmpty>
                    <CommandGroup>
                      {funeralHomes.map((home) => {
                        const isSelected = filterFuneralHomeIds.includes(home.id);
                        return (
                          <CommandItem
                            key={home.id}
                            value={home.name}
                            onSelect={() => {
                              setFilterFuneralHomeIds((prev) =>
                                isSelected
                                  ? prev.filter((id) => id !== home.id)
                                  : [...prev, home.id]
                              );
                            }}
                          >
                            <Check
                              className={cn(
                                "mr-2 h-4 w-4",
                                isSelected ? "opacity-100" : "opacity-0"
                              )}
                            />
                            <span className="truncate">{home.name}</span>
                          </CommandItem>
                        );
                      })}
                    </CommandGroup>
                  </CommandList>
                </Command>
                {filterFuneralHomeIds.length > 0 && (
                  <div className="border-t p-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full justify-center gap-1 text-muted-foreground"
                      onClick={() => setFilterFuneralHomeIds([])}
                    >
                      <X className="h-3.5 w-3.5" /> Resetează
                    </Button>
                  </div>
                )}
              </PopoverContent>
            </Popover>

            {/* Statuses multi-select */}
            <Popover open={statusPopoverOpen} onOpenChange={setStatusPopoverOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  className="w-full sm:w-[220px] justify-between font-normal"
                >
                  <span className="truncate">
                    {filterStatuses.length === 0
                      ? "Toate statusurile"
                      : `${filterStatuses.length} status${filterStatuses.length === 1 ? "" : "uri"} selectate`}
                  </span>
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[240px] p-0 bg-popover z-50" align="start">
                <ScrollArea className="max-h-72">
                  <div className="p-2 space-y-1">
                    {STATUS_OPTIONS.map((opt) => {
                      const isSelected = filterStatuses.includes(opt.key);
                      return (
                        <label
                          key={opt.key}
                          className="flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-accent cursor-pointer"
                        >
                          <Checkbox
                            checked={isSelected}
                            onCheckedChange={() => {
                              setFilterStatuses((prev) =>
                                isSelected
                                  ? prev.filter((s) => s !== opt.key)
                                  : [...prev, opt.key]
                              );
                            }}
                          />
                          <span className="text-sm">{opt.label}</span>
                        </label>
                      );
                    })}
                  </div>
                </ScrollArea>
                {filterStatuses.length > 0 && (
                  <div className="border-t p-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full justify-center gap-1 text-muted-foreground"
                      onClick={() => setFilterStatuses([])}
                    >
                      <X className="h-3.5 w-3.5" /> Resetează
                    </Button>
                  </div>
                )}
              </PopoverContent>
            </Popover>
          </div>
        )}

        {callLogs.length === 0 ? (
          <BrandState title="Nu există apeluri înregistrate." />
        ) : (
          <>
            {/* Mobile card layout */}
            <div className="md:hidden space-y-3">
              {callLogs.map((log) => (
                <div key={log.id} className="rounded-lg border bg-card p-3 space-y-2">
                  {showFuneralHomeName && log.funeral_homes?.name && (
                    <p className="font-medium text-sm">{log.funeral_homes.name}</p>
                  )}
                  <div className="flex items-center justify-between text-sm">
                     <span className="flex min-w-0 items-center gap-1.5 text-foreground">
                      <Phone className="h-3.5 w-3.5 text-muted-foreground" />
                       <span className="truncate">{log.caller_name || formatPhone(log.caller_phone)}</span>
                    </span>
                    <span className="text-muted-foreground text-xs">
                      {format(new Date(log.started_at), "dd MMM, HH:mm", { locale: ro })}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Clock className="h-3.5 w-3.5" />
                        {formatDuration(log.call_duration)}
                      </span>
                       {getStatusBadge(log)}
                    </div>
                    {log.recording_url ? (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => togglePlayRecording(log.id, log.recording_url!)}
                        className="gap-1 h-7 px-2"
                      >
                        {playingId === log.id ? (
                          <><Square className="h-3.5 w-3.5 text-destructive" /><span className="text-xs">Stop</span></>
                        ) : (
                          <><Play className="h-3.5 w-3.5 text-primary" /><span className="text-xs">Ascultă</span></>
                        )}
                      </Button>
                    ) : null}
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop table layout */}
            <div className="hidden md:block overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    {showFuneralHomeName && <TableHead>Firmă</TableHead>}
                    <TableHead>De la</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Durată</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Înregistrare</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {callLogs.map((log) => (
                    <TableRow key={log.id}>
                      {showFuneralHomeName && (
                        <TableCell className="font-medium">
                          {log.funeral_homes?.name || "-"}
                        </TableCell>
                      )}
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4 text-muted-foreground" />
                           <div><div className="font-medium">{log.caller_name || formatPhone(log.caller_phone)}</div>{log.caller_name && <div className="text-xs text-muted-foreground">{formatPhone(log.caller_phone)}</div>}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          {format(new Date(log.started_at), "dd MMM yyyy, HH:mm", { locale: ro })}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          {formatDuration(log.call_duration)}
                        </div>
                      </TableCell>
                      <TableCell>
                        {getStatusBadge(log)}
                      </TableCell>
                      <TableCell>
                        {log.recording_url ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => togglePlayRecording(log.id, log.recording_url!)}
                            className="gap-1"
                          >
                            {playingId === log.id ? (
                              <><Square className="h-4 w-4 text-destructive" /><span className="text-xs">Stop</span></>
                            ) : (
                              <><Play className="h-4 w-4 text-primary" /><span className="text-xs">Ascultă</span></>
                            )}
                          </Button>
                        ) : (
                          <span className="text-xs text-muted-foreground">-</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default CallLogsTable;
