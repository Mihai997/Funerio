import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { z } from "zod";
import { ArrowLeft, ArrowRight, Building2, Check, FileText, MapPin, Phone, Search, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { romanianCounties } from "@/types/funeral";
import { romanianLocalities } from "@/data/romanianLocalities";
import { ChevronDown, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import DoveLoader from "@/components/brand/DoveLoader";
import BrandState from "@/components/brand/BrandState";
import { trackEvent } from "@/lib/tracking";

const normalizeDiacritics = (value: string) =>
  value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();


type ContactMode = "call" | "quote" | "browse";

const contactSchema = z.object({
  name: z.string().trim().min(2, "Introdu un nume de cel puțin 2 caractere.").max(100, "Numele este prea lung."),
  phone: z.string().trim().transform((value) => value.replace(/[\s\-()]/g, "")).refine(
    (value) => /^(?:\+40|0)\d{9}$/.test(value),
    "Introdu un număr românesc valid, de forma 07xxxxxxxx."
  ),
});

const options: { value: ContactMode; title: string; description: string; icon: typeof Phone }[] = [
  { value: "call", title: "Contactează acum o firmă", description: "Veți fi pus în legătură imediat cu firmele disponibile.", icon: Phone },
  { value: "quote", title: "Cere ofertă", description: "Firmele vă vor contacta pentru a vă face o ofertă.", icon: FileText },
  { value: "browse", title: "Descoperă ofertele", description: "Puteți vedea serviciile firmelor și să contactați firma dorită.", icon: Search },
];

const HomeWizard = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [county, setCounty] = useState("");
  const [countyOpen, setCountyOpen] = useState(false);
  const [city, setCity] = useState("");
  const [mode, setMode] = useState<ContactMode | null>(null);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [cityOpen, setCityOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [firms, setFirms] = useState<{ id: string; name: string; city: string }[]>([]);
  const [firmsLoading, setFirmsLoading] = useState(false);
  const [firmsFromCounty, setFirmsFromCounty] = useState(false);
  const [selectedFirmIds, setSelectedFirmIds] = useState<string[]>([]);
  const [firmsOpen, setFirmsOpen] = useState(false);
  const [success, setSuccess] = useState<{ title: string; description: string } | null>(null);

  useEffect(() => {
    if (step !== 3 || mode !== "quote" || !county || !city) return;
    let cancelled = false;
    setFirmsLoading(true);
    setSelectedFirmIds([]);
    (async () => {
      const base = () => supabase.from("funeral_homes").select("id, name, city").eq("county", county).eq("subscription_active", true).order("rating", { ascending: false }).order("name");
      const { data: local } = await base().eq("city", city);
      let list = local ?? [];
      let fromCounty = false;
      if (list.length === 0) {
        const { data: all } = await base();
        list = all ?? [];
        fromCounty = true;
      }
      if (!cancelled) { setFirms(list); setFirmsFromCounty(fromCounty); setFirmsLoading(false); }
    })();
    return () => { cancelled = true; };
  }, [step, mode, county, city]);

  const toggleFirm = (id: string) => {
    setSelectedFirmIds((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      if (prev.length >= 3) { toast.info("Poți alege maximum 3 firme."); return prev; }
      return [...prev, id];
    });
  };

  const cities = useMemo(() => county ? romanianLocalities[county] ?? [] : [], [county]);
  const selectedOption = options.find((option) => option.value === mode);

  const continueFromMode = () => {
    if (!mode) return;
    if (mode === "browse") {
      trackEvent("view_firms", { county, city, metadata: { source: "wizard" } });
      navigate(`/firme?county=${encodeURIComponent(county)}&city=${encodeURIComponent(city)}`);
      return;
    }
    trackEvent("wizard_step_3", { county, city, metadata: { mode } });
    setStep(3);
  };


  const submit = async () => {
    const parsed = contactSchema.safeParse({ name, phone });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Verifică datele introduse.");
      return;
    }
    if (!mode || mode === "browse") return;
    if (mode === "quote" && selectedFirmIds.length === 0) {
      toast.error("Alege cel puțin o firmă căreia să îi ceri oferta.");
      return;
    }

    setSubmitting(true);
    const functionName = mode === "call" ? "initiate-sequential-call" : "distribute-quote-request";
    const body = mode === "call"
      ? { county, city, userName: parsed.data.name, userPhone: parsed.data.phone }
      : { county, city, customer_name: parsed.data.name, customer_phone: parsed.data.phone, funeral_home_ids: selectedFirmIds };

    try {
      const { data, error } = await supabase.functions.invoke(functionName, { body });
      if (error) {
        let message = "Acțiunea nu a putut fi finalizată. Încearcă din nou.";
        const context = (error as { context?: Response }).context;
        if (context) {
          try {
            const details = await context.json();
            if (typeof details?.error === "string") message = details.error;
          } catch {
            // Keep the safe fallback message when the response is not JSON.
          }
        }
        throw new Error(message);
      }

      const expanded = data?.expandedToCounty === true ? " Pentru că nu am găsit firme în localitatea aleasă, căutarea a fost extinsă la nivelul județului." : "";
      trackEvent("wizard_complete", { county, city, metadata: { mode } });
      if (mode === "call") {
        trackEvent("call_requested", { county, city, metadata: { source: "wizard" } });
        setSuccess({ title: "Apelul a fost inițiat", description: `Vei primi imediat un apel care te va conecta cu firmele disponibile.${expanded}` });
      } else {
        const count = Number(data?.firmsCount) || 0;
        trackEvent("quote_requested", { county, city, metadata: { source: "wizard", firms: count } });
        setSuccess({ title: "Cererea a fost trimisă", description: `${count} ${count === 1 ? "firmă a primit" : "firme au primit"} datele tale și te vor contacta în curând.${expanded}` });
      }

    } catch (error) {
      toast.error(error instanceof Error ? error.message : "A apărut o eroare. Încearcă din nou.");
    } finally {
      setSubmitting(false);
    }
  };

  if (success) {
    return (
      <BrandState kind="success" title={success.title} description={success.description} className="py-8">
        <Button variant="outline" onClick={() => { setSuccess(null); setStep(1); setMode(null); setName(""); setPhone(""); setSelectedFirmIds([]); }}>
          Începe o solicitare nouă
        </Button>
      </BrandState>
    );
  }

  return (
    <Card className="h-[43.25rem] w-full border-border/70 bg-card/95 shadow-xl min-[360px]:h-[36.5rem] sm:h-[38.125rem]">
      <CardContent className="flex h-full flex-col overflow-hidden p-4 min-[360px]:p-5 sm:p-8">
        <div className="mb-7 shrink-0" aria-label={`Pasul ${step} din 3`}>
          <div className="mb-3 flex items-center justify-between text-sm">
            <span className="font-semibold text-foreground">Pasul {step} din 3</span>
            <span className="text-muted-foreground">{step === 1 ? "Locație" : step === 2 ? "Alege opțiunea" : "Date de contact"}</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {[1, 2, 3].map((item) => <div key={item} className={cn("h-2 rounded-full bg-muted", item <= step && "bg-primary")} />)}
          </div>
        </div>

        {step === 1 && (
          <div className="flex min-h-0 flex-1 flex-col">
            <div className="flex min-h-0 flex-1 flex-col overflow-y-auto pr-1">
              <div className="space-y-6 pt-2">
                <div>
                  <h1 className="text-2xl font-bold sm:text-3xl">Unde ai nevoie de ajutor?</h1>
                  <p className="mt-2 text-muted-foreground">Alege județul și localitatea pentru a găsi firme disponibile în apropiere.</p>
                </div>
                <div className="space-y-3">
                  <Label className="text-base font-semibold">Județ</Label>
                  <div className="relative">
                    <span className="pointer-events-none absolute left-3 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-primary/10 text-primary"><MapPin className="h-4 w-4" /></span>
                    <Popover open={countyOpen} onOpenChange={setCountyOpen}>
                      <PopoverTrigger asChild>
                        <Button type="button" variant="outline" role="combobox" aria-label="Județ" className="h-12 w-full justify-between rounded-full pl-14 pr-4 text-base font-normal hover:bg-secondary hover:text-secondary-foreground sm:text-sm">
                          <span className={cn("truncate", !county && "text-muted-foreground")}>{county || "Selectează județul"}</span>
                          <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-[var(--radix-popover-trigger-width)] max-w-[calc(100vw-2rem)] p-0" align="start" collisionPadding={16}>
                        <Command filter={(value, search) => normalizeDiacritics(value).includes(normalizeDiacritics(search)) ? 1 : 0}><CommandInput className="text-base sm:text-sm" placeholder="Caută județul..." /><CommandList className="max-h-[min(18rem,45dvh)]"><CommandEmpty>Județul nu a fost găsit.</CommandEmpty><CommandGroup>
                          {romanianCounties.map((item) => <CommandItem key={item} value={item} onSelect={() => { if (!county) trackEvent("wizard_start", { county: item }); setCounty(item); setCity(""); setCountyOpen(false); }}><Check className={cn("mr-2 h-4 w-4", county === item ? "opacity-100" : "opacity-0")} />{item}</CommandItem>)}
                        </CommandGroup></CommandList></Command>
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
                <div className="space-y-3">
                  <Label className="text-base font-semibold">Localitate</Label>
                  <div className="relative">
                    <span className="pointer-events-none absolute left-3 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-primary/10 text-primary"><Building2 className="h-4 w-4" /></span>
                    <Popover open={cityOpen} onOpenChange={setCityOpen}>
                      <PopoverTrigger asChild>
                        <Button variant="outline" role="combobox" aria-label="Localitate" disabled={!county} className="h-12 w-full justify-between rounded-full pl-14 pr-4 text-base font-normal hover:bg-secondary hover:text-secondary-foreground sm:text-sm">
                          <span className={cn("truncate", !city && "text-muted-foreground")}>{city || "Selectează localitatea"}</span>
                          <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-[var(--radix-popover-trigger-width)] max-w-[calc(100vw-2rem)] p-0" align="start" collisionPadding={16} onOpenAutoFocus={(e) => { if (window.matchMedia("(pointer: coarse)").matches) e.preventDefault(); }}>
                        <Command><CommandInput className="text-base sm:text-sm" placeholder="Caută localitatea..." /><CommandList className="max-h-[min(18rem,45dvh)]"><CommandEmpty>Localitatea nu a fost găsită.</CommandEmpty><CommandGroup>
                          {cities.map((item, index) => <CommandItem key={`${item}-${index}`} value={item} onSelect={() => { setCity(item); setCityOpen(false); }}><Check className={cn("mr-2 h-4 w-4", city === item ? "opacity-100" : "opacity-0")} />{item}</CommandItem>)}
                        </CommandGroup></CommandList></Command>
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
              </div>
            </div>
            <div className="shrink-0 pt-4">
              <Button variant="hero" size="lg" className="h-14 w-full" disabled={!county || !city} onClick={() => { trackEvent("wizard_step_2", { county, city }); setStep(2); }}>
                Continuă <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="flex min-h-0 flex-1 flex-col">
            <div className="flex-1 space-y-5 overflow-y-auto pr-1">
              <div>
                <h2 className="text-2xl font-bold sm:text-3xl">Cum dorești să te ajutăm?</h2>
                <p className="mt-2 text-muted-foreground">Alege varianta potrivită pentru tine.</p>
              </div>
              <div className="space-y-3">
                {options.map((option) => {
                  const Icon = option.icon;
                  return (
                    <Button key={option.value} type="button" variant="outline" onClick={() => setMode(option.value)} className={cn("h-auto min-h-24 w-full justify-start whitespace-normal rounded-lg p-3 text-left hover:border-primary/70 hover:bg-secondary hover:text-secondary-foreground active:bg-secondary sm:p-4", mode === option.value && "border-primary bg-secondary text-secondary-foreground ring-2 ring-primary/20 hover:bg-secondary")}>
                      <span className="mr-4 flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary"><Icon className="h-5 w-5" /></span>
                      <span className="min-w-0"><span className="block font-semibold text-foreground">{option.title}</span><span className="mt-1 block text-sm font-normal text-muted-foreground">{option.description}</span></span>
                      {mode === option.value && <Check className="ml-auto h-5 w-5 shrink-0 text-primary" />}
                    </Button>
                  );
                })}
              </div>
            </div>
            <div className="shrink-0 pt-4">
              <div className="flex gap-3">
                <Button variant="outline" size="lg" className="h-14 px-5" onClick={() => setStep(1)} aria-label="Înapoi la locație"><ArrowLeft className="h-5 w-5" /></Button>
                <Button variant="hero" size="lg" className="h-14 flex-1" disabled={!mode} onClick={continueFromMode}>{mode === "browse" ? "Vezi firmele" : "Continuă"}<ArrowRight className="ml-2 h-5 w-5" /></Button>
              </div>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="flex min-h-0 flex-1 flex-col">
            <div className="flex-1 space-y-4 overflow-y-auto pr-1">
              <h2 className="text-xl font-bold sm:text-2xl">Datele tale de contact</h2>

              {mode === "quote" && (
                <div className="space-y-2">
                  <Label>Firmele cărora le ceri ofertă <span className="font-normal text-muted-foreground">(maximum 3)</span></Label>
                  <Popover open={firmsOpen} onOpenChange={setFirmsOpen}>
                    <PopoverTrigger asChild>
                      <Button variant="outline" role="combobox" aria-label="Alege firmele" disabled={firmsLoading || firms.length === 0} className="min-h-12 h-auto w-full justify-between gap-2 rounded-full px-4 py-2 text-left text-base font-normal hover:bg-secondary hover:text-secondary-foreground sm:text-sm">
                        {selectedFirmIds.length > 0 ? (
                          <span className="flex flex-wrap items-center gap-1.5">
                            {selectedFirmIds.map((id) => {
                              const firm = firms.find((f) => f.id === id);
                              if (!firm) return null;
                              return (
                                <span key={id} className="flex items-center gap-1 rounded-full bg-secondary py-0.5 pl-2.5 pr-1 text-sm font-normal text-secondary-foreground">
                                  <span className="max-w-[9rem] truncate">{firm.name}</span>
                                  <span
                                    role="button"
                                    tabIndex={-1}
                                    aria-label={`Elimină ${firm.name}`}
                                    onClick={(event) => { event.stopPropagation(); toggleFirm(id); }}
                                    className="rounded-full p-0.5 hover:bg-background"
                                  >
                                    <X className="h-3.5 w-3.5" />
                                  </span>
                                </span>
                              );
                            })}
                          </span>
                        ) : (
                          <span className="flex items-center gap-2 truncate text-muted-foreground"><Building2 className="h-4 w-4 shrink-0" />
                            {firmsLoading ? "Se încarcă firmele..." : firms.length === 0 ? "Nu există firme disponibile" : "Alege până la 3 firme"}
                          </span>
                        )}
                        <ChevronDown className="h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </PopoverTrigger>

                    <PopoverContent className="w-[var(--radix-popover-trigger-width)] max-w-[calc(100vw-2rem)] p-0" align="start" collisionPadding={16} onOpenAutoFocus={(e) => { if (window.matchMedia("(pointer: coarse)").matches) e.preventDefault(); }}>
                      <Command filter={(value, search) => normalizeDiacritics(value).includes(normalizeDiacritics(search)) ? 1 : 0}>
                        <CommandInput className="text-base sm:text-sm" placeholder="Caută firma..." />
                        <CommandList className="max-h-[min(16rem,40dvh)]"><CommandEmpty>Firma nu a fost găsită.</CommandEmpty><CommandGroup>
                          {firms.map((firm) => {
                            const checked = selectedFirmIds.includes(firm.id);
                            const blocked = !checked && selectedFirmIds.length >= 3;
                            return (
                              <CommandItem key={firm.id} value={`${firm.name} ${firm.city}`} onSelect={() => toggleFirm(firm.id)} className={cn("py-3", blocked && "opacity-50")}>
                                <Check className={cn("mr-2 h-4 w-4 shrink-0", checked ? "opacity-100 text-primary" : "opacity-0")} />
                                <span className="flex-1 truncate">{firm.name}</span>
                                {firmsFromCounty && <span className="ml-2 text-xs text-muted-foreground">{firm.city}</span>}
                              </CommandItem>
                            );
                          })}
                        </CommandGroup></CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                  {firmsFromCounty && firms.length > 0 && <p className="text-xs text-muted-foreground">Nu am găsit firme în {city}, așa că îți arătăm firmele din județul {county}.</p>}
                </div>
              )}
              <div className="space-y-2"><Label htmlFor="wizard-name">Nume complet</Label><div className="relative"><User className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><Input id="wizard-name" value={name} onChange={(event) => setName(event.target.value)} maxLength={100} autoComplete="name" className="h-12 rounded-full pl-11 text-base sm:text-sm" placeholder="Numele tău" /></div></div>
              <div className="space-y-2"><Label htmlFor="wizard-phone">Număr de telefon</Label><div className="relative"><Phone className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><Input id="wizard-phone" value={phone} onChange={(event) => setPhone(event.target.value)} maxLength={20} inputMode="tel" autoComplete="tel" className="h-12 rounded-full pl-11 text-base sm:text-sm" placeholder="07xx xxx xxx" /></div></div>
            </div>
            <div className="shrink-0 pt-4">
              {submitting ? <DoveLoader size="compact" label={mode === "call" ? "Inițiem apelul" : "Trimitem cererea"} /> : (
                <div className="flex gap-3">
                  <Button variant="outline" size="lg" className="h-14 px-5" onClick={() => setStep(2)} aria-label="Înapoi la opțiuni"><ArrowLeft className="h-5 w-5" /></Button>
                  <Button variant="hero" size="lg" className="h-14 flex-1" onClick={submit}>{mode === "call" ? "Sună-mă acum" : "Trimite cererea"}<ArrowRight className="ml-2 h-5 w-5" /></Button>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default HomeWizard;