import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { trackEvent } from "@/lib/tracking";

const ScrollToTop = () => {
  const { pathname, search } = useLocation();

  useEffect(() => {
    if ("scrollRestoration" in window.history) {
      window.history.scrollRestoration = "manual";
    }
    window.scrollTo({ top: 0, left: 0, behavior: "auto" });
  }, [pathname, search]);

  useEffect(() => {
    if (pathname.startsWith("/admin") || pathname.startsWith("/dashboard")) return;
    trackEvent("page_view", { path: pathname });
  }, [pathname]);

  return null;
};


export default ScrollToTop;
