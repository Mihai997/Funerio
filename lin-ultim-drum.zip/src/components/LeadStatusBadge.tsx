import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { getLeadStatus, type LeadStatusInput } from "@/lib/leadStatus";

interface LeadStatusBadgeProps {
  call: LeadStatusInput;
  className?: string;
}

const LeadStatusBadge = ({ call, className }: LeadStatusBadgeProps) => {
  const status = getLeadStatus(call);
  return (
    <Badge variant="outline" className={cn(status.className, className)}>
      {status.label}
    </Badge>
  );
};

export default LeadStatusBadge;
