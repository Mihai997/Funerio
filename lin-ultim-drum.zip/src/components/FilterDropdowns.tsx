import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { MapPin, ChevronDown, Search } from "lucide-react";
import { FilterState, romanianCounties } from "@/types/funeral";

const normalizeDiacritics = (value: string) =>
  value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

interface FilterDropdownsProps {
  filters: FilterState;
  onCountySelect: (county: string) => void;
  onResetFilters: () => void;
}

const FilterDropdowns = ({ filters, onCountySelect, onResetFilters }: FilterDropdownsProps) => {
  const [locationOpen, setLocationOpen] = useState(false);
  const [search, setSearch] = useState("");

  const filteredCounties = useMemo(() => {
    const query = normalizeDiacritics(search.trim());
    if (!query) return romanianCounties;
    return romanianCounties.filter((county) => normalizeDiacritics(county).includes(query));
  }, [search]);

  const handleCountySelect = (county: string) => {
    onCountySelect(county);
    setLocationOpen(false);
  };

  const locationLabel = filters.county !== "all" ? filters.county : "Locație";
  const filtersActive = filters.county !== "all";

  return (
    <div className="mb-8 flex flex-col items-center gap-3">
      <DropdownMenu
        modal={false}
        open={locationOpen}
        onOpenChange={(open) => {
          setLocationOpen(open);
          if (open) setSearch("");
        }}
      >
        <DropdownMenuTrigger asChild>
          <Button
            variant="outline"
            className="gap-2 h-12 px-6 text-base rounded-full shadow-sm border-border bg-background hover:bg-accent w-full max-w-xs sm:w-auto"
          >
            <MapPin className="h-4 w-4 text-primary shrink-0" />
            <span className="truncate">{locationLabel}</span>
            <ChevronDown className="h-4 w-4 opacity-50 shrink-0" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent
          className="bg-popover z-50 w-[min(20rem,calc(100vw-2rem))] p-0"
          align="center"
        >
          <div className="p-2 pb-0">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Caută județul..."
                className="h-10 rounded-full pl-9 text-sm"
              />
            </div>
          </div>
          <ScrollArea className="h-64">
            <div className="p-2 space-y-0.5">
              <button
                onClick={() => handleCountySelect("all")}
                className={`w-full text-left px-3 py-2 text-sm rounded-md transition-colors ${
                  filters.county === "all"
                    ? "bg-primary text-primary-foreground"
                    : "hover:bg-accent"
                }`}
              >
                Toate județele
              </button>
              {filteredCounties.map(county => (
                <button
                  key={county}
                  onClick={() => handleCountySelect(county)}
                  className={`w-full text-left px-3 py-2 text-sm rounded-md transition-colors ${
                    filters.county === county
                      ? "bg-primary text-primary-foreground"
                      : "hover:bg-accent"
                  }`}
                >
                  {county}
                </button>
              ))}
              {filteredCounties.length === 0 && (
                <p className="px-3 py-2 text-sm text-muted-foreground">Județul nu a fost găsit.</p>
              )}
            </div>
          </ScrollArea>
        </DropdownMenuContent>
      </DropdownMenu>

      {filtersActive && (
        <Button
          variant="secondary"
          onClick={onResetFilters}
          className="gap-2 h-11 px-5 text-sm rounded-full shadow-sm border border-border hover:bg-accent"
        >
          Resetează filtrele
        </Button>
      )}
    </div>
  );
};

export default FilterDropdowns;
