import { Link } from "react-router-dom";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Building2, Phone } from "lucide-react";
import { FuneralHome } from "@/types/funeral";
import { useMemo } from "react";
import { useIsMobile } from "@/hooks/use-mobile";

interface FuneralHomeCardProps {
  funeralHome: FuneralHome;
}

const FuneralHomeCard = ({ funeralHome }: FuneralHomeCardProps) => {
  const isMobile = useIsMobile();

  const minPackagePrice = useMemo(() => {
    if (!funeralHome.packages || funeralHome.packages.length === 0) return null;
    return Math.min(...funeralHome.packages.map((p) => p.price));
  }, [funeralHome.packages]);

  return (
    <Card className="h-full flex flex-col transition-all hover:shadow-lg">
      <CardContent className="pt-6 flex-1">
        <div className="flex items-start gap-4 mb-4">
          <div className="h-20 w-20 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
            <Building2 className="h-10 w-10 text-primary" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-lg mb-1">{funeralHome.name}</h3>
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
              <MapPin className="h-4 w-4" />
              <span>{funeralHome.location.city}, {funeralHome.location.county}</span>
            </div>
            {minPackagePrice !== null && (
              <Badge variant="secondary" className="text-xs">
                Preț de la {minPackagePrice.toLocaleString("ro-RO")} RON
              </Badge>
            )}
          </div>
        </div>
        
        <p className="text-sm text-muted-foreground">{funeralHome.description}</p>
      </CardContent>
      
      <CardFooter className="gap-2">
        {funeralHome.phone && (
          <a href={`tel:${funeralHome.phone}`} className="flex-1">
            <Button variant="hero" className="w-full gap-2" size="sm">
              <Phone className="h-4 w-4" />
              Sună Acum
            </Button>
          </a>
        )}
        <Button variant="outline" className="flex-1" size="sm" asChild>
          <Link to={`/firme/${funeralHome.id}`}>Vezi Detalii</Link>
        </Button>
      </CardFooter>
    </Card>
  );
};

export default FuneralHomeCard;
