import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ArrowUpDown } from "lucide-react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

export type SortOption = "name-asc" | "name-desc" | "rating-desc" | "rating-asc";

interface SortPopupProps {
  sortBy: SortOption;
  onSortChange: (sort: SortOption) => void;
}

const SortPopup = ({ sortBy, onSortChange }: SortPopupProps) => {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <ArrowUpDown className="h-4 w-4" />
          Sortează
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Sortează Firmele</DialogTitle>
        </DialogHeader>
        <RadioGroup value={sortBy} onValueChange={(value) => onSortChange(value as SortOption)} className="space-y-3 py-4">
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="name-asc" id="name-asc" />
            <Label htmlFor="name-asc" className="cursor-pointer">Nume (A-Z)</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="name-desc" id="name-desc" />
            <Label htmlFor="name-desc" className="cursor-pointer">Nume (Z-A)</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="rating-desc" id="rating-desc" />
            <Label htmlFor="rating-desc" className="cursor-pointer">Rating (Descrescător)</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="rating-asc" id="rating-asc" />
            <Label htmlFor="rating-asc" className="cursor-pointer">Rating (Crescător)</Label>
          </div>
        </RadioGroup>
      </DialogContent>
    </Dialog>
  );
};

export default SortPopup;