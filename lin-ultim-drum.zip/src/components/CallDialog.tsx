import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Phone } from "lucide-react";
import DoveLoader from "@/components/brand/DoveLoader";
import { romanianLocalities } from "@/data/romanianLocalities";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { trackEvent } from "@/lib/tracking";


interface CallDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const counties = Object.keys(romanianLocalities).sort();

const CallDialog = ({ open, onOpenChange }: CallDialogProps) => {
  const [county, setCounty] = useState("");
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);
  const [callInitiated, setCallInitiated] = useState(false);

  const handleCall = async () => {
    if (!county) {
      toast.error("Te rugăm să selectezi un județ.");
      return;
    }
    if (!phone) {
      toast.error("Te rugăm să introduci numărul tău de telefon.");
      return;
    }

    const cleanedPhone = phone.replace(/[\s\-\(\)]/g, "");
    const phoneRegex = /^(\+40|0)[0-9]{9}$/;
    if (!phoneRegex.test(cleanedPhone)) {
      toast.error("Număr de telefon invalid. Folosește formatul: 07xxxxxxxx");
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("initiate-sequential-call", {
        body: { county, userPhone: cleanedPhone },
      });

      if (error) throw error;

      if (data?.error) {
        toast.error(data.error);
        return;
      }

      trackEvent("call_requested", { county, metadata: { source: "call_dialog" } });
      setCallInitiated(true);
      toast.success(data.message || "Apelul a fost inițiat cu succes!");
    } catch (err: any) {
      console.error("Error initiating call:", err);
      toast.error("A apărut o eroare la inițierea apelului. Încearcă din nou.");
    } finally {
      setLoading(false);
    }
  };

  const handleClose = (open: boolean) => {
    if (!open) {
      setCounty("");
      setPhone("");
      setCallInitiated(false);
      setLoading(false);
    }
    onOpenChange(open);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Phone className="h-5 w-5 text-primary" />
            Contactează o Firmă
          </DialogTitle>
          <DialogDescription>
            Selectează județul și introdu numărul tău de telefon. Te vom suna și te vom conecta pe rând cu firmele disponibile până când una răspunde.
          </DialogDescription>
        </DialogHeader>

        {callInitiated ? (
          <div className="text-center py-6 space-y-4">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
              <Phone className="h-8 w-8 text-primary animate-pulse" />
            </div>
            <p className="text-lg font-medium">Apel în curs!</p>
            <p className="text-sm text-muted-foreground">
              Vei primi un apel în câteva secunde. Când răspunzi, vei fi conectat automat pe rând cu firmele din {county}.
            </p>
            <Button variant="outline" onClick={() => handleClose(false)} className="mt-4">
              Închide
            </Button>
          </div>
        ) : (
          <div className="space-y-4 pt-2">
            <div className="space-y-2">
              <label className="text-sm font-medium">Județ</label>
              <Select value={county} onValueChange={setCounty}>
                <SelectTrigger>
                  <SelectValue placeholder="Selectează județul" />
                </SelectTrigger>
                <SelectContent className="max-h-60">
                  {counties.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Numărul tău de telefon</label>
              <Input
                type="tel"
                placeholder="07xxxxxxxx"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                maxLength={15}
              />
              <p className="text-xs text-muted-foreground">
                Te vom suna la acest număr și te vom conecta cu firmele disponibile.
              </p>
            </div>

            <Button
              onClick={handleCall}
              disabled={loading || !county || !phone}
              className="w-full"
              size="lg"
            >
              {loading ? (
                <>
                  <DoveLoader size="inline" className="mr-2" label="Se inițiază apelul" />
                  Se inițiază apelul...
                </>
              ) : (
                <>
                  <Phone className="mr-2 h-4 w-4" />
                  Sună
                </>
              )}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default CallDialog;
