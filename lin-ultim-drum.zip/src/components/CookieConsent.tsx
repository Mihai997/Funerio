import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Link } from "react-router-dom";
import { Shield, BarChart3, Megaphone } from "lucide-react";
import { getCookieConsent, setCookieConsent, type CookieConsent as CookieConsentType } from "@/lib/cookies";

const categories = [
  {
    id: "essential" as const,
    icon: Shield,
    title: "Cookie-uri Esențiale",
    description:
      "Necesare pentru funcționarea platformei. Includ stocarea sesiunii de autentificare, preferințele de interfață și starea consimțământului cookie-urilor.",
    always: true,
  },
  {
    id: "analytics" as const,
    icon: BarChart3,
    title: "Cookie-uri Analitice",
    description:
      "Ne ajută să înțelegem cum este utilizat site-ul, ce pagini sunt vizitate cel mai des și cum putem îmbunătăți experiența utilizatorilor.",
    always: false,
  },
  {
    id: "marketing" as const,
    icon: Megaphone,
    title: "Cookie-uri de Marketing",
    description:
      "Folosite pentru a personaliza comunicările și a afișa conținut relevant pe baza intereselor dumneavoastră.",
    always: false,
  },
];

const CookieConsent = () => {
  const [visible, setVisible] = useState(false);
  const [analytics, setAnalytics] = useState(false);
  const [marketing, setMarketing] = useState(false);

  useEffect(() => {
    const consent = getCookieConsent();
    if (!consent) {
      const t = setTimeout(() => setVisible(true), 600);
      return () => clearTimeout(t);
    }
  }, []);

  const save = (consent: CookieConsentType) => {
    setCookieConsent(consent);
    setVisible(false);
  };

  const handleAcceptAll = () => save({ essential: true, analytics: true, marketing: true });
  const handleEssentialOnly = () => save({ essential: true, analytics: false, marketing: false });
  const handleSavePreferences = () => save({ essential: true, analytics, marketing });

  if (!visible) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 animate-in fade-in duration-300">
      <div className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-xl border bg-background shadow-2xl animate-in zoom-in-95 duration-300">
        {/* Header */}
        <div className="p-6 pb-2">
          <h2 className="text-xl font-semibold tracking-tight">
            Setări Cookie-uri
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Respectăm confidențialitatea datelor tale. Alege ce cookie-uri
            permiți pe acest site.
          </p>
        </div>

        {/* Categories */}
        <div className="px-6 py-4 space-y-4">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const checked =
              cat.id === "essential"
                ? true
                : cat.id === "analytics"
                ? analytics
                : marketing;
            const toggle =
              cat.id === "analytics"
                ? setAnalytics
                : cat.id === "marketing"
                ? setMarketing
                : undefined;

            return (
              <div
                key={cat.id}
                className="flex items-start gap-3 rounded-lg border p-4"
              >
                <Icon className="mt-0.5 h-5 w-5 shrink-0 text-muted-foreground" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-medium">{cat.title}</span>
                    {cat.always ? (
                      <span className="text-xs text-muted-foreground italic whitespace-nowrap">
                        Mereu active
                      </span>
                    ) : (
                      <Switch
                        checked={checked}
                        onCheckedChange={toggle}
                        aria-label={cat.title}
                      />
                    )}
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground leading-relaxed">
                    {cat.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Links */}
        <div className="px-6 flex flex-wrap gap-x-3 gap-y-1 text-xs">
          <Link to="/privacy" className="underline text-primary hover:text-primary/80">
            Politica de Confidențialitate
          </Link>
          <span className="text-muted-foreground">•</span>
          <Link to="/gdpr" className="underline text-primary hover:text-primary/80">
            Informații GDPR
          </Link>
          <span className="text-muted-foreground">•</span>
          <Link to="/terms" className="underline text-primary hover:text-primary/80">
            Termeni și Condiții
          </Link>
        </div>

        {/* Buttons */}
        <div className="p-6 pt-4 flex flex-col sm:flex-row gap-2">
          <Button onClick={handleAcceptAll} className="flex-1">
            Acceptă toate
          </Button>
          <Button onClick={handleSavePreferences} variant="secondary" className="flex-1">
            Salvează preferințele
          </Button>
          <Button onClick={handleEssentialOnly} variant="outline" className="flex-1">
            Doar esențiale
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CookieConsent;
