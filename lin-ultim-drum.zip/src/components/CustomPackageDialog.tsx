import { useMemo, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, Loader2, Send } from "lucide-react";
import { FuneralHome, serviceCategories } from "@/types/funeral";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface CustomPackageDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  funeralHome: FuneralHome;
}

const CustomPackageDialog = ({ open, onOpenChange, funeralHome }: CustomPackageDialogProps) => {
  const [step, setStep] = useState<1 | 2>(1);
  const [selected, setSelected] = useState<string[]>([]);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const grouped = useMemo(
    () =>
      serviceCategories
        .map((c) => ({ ...c, services: funeralHome.services.filter((s) => s.category === c.value) }))
        .filter((c) => c.services.length > 0),
    [funeralHome.services],
  );

  const reset = () => {
    setStep(1);
    setSelected([]);
    setName("");
    setPhone("");
    setEmail("");
    setNotes("");
  };

  const handleOpenChange = (value: boolean) => {
    if (!value) reset();
    onOpenChange(value);
  };

  const toggle = (id: string) =>
    setSelected((prev) => (prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]));

  const handleSubmit = async () => {
    if (name.trim().length < 2) {
      toast.error("Introdu numele tău");
      return;
    }
    if (!/^(\+4|0)[0-9]{9}$/.test(phone.replace(/\s/g, ""))) {
      toast.error("Introdu un număr de telefon valid");
      return;
    }
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error("Introdu o adresă de email validă");
      return;
    }

    setSubmitting(true);
    try {
      const { error } = await supabase.functions.invoke("submit-custom-package", {
        body: {
          funeralHomeId: funeralHome.id,
          customerName: name.trim(),
          customerPhone: phone.replace(/\s/g, ""),
          customerEmail: email.trim() || undefined,
          notes: notes.trim() || undefined,
          serviceIds: selected,
        },
      });
      if (error) throw error;

      toast.success("Cererea a fost trimisă. Firma te va contacta în curând.");
      handleOpenChange(false);
    } catch (err) {
      console.error("Error submitting custom package:", err);
      toast.error("A apărut o eroare la trimiterea cererii");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-2xl h-[90vh] sm:h-[80vh] flex flex-col p-0 gap-0">
        <DialogHeader className="p-4 sm:p-6 pb-3 shrink-0 text-left">
          <DialogTitle className="text-xl">
            {step === 1 ? "Pachet personalizat" : "Datele tale de contact"}
          </DialogTitle>
          <DialogDescription>
            {step === 1
              ? `Alege serviciile de care ai nevoie de la ${funeralHome.name}. Prețul final îți va fi comunicat de firmă.`
              : "Lăsăm firma să te contacteze cu o ofertă pentru serviciile alese."}
          </DialogDescription>
        </DialogHeader>

        <Separator />

        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {step === 1 ? (
            grouped.map((category) => (
              <div key={category.value} className="space-y-3">
                <h3 className="font-semibold text-base">{category.label}</h3>
                <div className="space-y-2">
                  {category.services.map((service) => {
                    const checked = selected.includes(service.id);
                    return (
                      <label
                        key={service.id}
                        className={`flex items-start gap-3 rounded-2xl border p-3 cursor-pointer transition-colors ${
                          checked ? "border-primary bg-primary/5" : "hover:bg-muted/50"
                        }`}
                      >
                        <Checkbox
                          checked={checked}
                          onCheckedChange={() => toggle(service.id)}
                          className="mt-1 h-5 w-5"
                        />
                        <span className="flex-1 min-w-0">
                          <span className="flex items-start justify-between gap-2">
                            <span className="font-medium text-base leading-snug">{service.name}</span>
                            <Badge variant="secondary" className="shrink-0">
                              {service.price.toLocaleString("ro-RO")} RON
                            </Badge>
                          </span>
                          <span className="block text-sm text-muted-foreground line-clamp-2 mt-1">
                            {service.description}
                          </span>
                        </span>
                      </label>
                    );
                  })}
                </div>
              </div>
            ))
          ) : (
            <div className="space-y-4">
              <div className="rounded-2xl bg-muted/50 p-4">
                <p className="font-medium text-sm mb-2">Servicii alese ({selected.length})</p>
                <ul className="space-y-1">
                  {selected.map((id) => {
                    const service = funeralHome.services.find((s) => s.id === id);
                    return service ? (
                      <li key={id} className="flex items-center gap-2 text-sm text-muted-foreground">
                        <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                        {service.name}
                      </li>
                    ) : null;
                  })}
                </ul>
              </div>

              <div className="space-y-2">
                <Label htmlFor="cp-name">Nume complet *</Label>
                <Input
                  id="cp-name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Numele tău"
                  className="h-12 rounded-full text-base"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cp-phone">Telefon *</Label>
                <Input
                  id="cp-phone"
                  type="tel"
                  inputMode="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="07XXXXXXXX"
                  className="h-12 rounded-full text-base"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cp-email">Email (opțional)</Label>
                <Input
                  id="cp-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="email@exemplu.ro"
                  className="h-12 rounded-full text-base"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cp-notes">Detalii suplimentare</Label>
                <Textarea
                  id="cp-notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Localitate, dată, alte cerințe..."
                  rows={4}
                  className="rounded-2xl text-base"
                />
              </div>
            </div>
          )}
        </div>

        <Separator />

        <div className="shrink-0 p-4 sm:p-6 flex items-center gap-3">
          {step === 1 ? (
            <>
              <span className="text-sm text-muted-foreground flex-1">
                {selected.length} servicii selectate
              </span>
              <Button
                className="rounded-full"
                size="lg"
                disabled={selected.length === 0}
                onClick={() => setStep(2)}
              >
                Cere ofertă
              </Button>
            </>
          ) : (
            <>
              <Button
                variant="outline"
                size="lg"
                className="rounded-full"
                onClick={() => setStep(1)}
                disabled={submitting}
              >
                <ArrowLeft className="h-4 w-4" />
                Înapoi
              </Button>
              <Button className="rounded-full flex-1" size="lg" onClick={handleSubmit} disabled={submitting}>
                {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                Trimite cererea
              </Button>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default CustomPackageDialog;
