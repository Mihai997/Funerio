import { Badge } from "@/components/ui/badge";
import { Clock, CheckCircle2, XCircle } from "lucide-react";

export type ApprovalStatus = "pending" | "approved" | "rejected";

export const ApprovalBadge = ({ status }: { status?: string | null }) => {
  if (status === "approved") {
    return (
      <Badge className="text-xs gap-1 bg-primary/15 text-primary border-primary/30 hover:bg-primary/15" variant="outline">
        <CheckCircle2 className="h-3 w-3" /> Aprobat
      </Badge>
    );
  }
  if (status === "rejected") {
    return (
      <Badge variant="destructive" className="text-xs gap-1">
        <XCircle className="h-3 w-3" /> Refuzat
      </Badge>
    );
  }
  return (
    <Badge variant="outline" className="text-xs gap-1 bg-accent text-accent-foreground">
      <Clock className="h-3 w-3" /> În așteptare
    </Badge>
  );
};

export const RejectionReason = ({ status, reason }: { status?: string | null; reason?: string | null }) =>
  status === "rejected" && reason ? (
    <p className="text-xs text-destructive mt-1">
      <span className="font-semibold">Motiv refuz:</span> {reason}
    </p>
  ) : null;
