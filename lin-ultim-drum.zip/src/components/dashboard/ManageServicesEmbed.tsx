import { useEffect, useState, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, Package, Search, ChevronDown } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { serviceCategories, ServiceCategory } from "@/types/funeral";
import DoveLoader from "@/components/brand/DoveLoader";
import BrandState from "@/components/brand/BrandState";
import { ApprovalBadge, RejectionReason } from "@/components/dashboard/ApprovalBadge";

interface Service {
  id: string;
  name: string;
  description: string;
  price: number;
  price_unit: string;
  category: ServiceCategory;
  approval_status?: string | null;
  rejection_reason?: string | null;
}

interface PackageData {
  id: string;
  name: string;
  description: string;
  price: number;
  approval_status?: string | null;
  rejection_reason?: string | null;
}

interface Props {
  funeralHomeId: string;
}

const ManageServicesEmbed = ({ funeralHomeId }: Props) => {
  const [loading, setLoading] = useState(true);
  const [services, setServices] = useState<Service[]>([]);
  const [packages, setPackages] = useState<PackageData[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterCategories, setFilterCategories] = useState<string[]>([]);

  // Service form state
  const [isAddServiceOpen, setIsAddServiceOpen] = useState(false);
  const [editingService, setEditingService] = useState<Service | null>(null);
  const [deleteServiceId, setDeleteServiceId] = useState<string | null>(null);
  const [serviceName, setServiceName] = useState("");
  const [serviceDescription, setServiceDescription] = useState("");
  const [servicePrice, setServicePrice] = useState("");
  const [servicePriceUnit, setServicePriceUnit] = useState("Serviciu");
  const [serviceCategory, setServiceCategory] = useState<ServiceCategory>("altele");

  // Package form state
  const [isAddPackageOpen, setIsAddPackageOpen] = useState(false);
  const [editingPackage, setEditingPackage] = useState<PackageData | null>(null);
  const [deletePackageId, setDeletePackageId] = useState<string | null>(null);
  const [packageName, setPackageName] = useState("");
  const [packageDescription, setPackageDescription] = useState("");
  const [packagePrice, setPackagePrice] = useState("");
  const [selectedServiceIds, setSelectedServiceIds] = useState<string[]>([]);
  const [packageServices, setPackageServices] = useState<{ [packageId: string]: string[] }>({});

  useEffect(() => {
    loadData();
  }, [funeralHomeId]);

  const loadData = async () => {
    try {
      const [servicesRes, packagesRes] = await Promise.all([
        supabase.from("services").select("*").eq("funeral_home_id", funeralHomeId).order("name"),
        supabase.from("packages").select("*").eq("funeral_home_id", funeralHomeId).order("name"),
      ]);

      if (servicesRes.error) throw servicesRes.error;
      if (packagesRes.error) throw packagesRes.error;

      setServices((servicesRes.data || []) as Service[]);
      setPackages(packagesRes.data || []);

      // Load package_services
      const { data: psData } = await supabase
        .from("package_services")
        .select("package_id, service_id")
        .in("package_id", (packagesRes.data || []).map(p => p.id));

      const psMap: { [k: string]: string[] } = {};
      (psData || []).forEach(ps => {
        if (!psMap[ps.package_id]) psMap[ps.package_id] = [];
        psMap[ps.package_id].push(ps.service_id);
      });
      setPackageServices(psMap);

      setLoading(false);
    } catch (error) {
      console.error("Error loading data:", error);
      toast.error("Eroare la încărcarea datelor.");
      setLoading(false);
    }
  };

  const filteredServices = useMemo(() => {
    return services.filter(s => {
      const matchesSearch = s.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = filterCategories.length === 0 || filterCategories.includes(s.category);
      return matchesSearch && matchesCategory;
    });
  }, [services, searchQuery, filterCategories]);

  // Service CRUD
  const resetServiceForm = () => {
    setServiceName("");
    setServiceDescription("");
    setServicePrice("");
    setServicePriceUnit("Serviciu");
    setServiceCategory("altele");
    setEditingService(null);
  };

  const handleSaveService = async () => {
    if (!serviceName || !servicePrice) {
      toast.error("Completați numele și prețul.");
      return;
    }

    try {
      if (editingService) {
        const { error } = await supabase.from("services").update({
          name: serviceName,
          description: serviceDescription,
          price: parseFloat(servicePrice),
          price_unit: servicePriceUnit,
          category: serviceCategory,
        }).eq("id", editingService.id);
        if (error) throw error;
        toast.success("Serviciu trimis spre aprobare.");
      } else {
        const { error } = await supabase.from("services").insert({
          funeral_home_id: funeralHomeId,
          name: serviceName,
          description: serviceDescription,
          price: parseFloat(servicePrice),
          price_unit: servicePriceUnit,
          category: serviceCategory,
        });
        if (error) throw error;
        toast.success("Serviciu trimis spre aprobare.");
      }
      resetServiceForm();
      setIsAddServiceOpen(false);
      loadData();
    } catch (error) {
      console.error(error);
      toast.error("Eroare la salvarea serviciului.");
    }
  };

  const handleDeleteService = async () => {
    if (!deleteServiceId) return;
    try {
      const { error } = await supabase.from("services").delete().eq("id", deleteServiceId);
      if (error) throw error;
      toast.success("Serviciu șters!");
      setDeleteServiceId(null);
      loadData();
    } catch (error) {
      console.error(error);
      toast.error("Eroare la ștergerea serviciului.");
    }
  };

  const openEditService = (service: Service) => {
    setEditingService(service);
    setServiceName(service.name);
    setServiceDescription(service.description);
    setServicePrice(service.price.toString());
    setServicePriceUnit(service.price_unit);
    setServiceCategory(service.category);
    setIsAddServiceOpen(true);
  };

  // Package CRUD
  const resetPackageForm = () => {
    setPackageName("");
    setPackageDescription("");
    setPackagePrice("");
    setSelectedServiceIds([]);
    setEditingPackage(null);
  };

  const handleSavePackage = async () => {
    if (!packageName || !packagePrice) {
      toast.error("Completați numele și prețul.");
      return;
    }

    try {
      if (editingPackage) {
        const { error } = await supabase.from("packages").update({
          name: packageName,
          description: packageDescription,
          price: parseFloat(packagePrice),
        }).eq("id", editingPackage.id);
        if (error) throw error;

        // Update package_services
        await supabase.from("package_services").delete().eq("package_id", editingPackage.id);
        if (selectedServiceIds.length > 0) {
          await supabase.from("package_services").insert(
            selectedServiceIds.map(sid => ({ package_id: editingPackage.id, service_id: sid }))
          );
        }
        toast.success("Pachet trimis spre aprobare.");
      } else {
        const { data, error } = await supabase.from("packages").insert({
          funeral_home_id: funeralHomeId,
          name: packageName,
          description: packageDescription,
          price: parseFloat(packagePrice),
        }).select().single();
        if (error) throw error;

        if (selectedServiceIds.length > 0 && data) {
          await supabase.from("package_services").insert(
            selectedServiceIds.map(sid => ({ package_id: data.id, service_id: sid }))
          );
        }
        toast.success("Pachet trimis spre aprobare.");
      }
      resetPackageForm();
      setIsAddPackageOpen(false);
      loadData();
    } catch (error) {
      console.error(error);
      toast.error("Eroare la salvarea pachetului.");
    }
  };

  const handleDeletePackage = async () => {
    if (!deletePackageId) return;
    try {
      await supabase.from("package_services").delete().eq("package_id", deletePackageId);
      const { error } = await supabase.from("packages").delete().eq("id", deletePackageId);
      if (error) throw error;
      toast.success("Pachet șters!");
      setDeletePackageId(null);
      loadData();
    } catch (error) {
      console.error(error);
      toast.error("Eroare la ștergerea pachetului.");
    }
  };

  const openEditPackage = (pkg: PackageData) => {
    setEditingPackage(pkg);
    setPackageName(pkg.name);
    setPackageDescription(pkg.description);
    setPackagePrice(pkg.price.toString());
    setSelectedServiceIds(packageServices[pkg.id] || []);
    setIsAddPackageOpen(true);
  };

  const getServicesTotalForPackage = (pkgId: string) => {
    const svcIds = packageServices[pkgId] || [];
    return svcIds.reduce((sum, id) => {
      const svc = services.find(s => s.id === id);
      return sum + (svc?.price || 0);
    }, 0);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <DoveLoader size="compact" label="Se încarcă serviciile" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <p className="text-sm text-muted-foreground mb-4 rounded-2xl border bg-muted/40 px-4 py-3">Serviciile și pachetele noi sau modificate sunt verificate de echipa Funerio înainte de a apărea pe site.</p>
      <Tabs defaultValue="services">
        <TabsList className="w-full grid grid-cols-2">
          <TabsTrigger value="services">Servicii ({services.length})</TabsTrigger>
          <TabsTrigger value="packages">Pachete ({packages.length})</TabsTrigger>
        </TabsList>

        {/* Services Tab */}
        <TabsContent value="services" className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
            <div className="flex flex-1 gap-2 w-full sm:w-auto">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Caută servicii..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 rounded-full"
                />
              </div>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-[180px] rounded-full justify-between font-normal">
                    <span className="truncate">
                      {filterCategories.length === 0
                        ? "Toate categoriile"
                        : filterCategories.length === 1
                          ? serviceCategories.find(c => c.value === filterCategories[0])?.label
                          : `${filterCategories.length} selectate`}
                    </span>
                    <ChevronDown className="h-4 w-4 opacity-50 ml-2 shrink-0" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-[240px] p-2" align="start">
                  <div className="flex items-center justify-between px-2 py-1 mb-1">
                    <span className="text-xs font-medium text-muted-foreground">Categorii</span>
                    {filterCategories.length > 0 && (
                      <Button variant="ghost" size="sm" className="h-6 px-2 text-xs" onClick={() => setFilterCategories([])}>
                        Resetează
                      </Button>
                    )}
                  </div>
                  <div className="max-h-64 overflow-y-auto space-y-1">
                    {serviceCategories.map(cat => {
                      const checked = filterCategories.includes(cat.value);
                      return (
                        <label key={cat.value} className="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-accent cursor-pointer">
                          <Checkbox
                            checked={checked}
                            onCheckedChange={(v) => {
                              setFilterCategories(prev =>
                                v ? [...prev, cat.value] : prev.filter(c => c !== cat.value)
                              );
                            }}
                          />
                          <span className="text-sm">{cat.label}</span>
                        </label>
                      );
                    })}
                  </div>
                </PopoverContent>
              </Popover>
            </div>
            <Dialog open={isAddServiceOpen} onOpenChange={(open) => { setIsAddServiceOpen(open); if (!open) resetServiceForm(); }}>
              <DialogTrigger asChild>
                <Button className="gap-2 w-full sm:w-auto">
                  <Plus className="h-4 w-4" />
                  Adaugă Serviciu
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{editingService ? "Editează Serviciu" : "Adaugă Serviciu Nou"}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div><Label>Nume</Label><Input value={serviceName} onChange={e => setServiceName(e.target.value)} className="rounded-full" /></div>
                  <div><Label>Descriere</Label><Textarea value={serviceDescription} onChange={e => setServiceDescription(e.target.value)} /></div>
                  <div className="grid grid-cols-2 gap-4">
                    <div><Label>Preț (RON)</Label><Input type="number" value={servicePrice} onChange={e => setServicePrice(e.target.value)} className="rounded-full" /></div>
                    <div><Label>Unitate</Label>
                      <Select value={servicePriceUnit} onValueChange={setServicePriceUnit}>
                        <SelectTrigger className="rounded-full"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Bucata">Bucată</SelectItem>
                          <SelectItem value="Serviciu">Serviciu</SelectItem>
                          <SelectItem value="Persoana">Persoană</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <Label>Categorie</Label>
                    <Select value={serviceCategory} onValueChange={v => setServiceCategory(v as ServiceCategory)}>
                      <SelectTrigger className="rounded-full"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {serviceCategories.map(cat => (
                          <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={handleSaveService}>{editingService ? "Salvează" : "Adaugă"}</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          {filteredServices.length === 0 ? (
            <Card>
              <CardContent>
                <BrandState title={services.length === 0 ? "Nu există servicii. Adăugați primul serviciu." : "Niciun rezultat pentru filtrele selectate."} />
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-2">
              {filteredServices.map(service => (
                <Card key={service.id}>
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-medium truncate">{service.name}</p>
                        <Badge variant="secondary" className="text-xs">
                          {serviceCategories.find(c => c.value === service.category)?.label}
                        </Badge>
                        <ApprovalBadge status={service.approval_status} />
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{service.price.toFixed(0)} RON / {service.price_unit}</p>
                      <RejectionReason status={service.approval_status} reason={service.rejection_reason} />
                    </div>
                    <div className="flex gap-1 ml-2">
                      <Button variant="ghost" size="icon" onClick={() => openEditService(service)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => setDeleteServiceId(service.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Packages Tab */}
        <TabsContent value="packages" className="space-y-4">
          <div className="flex justify-end">
            <Dialog open={isAddPackageOpen} onOpenChange={(open) => { setIsAddPackageOpen(open); if (!open) resetPackageForm(); }}>
              <DialogTrigger asChild>
                <Button className="gap-2 w-full sm:w-auto">
                  <Plus className="h-4 w-4" />
                  Adaugă Pachet
                </Button>
              </DialogTrigger>
              <DialogContent className="max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>{editingPackage ? "Editează Pachet" : "Adaugă Pachet Nou"}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div><Label>Nume</Label><Input value={packageName} onChange={e => setPackageName(e.target.value)} className="rounded-full" /></div>
                  <div><Label>Descriere</Label><Textarea value={packageDescription} onChange={e => setPackageDescription(e.target.value)} /></div>
                  <div><Label>Preț Pachet (RON)</Label><Input type="number" value={packagePrice} onChange={e => setPackagePrice(e.target.value)} className="rounded-full" /></div>
                  {services.length > 0 && (
                    <div>
                      <Label className="mb-2 block">Servicii Incluse</Label>
                      <div className="max-h-[200px] overflow-y-auto space-y-2 border rounded-lg p-3">
                        {services.map(s => (
                          <label key={s.id} className="flex items-center gap-2 cursor-pointer">
                            <Checkbox
                              checked={selectedServiceIds.includes(s.id)}
                              onCheckedChange={(checked) => {
                                setSelectedServiceIds(prev =>
                                  checked ? [...prev, s.id] : prev.filter(id => id !== s.id)
                                );
                              }}
                            />
                            <span className="text-sm flex-1">{s.name}</span>
                            <span className="text-xs text-muted-foreground">{s.price.toFixed(0)} RON</span>
                          </label>
                        ))}
                      </div>
                      {selectedServiceIds.length > 0 && (
                        <p className="text-xs text-muted-foreground mt-1">
                          Total servicii: {selectedServiceIds.reduce((sum, id) => sum + (services.find(s => s.id === id)?.price || 0), 0).toFixed(0)} RON
                        </p>
                      )}
                    </div>
                  )}
                </div>
                <DialogFooter>
                  <Button onClick={handleSavePackage}>{editingPackage ? "Salvează" : "Adaugă"}</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          {packages.length === 0 ? (
            <Card>
              <CardContent>
                <BrandState title="Nu există pachete. Adăugați primul pachet." />
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {packages.map(pkg => {
                const servicesTotal = getServicesTotalForPackage(pkg.id);
                const savings = servicesTotal > 0 ? servicesTotal - pkg.price : 0;
                const svcIds = packageServices[pkg.id] || [];

                return (
                  <Card key={pkg.id}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <Package className="h-4 w-4 text-primary" />
                            <p className="font-semibold">{pkg.name}</p>
                            <ApprovalBadge status={pkg.approval_status} />
                          </div>
                          <RejectionReason status={pkg.approval_status} reason={pkg.rejection_reason} />
                          <p className="text-sm text-muted-foreground mt-1">{pkg.description}</p>
                          <div className="flex items-center gap-3 mt-2">
                            <p className="font-bold text-lg">{pkg.price.toFixed(0)} RON</p>
                            {savings > 0 && (
                              <Badge variant="default" className="text-xs">
                                Economie: {savings.toFixed(0)} RON
                              </Badge>
                            )}
                          </div>
                          {svcIds.length > 0 && (
                            <div className="mt-2 flex flex-wrap gap-1">
                              {svcIds.map(sid => {
                                const svc = services.find(s => s.id === sid);
                                return svc ? (
                                  <Badge key={sid} variant="outline" className="text-xs">
                                    {svc.name}
                                  </Badge>
                                ) : null;
                              })}
                            </div>
                          )}
                        </div>
                        <div className="flex gap-1 ml-2">
                          <Button variant="ghost" size="icon" onClick={() => openEditPackage(pkg)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => setDeletePackageId(pkg.id)}>
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Delete service confirmation */}
      <AlertDialog open={!!deleteServiceId} onOpenChange={() => setDeleteServiceId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Ștergeți serviciul?</AlertDialogTitle>
            <AlertDialogDescription>Această acțiune nu poate fi anulată.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Anulează</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteService}>Șterge</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete package confirmation */}
      <AlertDialog open={!!deletePackageId} onOpenChange={() => setDeletePackageId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Ștergeți pachetul?</AlertDialogTitle>
            <AlertDialogDescription>Această acțiune nu poate fi anulată.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Anulează</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeletePackage}>Șterge</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default ManageServicesEmbed;
