import { useEffect, useState } from "react";
import { subDays } from "date-fns";
import { Gauge, Lightbulb } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { computeFirmScore, FirmScoreResult, SCORE_WINDOW_DAYS, MIN_LEADS_FOR_SCORE } from "@/lib/firmScore";
import { QUALIFIED_LEAD_SECONDS } from "@/lib/leadStatus";

const pct = (v: number) => `${Math.round(v * 100)}%`;

const FirmScoreCard = ({ funeralHomeId }: { funeralHomeId: string }) => {
  const [score, setScore] = useState<FirmScoreResult | null>(null);

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase
        .from("call_logs")
        .select("started_at, call_duration, outcome, resolved_at")
        .eq("funeral_home_id", funeralHomeId)
        .gte("started_at", subDays(new Date(), SCORE_WINDOW_DAYS).toISOString());
      const rows = data || [];
      let speedPoints = 0;
      for (const r of rows) {
        if (r.outcome === "resolved" && r.resolved_at) {
          const days = (new Date(r.resolved_at).getTime() - new Date(r.started_at).getTime()) / 86400000;
          speedPoints += Math.max(0, Math.min(1, 1 - (days - 7) / 23));
        }
      }
      const dur = (r: { call_duration: number | null }) => r.call_duration ?? 0;
      setScore(
        computeFirmScore({
          totalLeads: rows.length,
          answeredLeads: rows.filter((r) => dur(r) > 0).length,
          validLeads: rows.filter((r) => dur(r) >= QUALIFIED_LEAD_SECONDS).length,
          resolvedLeads: rows.filter((r) => r.outcome === "resolved").length,
          lostLeads: 0,
          unprocessedLeads: rows.filter((r) => dur(r) >= QUALIFIED_LEAD_SECONDS && r.outcome !== "resolved").length,
          missedLeads: rows.filter((r) => dur(r) === 0).length,
          speedPoints,
        })
      );
    };
    if (funeralHomeId) void load();
  }, [funeralHomeId]);

  if (!score) return null;

  const parts = [
    { label: "Răspuns la apeluri", value: score.answerRate },
    { label: `Convorbiri peste ${QUALIFIED_LEAD_SECONDS}s`, value: score.qualityRate },
    { label: "Lead-uri finalizate", value: score.resolveRate },
    { label: "Rapiditate finalizare", value: score.speedRate },
  ];

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Gauge className="h-5 w-5 text-primary" /> Scorul tău: {score.score}/100
        </CardTitle>
        <CardDescription>
          {score.isNew
            ? `Firmă nouă (${score.totalLeads}/${MIN_LEADS_FOR_SCORE} apeluri): pornești cu scor mare, care se ajustează după primele ${MIN_LEADS_FOR_SCORE} apeluri.`
            : `Calculat din apelurile din ultimele ${SCORE_WINDOW_DAYS} de zile. Un scor mare îți aduce mai des primul apel la „Contactează acum”.`}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-2">
          {parts.map((p) => (
            <div key={p.label} className="space-y-1">
              <div className="flex justify-between text-sm">
                <span>{p.label}</span>
                <span className="font-semibold">{pct(p.value)}</span>
              </div>
              <Progress value={p.value * 100} className="h-2" />
            </div>
          ))}
        </div>
        {score.tips.length > 0 && (
          <div className="rounded-2xl border bg-muted/40 p-3 space-y-1">
            <p className="flex items-center gap-2 text-sm font-semibold">
              <Lightbulb className="h-4 w-4 text-primary" /> Cum îți poți crește scorul
            </p>
            {score.tips.map((t) => (
              <p key={t} className="text-sm text-muted-foreground">• {t}</p>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default FirmScoreCard;
