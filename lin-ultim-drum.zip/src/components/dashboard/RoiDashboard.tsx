import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { format, startOfMonth, endOfMonth, subMonths } from "date-fns";
import { ro } from "date-fns/locale";
import {
  Phone,
  PhoneCall,
  Users,
  Wallet,
  TrendingUp,
  TrendingDown,
  Minus,
  Clock,
  AlertCircle,
  Sparkles,
} from "lucide-react";
import BrandState from "@/components/brand/BrandState";
import FirmScoreCard from "@/components/dashboard/FirmScoreCard";
import { QUALIFIED_LEAD_SECONDS } from "@/lib/leadStatus";

const LEAD_MIN_DURATION = QUALIFIED_LEAD_SECONDS;

interface RoiDashboardProps {
  funeralHomeId: string;
}

interface RawCall {
  started_at: string;
  call_duration: number | null;
  outcome: string | null;
  outcome_amount: number | null;
}

interface PeriodMetrics {
  calls: number;
  answered: number;
  leads: number;
  clients: number;
  revenue: number;
  unprocessed: number;
  totalDuration: number;
  busiestDay: string | null;
}

const emptyMetrics: PeriodMetrics = {
  calls: 0,
  answered: 0,
  leads: 0,
  clients: 0,
  revenue: 0,
  unprocessed: 0,
  totalDuration: 0,
  busiestDay: null,
};

const aggregate = (calls: RawCall[], from: Date, to: Date): PeriodMetrics => {
  const inRange = calls.filter((c) => {
    const d = new Date(c.started_at);
    return d >= from && d <= to;
  });

  const byDay: Record<string, number> = {};
  let totalDuration = 0;

  inRange.forEach((c) => {
    const key = format(new Date(c.started_at), "dd MMM", { locale: ro });
    byDay[key] = (byDay[key] || 0) + 1;
    totalDuration += c.call_duration || 0;
  });

  const busiest = Object.entries(byDay).sort((a, b) => b[1] - a[1])[0];

  return {
    calls: inRange.length,
    answered: inRange.filter((c) => (c.call_duration || 0) > 0).length,
    leads: inRange.filter((c) => (c.call_duration || 0) >= LEAD_MIN_DURATION).length,
    clients: inRange.filter((c) => c.outcome === "resolved").length,
    revenue: inRange
      .filter((c) => c.outcome === "resolved")
      .reduce((sum, c) => sum + (Number(c.outcome_amount) || 0), 0),
    unprocessed: inRange.filter(
      (c) => (c.call_duration || 0) >= LEAD_MIN_DURATION && (c.outcome ?? "pending") !== "resolved"
    ).length,
    totalDuration,
    busiestDay: busiest ? `${busiest[0]} (${busiest[1]} apeluri)` : null,
  };
};

const formatMoney = (v: number) =>
  `${new Intl.NumberFormat("ro-RO", { maximumFractionDigits: 0 }).format(v)} RON`;

const formatDuration = (seconds: number) => {
  const m = Math.floor(seconds / 60);
  const s = Math.round(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
};

const Delta = ({ current, previous }: { current: number; previous: number }) => {
  if (previous === 0) {
    if (current === 0) {
      return (
        <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
          <Minus className="h-3 w-3" /> fără schimbare
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-600 dark:text-emerald-400">
        <TrendingUp className="h-3 w-3" /> nou
      </span>
    );
  }

  const change = ((current - previous) / previous) * 100;
  const rounded = Math.round(change);

  if (rounded === 0) {
    return (
      <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
        <Minus className="h-3 w-3" /> la fel ca luna trecută
      </span>
    );
  }

  const up = rounded > 0;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 text-xs font-medium",
        up ? "text-emerald-600 dark:text-emerald-400" : "text-destructive"
      )}
    >
      {up ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
      {up ? "+" : ""}
      {rounded}% față de luna anterioară
    </span>
  );
};

const RoiDashboard = ({ funeralHomeId }: RoiDashboardProps) => {
  const [calls, setCalls] = useState<RawCall[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState<"previous" | "current">("previous");

  const ranges = useMemo(() => {
    const now = new Date();
    const anchor = period === "previous" ? subMonths(now, 1) : now;
    const compare = subMonths(anchor, 1);
    return {
      from: startOfMonth(anchor),
      to: period === "current" ? now : endOfMonth(anchor),
      prevFrom: startOfMonth(compare),
      prevTo: endOfMonth(compare),
      label: format(anchor, "LLLL yyyy", { locale: ro }),
    };
  }, [period]);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      const oldest = startOfMonth(subMonths(new Date(), 2));
      const { data } = await supabase
        .from("call_logs")
        .select("started_at, call_duration, outcome, outcome_amount")
        .eq("funeral_home_id", funeralHomeId)
        .gte("started_at", oldest.toISOString())
        .order("started_at", { ascending: false });

      setCalls((data || []) as unknown as RawCall[]);
      setLoading(false);
    };
    if (funeralHomeId) load();
  }, [funeralHomeId]);

  const current = useMemo(
    () => (loading ? emptyMetrics : aggregate(calls, ranges.from, ranges.to)),
    [calls, ranges, loading]
  );
  const previous = useMemo(
    () => (loading ? emptyMetrics : aggregate(calls, ranges.prevFrom, ranges.prevTo)),
    [calls, ranges, loading]
  );

  const conversion = current.leads > 0 ? Math.round((current.clients / current.leads) * 100) : 0;
  const answerRate = current.calls > 0 ? Math.round((current.answered / current.calls) * 100) : 0;
  const avgOrder = current.clients > 0 ? current.revenue / current.clients : 0;
  const avgDuration = current.answered > 0 ? current.totalDuration / current.answered : 0;

  const cards = [
    { title: "Apeluri primite", value: current.calls, prev: previous.calls, icon: Phone },
    { title: `Lead-uri calificate`, value: current.leads, prev: previous.leads, icon: PhoneCall },
    { title: "Clienți câștigați", value: current.clients, prev: previous.clients, icon: Users },
    {
      title: "Încasări generate",
      value: current.revenue,
      prev: previous.revenue,
      icon: Wallet,
      money: true,
    },
  ];

  return (
    <div className="space-y-6">
      <FirmScoreCard funeralHomeId={funeralHomeId} />
      {/* Header + period switch */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h2 className="text-xl font-bold capitalize sm:text-2xl">
            Rezultatele tale în {ranges.label}
          </h2>
          <p className="text-sm text-muted-foreground">
            {format(ranges.from, "dd MMM", { locale: ro })} – {format(ranges.to, "dd MMM yyyy", { locale: ro })}
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant={period === "previous" ? "default" : "outline"}
            size="sm"
            className="rounded-full"
            onClick={() => setPeriod("previous")}
          >
            Luna precedentă
          </Button>
          <Button
            variant={period === "current" ? "default" : "outline"}
            size="sm"
            className="rounded-full"
            onClick={() => setPeriod("current")}
          >
            Luna curentă
          </Button>
        </div>
      </div>

      {loading ? (
        <p className="py-8 text-center text-sm text-muted-foreground">Se încarcă rezultatele...</p>
      ) : current.calls === 0 ? (
        <BrandState title={`Nu ai primit apeluri prin Funerio în ${ranges.label}.`} />
      ) : (
        <>
          {/* Main cards */}
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            {cards.map((c) => (
              <Card key={c.title}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-xs font-medium sm:text-sm">{c.title}</CardTitle>
                  <c.icon className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent className="space-y-1">
                  <div className="text-2xl font-bold">
                    {c.money ? formatMoney(c.value) : c.value}
                  </div>
                  <Delta current={c.value} previous={c.prev} />
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Impact summary */}
          <Card className="border-primary/30 bg-primary/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" />
                Impactul Funerio
              </CardTitle>
              <CardDescription>Ce a adus platforma firmei tale în această perioadă</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-base leading-relaxed">
                În <span className="font-semibold capitalize">{ranges.label}</span> ai primit{" "}
                <span className="font-semibold">{current.calls} apeluri</span> prin Funerio, din care{" "}
                <span className="font-semibold">{current.leads} lead-uri reale</span> și{" "}
                <span className="font-semibold">{current.clients} clienți câștigați</span>.
                {current.revenue > 0 && (
                  <>
                    {" "}Valoarea totală a comenzilor:{" "}
                    <span className="font-semibold">{formatMoney(current.revenue)}</span>, cu o medie de{" "}
                    <span className="font-semibold">{formatMoney(avgOrder)}</span> per client.
                  </>
                )}{" "}
                Rata de transformare lead → client:{" "}
                <span className="font-semibold">{conversion}%</span>.
              </p>

              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary" className="text-xs">
                  Lead-uri: <Delta current={current.leads} previous={previous.leads} />
                </Badge>
                <Badge variant="secondary" className="text-xs">
                  Clienți: {current.clients - previous.clients >= 0 ? "+" : ""}
                  {current.clients - previous.clients} față de luna anterioară
                </Badge>
                <Badge variant="secondary" className="text-xs">
                  Încasări: <Delta current={current.revenue} previous={previous.revenue} />
                </Badge>
              </div>

              {current.revenue === 0 && current.clients > 0 && (
                <p className="rounded-lg border border-dashed p-3 text-sm text-muted-foreground">
                  Completează prețul la finalizarea apelurilor ca să vezi încasările reale generate.
                </p>
              )}
            </CardContent>
          </Card>

          {/* Secondary indicators */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-xs font-medium sm:text-sm">Rată preluare apeluri</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-xl font-bold">{answerRate}%</div>
                <p className="mt-1 text-xs text-muted-foreground">
                  {current.answered} din {current.calls} apeluri preluate
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-1.5 text-xs font-medium sm:text-sm">
                  <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                  Timp mediu convorbire
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-xl font-bold">{formatDuration(avgDuration)}</div>
                <p className="mt-1 text-xs text-muted-foreground">minute pe apel preluat</p>
              </CardContent>
            </Card>

            <Card className={cn(current.unprocessed > 0 && "border-amber-500/40 bg-amber-500/5")}>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-1.5 text-xs font-medium sm:text-sm">
                  {current.unprocessed > 0 && <AlertCircle className="h-3.5 w-3.5 text-amber-600" />}
                  Lead-uri nefinalizate
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-xl font-bold">{current.unprocessed}</div>
                <p className="mt-1 text-xs text-muted-foreground">
                  {current.unprocessed > 0
                    ? "Marchează-le în tab-ul Apeluri pentru a recupera valoarea lor."
                    : "Toate lead-urile au fost procesate."}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-xs font-medium sm:text-sm">Cea mai activă zi</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-xl font-bold">{current.busiestDay?.split(" (")[0] ?? "—"}</div>
                <p className="mt-1 text-xs text-muted-foreground">
                  {current.busiestDay ? current.busiestDay.split("(")[1]?.replace(")", "") : "fără date"}
                </p>
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  );
};

export default RoiDashboard;
