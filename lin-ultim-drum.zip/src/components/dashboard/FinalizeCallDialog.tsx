import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { ro } from "date-fns/locale";

interface FinalizeCallDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  callerPhone: string;
  onSave: (data: FinalizeFormData) => void;
}

export interface FinalizeFormData {
  contactName: string;
  phone: string;
  price: string;
  address: string;
  date: Date | undefined;
  details: string;
}

const FinalizeCallDialog = ({ open, onOpenChange, callerPhone, onSave }: FinalizeCallDialogProps) => {
  const formatPhone = (phone: string) => {
    if (phone.startsWith("+40")) return phone.replace("+40", "0");
    return phone;
  };

  const [form, setForm] = useState<FinalizeFormData>({
    contactName: "",
    phone: formatPhone(callerPhone || ""),
    price: "",
    address: "",
    date: undefined,
    details: "",
  });

  const handleSave = () => {
    if (!form.phone.trim()) return;
    onSave(form);
    setForm({ contactName: "", phone: "", price: "", address: "", date: undefined, details: "" });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Finalizare apel</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="contactName">Persoană de contact</Label>
            <Input
              id="contactName"
              value={form.contactName}
              onChange={(e) => setForm(prev => ({ ...prev, contactName: e.target.value }))}
              placeholder="Numele persoanei cu care ați vorbit"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">Nr. telefon *</Label>
            <Input
              id="phone"
              value={form.phone}
              onChange={(e) => setForm(prev => ({ ...prev, phone: e.target.value }))}
              placeholder="07xx xxx xxx"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="price">Preț (RON)</Label>
            <Input
              id="price"
              type="number"
              value={form.price}
              onChange={(e) => setForm(prev => ({ ...prev, price: e.target.value }))}
              placeholder="0"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="address">Adresă</Label>
            <Input
              id="address"
              value={form.address}
              onChange={(e) => setForm(prev => ({ ...prev, address: e.target.value }))}
              placeholder="Adresa clientului"
            />
          </div>
          <div className="space-y-2">
            <Label>Data</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !form.date && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {form.date ? format(form.date, "dd MMM yyyy", { locale: ro }) : "Selectează data"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={form.date}
                  onSelect={(date) => setForm(prev => ({ ...prev, date }))}
                  initialFocus
                  className={cn("p-3 pointer-events-auto")}
                />
              </PopoverContent>
            </Popover>
          </div>
          <div className="space-y-2">
            <Label htmlFor="details">Detalii</Label>
            <Textarea
              id="details"
              value={form.details}
              onChange={(e) => setForm(prev => ({ ...prev, details: e.target.value }))}
              placeholder="Pachetul ales, servicii, alte detalii..."
              rows={3}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Anulează</Button>
          <Button onClick={handleSave} disabled={!form.phone.trim()}>Salvează</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default FinalizeCallDialog;
