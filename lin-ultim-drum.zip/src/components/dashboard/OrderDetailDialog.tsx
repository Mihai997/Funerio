import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Pencil } from "lucide-react";

export interface OrderItem {
  id: string;
  name: string;
  phone: string;
  date: string;
  amount: number;
  status: string;
  details: string;
  address?: string;
  custom?: boolean;
}

interface OrderDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  order: OrderItem | null;
  onSave: (updated: OrderItem) => void;
}

const OrderDetailDialog = ({ open, onOpenChange, order, onSave }: OrderDetailDialogProps) => {
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState<OrderItem | null>(null);

  useEffect(() => {
    if (order) {
      setForm({ ...order });
      setEditing(false);
    }
  }, [order]);

  if (!form) return null;

  const statusLabel = form.status === "pending" ? "În așteptare" 
    : form.status === "completed" ? "Finalizată" 
    : form.status === "finalizat" ? "Din apel" 
    : form.status;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>Detalii comandă</DialogTitle>
            {!editing && (
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setEditing(true)}>
                <Pencil className="h-4 w-4" />
              </Button>
            )}
          </div>
        </DialogHeader>

        {editing ? (
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label>Nume / Telefon</Label>
              <Input
                value={form.name}
                onChange={(e) => setForm(prev => prev ? { ...prev, name: e.target.value } : prev)}
              />
            </div>
            <div className="space-y-2">
              <Label>Telefon</Label>
              <Input
                value={form.phone}
                onChange={(e) => setForm(prev => prev ? { ...prev, phone: e.target.value } : prev)}
              />
            </div>
            <div className="space-y-2">
              <Label>Preț (RON)</Label>
              <Input
                type="number"
                value={form.amount || ""}
                onChange={(e) => setForm(prev => prev ? { ...prev, amount: parseFloat(e.target.value) || 0 } : prev)}
              />
            </div>
            <div className="space-y-2">
              <Label>Adresă</Label>
              <Input
                value={form.address || ""}
                onChange={(e) => setForm(prev => prev ? { ...prev, address: e.target.value } : prev)}
              />
            </div>
            <div className="space-y-2">
              <Label>Detalii</Label>
              <Textarea
                value={form.details}
                onChange={(e) => setForm(prev => prev ? { ...prev, details: e.target.value } : prev)}
                rows={3}
              />
            </div>
          </div>
        ) : (
          <div className="space-y-3 py-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Status</span>
              <Badge variant={form.status === "completed" || form.status === "finalizat" ? "default" : "secondary"} className="text-xs">
                {statusLabel}
              </Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-muted-foreground">Nume / Telefon</span>
              <span className="text-sm font-medium">{form.name}</span>
            </div>
            {form.phone && form.phone !== form.name && (
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Telefon</span>
                <span className="text-sm">{form.phone}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-sm text-muted-foreground">Preț</span>
              <span className="text-sm font-medium">{form.amount > 0 ? `${form.amount.toFixed(0)} RON` : "-"}</span>
            </div>
            {form.address && (
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Adresă</span>
                <span className="text-sm text-right max-w-[60%]">{form.address}</span>
              </div>
            )}
            {form.details && (
              <div>
                <span className="text-sm text-muted-foreground">Detalii</span>
                <p className="text-sm mt-1 p-2 rounded bg-muted/50">{form.details}</p>
              </div>
            )}
          </div>
        )}

        {editing && (
          <DialogFooter>
            <Button variant="outline" onClick={() => { setForm(order ? { ...order } : null); setEditing(false); }}>Anulează</Button>
            <Button onClick={() => { if (form) { onSave(form); setEditing(false); onOpenChange(false); } }}>Salvează</Button>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default OrderDetailDialog;
