import { useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Upload, Trash2 } from "lucide-react";
import DoveLoader from "@/components/brand/DoveLoader";
import funerioDove from "@/assets/funerio-dove.png";
import { ACCEPTED_IMAGE_TYPES, MAX_UPLOAD_BYTES, resizeImage } from "@/lib/imageResize";

const BUCKET = "firm-logos";
const SIGNED_URL_TTL = 60 * 60 * 24 * 365 * 10; // 10 ani

interface LogoUploaderProps {
  funeralHomeId: string;
  logo: string | null;
  onChange: (logo: string | null) => void;
}

const storagePathFromUrl = (url: string | null): string | null => {
  if (!url) return null;
  const marker = `/${BUCKET}/`;
  const index = url.indexOf(marker);
  if (index === -1) return null;
  return decodeURIComponent(url.slice(index + marker.length).split("?")[0]);
};

const LogoUploader = ({ funeralHomeId, logo, onChange }: LogoUploaderProps) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  const removeOldFile = async (currentLogo: string | null) => {
    const path = storagePathFromUrl(currentLogo);
    if (path) await supabase.storage.from(BUCKET).remove([path]);
  };

  const handleFile = async (file: File) => {
    if (!ACCEPTED_IMAGE_TYPES.includes(file.type)) {
      toast.error("Format acceptat: JPG, PNG sau WebP.");
      return;
    }
    if (file.size > MAX_UPLOAD_BYTES) {
      toast.error("Fișierul este prea mare (maximum 10 MB).");
      return;
    }

    setUploading(true);
    try {
      const { blob, extension, contentType } = await resizeImage(file);
      const path = `${funeralHomeId}/logo-${Date.now()}.${extension}`;

      const { error: uploadError } = await supabase.storage
        .from(BUCKET)
        .upload(path, blob, { contentType, upsert: true });
      if (uploadError) throw uploadError;

      const { data, error: urlError } = await supabase.storage
        .from(BUCKET)
        .createSignedUrl(path, SIGNED_URL_TTL);
      if (urlError || !data?.signedUrl) throw urlError ?? new Error("URL indisponibil");

      await removeOldFile(logo);
      onChange(data.signedUrl);
      toast.success("Logo încărcat. Nu uita să salvezi modificările.");
    } catch (error) {
      console.error("Logo upload error:", error);
      toast.error("Eroare la încărcarea imaginii.");
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  const handleRemove = async () => {
    setUploading(true);
    try {
      await removeOldFile(logo);
      onChange(null);
      toast.success("Logo șters. Nu uita să salvezi modificările.");
    } catch (error) {
      console.error("Logo remove error:", error);
      toast.error("Eroare la ștergerea imaginii.");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="space-y-3">
      <Label>Logo firmă</Label>
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
        <div className="flex h-24 w-24 shrink-0 items-center justify-center overflow-hidden rounded-full border bg-muted">
          {uploading ? (
            <DoveLoader size="inline" label="Se încarcă" />
          ) : (
            <img
              src={logo || funerioDove}
              alt="Logo firmă"
              className={logo ? "h-full w-full object-cover" : "h-12 w-12 object-contain opacity-70"}
            />
          )}
        </div>

        <div className="flex flex-col gap-2 sm:flex-row">
          <Button
            type="button"
            variant="outline"
            className="gap-2"
            disabled={uploading}
            onClick={() => inputRef.current?.click()}
          >
            <Upload className="h-4 w-4" />
            Încarcă imagine
          </Button>
          {logo && (
            <Button
              type="button"
              variant="ghost"
              className="gap-2 text-destructive"
              disabled={uploading}
              onClick={handleRemove}
            >
              <Trash2 className="h-4 w-4" />
              Șterge
            </Button>
          )}
        </div>
      </div>
      <p className="text-xs text-muted-foreground">
        JPG, PNG sau WebP, maximum 10 MB. Imaginea este redimensionată automat la 800px pentru încărcare rapidă.
      </p>
      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleFile(file);
        }}
      />
    </div>
  );
};

export default LogoUploader;
