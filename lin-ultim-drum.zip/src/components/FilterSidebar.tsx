import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FilterState, serviceCategories, romanianCounties } from "@/types/funeral";

interface FilterSidebarProps {
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
}

const FilterSidebar = ({ filters, onFilterChange }: FilterSidebarProps) => {
  const handleCountyChange = (county: string) => {
    onFilterChange({ ...filters, county, city: "" });
  };

  const handlePriceRangeToggle = (priceRange: string) => {
    const newPriceRanges = filters.priceRange.includes(priceRange)
      ? filters.priceRange.filter(p => p !== priceRange)
      : [...filters.priceRange, priceRange];
    onFilterChange({ ...filters, priceRange: newPriceRanges });
  };

  const handleServiceToggle = (service: string) => {
    const newServices = filters.services.includes(service as any)
      ? filters.services.filter(s => s !== service)
      : [...filters.services, service as any];
    onFilterChange({ ...filters, services: newServices });
  };

  return (
    <Card className="sticky top-20">
      <CardHeader>
        <CardTitle className="text-lg">Filtre</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Location Filter */}
        <div className="space-y-3">
          <Label className="text-base font-semibold">Locație</Label>
          <div className="space-y-2">
            <Select value={filters.county} onValueChange={handleCountyChange}>
              <SelectTrigger>
                <SelectValue placeholder="Selectează județul" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toate județele</SelectItem>
                {romanianCounties.map(county => (
                  <SelectItem key={county} value={county}>{county}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Price Range Filter */}
        <div className="space-y-3">
          <Label className="text-base font-semibold">Interval de Preț</Label>
          <div className="space-y-2">
            {["€", "€€", "€€€"].map(range => (
              <div key={range} className="flex items-center space-x-2">
                <Checkbox
                  id={`price-${range}`}
                  checked={filters.priceRange.includes(range)}
                  onCheckedChange={() => handlePriceRangeToggle(range)}
                />
                <label
                  htmlFor={`price-${range}`}
                  className="text-sm cursor-pointer"
                >
                  {range} {range === "€" && "(Accesibil)"} {range === "€€" && "(Mediu)"} {range === "€€€" && "(Premium)"}
                </label>
              </div>
            ))}
          </div>
          <div className="text-xs text-muted-foreground space-y-1 pt-2 border-t">
            <p>€ - Sub 5.000 RON</p>
            <p>€€ - 5.000-10.000 RON</p>
            <p>€€€ - Peste 10.000 RON</p>
          </div>
        </div>

        {/* Services Filter */}
        <div className="space-y-3">
          <Label className="text-base font-semibold">Servicii</Label>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {serviceCategories.map(category => (
              <div key={category.value} className="flex items-center space-x-2">
                <Checkbox
                  id={`service-${category.value}`}
                  checked={filters.services.includes(category.value)}
                  onCheckedChange={() => handleServiceToggle(category.value)}
                />
                <label
                  htmlFor={`service-${category.value}`}
                  className="text-sm cursor-pointer"
                >
                  {category.label}
                </label>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default FilterSidebar;
