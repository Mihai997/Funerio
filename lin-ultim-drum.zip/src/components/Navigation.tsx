import { Link, useLocation, useNavigate } from "react-router-dom";
import { LogIn, LogOut, Shield, Settings, Menu, Home, Building2, Phone, FileText, Users, BarChart3, ClipboardCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Session } from "@supabase/supabase-js";
import funerioLogo from "@/assets/funerio-logo.png";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";

const adminCache = new Map<string, boolean>();
const adminPendingChecks = new Map<string, Promise<boolean>>();

const Navigation = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const initialSessionLoadedRef = useRef(false);
  const [session, setSession] = useState<Session | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [authResolved, setAuthResolved] = useState(false);
  const [roleResolved, setRoleResolved] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const isActive = (path: string) => location.pathname === path;

  const checkAdminRole = async (userId: string) => {
    if (adminCache.has(userId)) {
      setIsAdmin(adminCache.get(userId)!);
      setRoleResolved(true);
      return;
    }

    setRoleResolved(false);

    let pendingCheck = adminPendingChecks.get(userId);
    if (!pendingCheck) {
      pendingCheck = (async () => {
        const { data, error } = await supabase
          .from("user_roles")
          .select("role")
          .eq("user_id", userId)
          .eq("role", "admin")
          .maybeSingle();

        if (error) throw error;
        const result = !!data;
        adminCache.set(userId, result);
        return result;
      })();

      adminPendingChecks.set(userId, pendingCheck);
    }

    try {
      setIsAdmin(await pendingCheck);
    } catch (error) {
      console.error("Error checking admin role:", error);
      setIsAdmin(false);
    } finally {
      setRoleResolved(true);
    }
  };

  const applySessionState = (nextSession: Session | null) => {
    setSession(nextSession);

    if (!nextSession) {
      setIsAdmin(false);
      setRoleResolved(true);
      return;
    }

    void checkAdminRole(nextSession.user.id);
  };

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      if (!initialSessionLoadedRef.current) return;
      setAuthResolved(true);
      applySessionState(nextSession);
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      initialSessionLoadedRef.current = true;
      setAuthResolved(true);
      applySessionState(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  const authReady = authResolved && (!session || roleResolved);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };
  
  return (
    <nav className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50 shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20 md:h-24">
          <Link to="/" className="flex items-center group">
            <img 
              src={funerioLogo} 
              alt="Funerio Logo" 
              className="h-14 md:h-18 lg:h-22 w-auto transition-transform group-hover:scale-105" 
            />
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6">
            <Link
              to="/"
              className={`text-base font-medium transition-colors hover:text-primary px-3 py-2 rounded-full ${
                isActive("/") ? "text-primary bg-primary/10" : "text-muted-foreground"
              }`}
            >
              Acasă
            </Link>
            <Link
              to="/firme"
              className={`text-base font-medium transition-colors hover:text-primary px-3 py-2 rounded-full ${
                isActive("/firme") ? "text-primary bg-primary/10" : "text-muted-foreground"
              }`}
            >
              Servicii
            </Link>
            <Link
              to="/contact"
              className={`text-base font-medium transition-colors hover:text-primary px-3 py-2 rounded-full ${
                isActive("/contact") ? "text-primary bg-primary/10" : "text-muted-foreground"
              }`}
            >
              Contact
            </Link>
            <Link
              to="/articole"
              className={`text-base font-medium transition-colors hover:text-primary px-3 py-2 rounded-full ${
                isActive("/articole") ? "text-primary bg-primary/10" : "text-muted-foreground"
              }`}
            >
              Articole
            </Link>
          </div>
          
          {/* Desktop Auth Buttons */}
          <div className="hidden md:flex items-center gap-2 min-h-9">
            <Link to="/parteneri">
              <Button variant="outline" size="sm" className="gap-2">
                <Building2 className="h-4 w-4" />
                Devino partener
              </Button>
            </Link>
            {!authReady ? (
              <div className="h-9 w-32" aria-hidden />
            ) : session ? (
              <>
                {isAdmin ? (
                  <>
                    <Link to="/admin">
                      <Button variant="outline" size="sm" className="gap-2">
                        <Shield className="h-4 w-4" />
                        <span className="hidden lg:inline">Admin</span>
                      </Button>
                    </Link>
                    <Link to="/admin/users">
                      <Button variant="outline" size="sm" className="gap-2">
                        <Users className="h-4 w-4" />
                        <span className="hidden lg:inline">Utilizatori</span>
                      </Button>
                    </Link>
                    <Link to="/admin/funeral-homes">
                      <Button variant="outline" size="sm" className="gap-2">
                        <Building2 className="h-4 w-4" />
                        <span className="hidden lg:inline">Firme</span>
                      </Button>
                    </Link>
                    <Link to="/admin/statistici">
                      <Button variant="outline" size="sm" className="gap-2">
                        <BarChart3 className="h-4 w-4" />
                        <span className="hidden lg:inline">Statistici</span>
                      </Button>
                    </Link>
                    <Link to="/admin/aprobari">
                      <Button variant="outline" size="sm" className="gap-2">
                        <ClipboardCheck className="h-4 w-4" />
                        <span className="hidden lg:inline">De aprobat</span>
                      </Button>
                    </Link>

                  </>
                ) : (
                  <>
                    <Link to="/dashboard">
                      <Button variant="outline" size="sm" className="gap-2">
                        <span className="hidden lg:inline">Administrare</span>
                      </Button>
                    </Link>
                    <Link to="/settings">
                      <Button variant="outline" size="sm" className="gap-2">
                        <Settings className="h-4 w-4" />
                      </Button>
                    </Link>
                  </>
                )}
                <Button size="sm" className="gap-2" onClick={handleLogout}>
                  <LogOut className="h-4 w-4" />
                  <span className="hidden lg:inline">Deconectare</span>
                </Button>
              </>
            ) : (
              <Link to="/auth">
                <Button variant="outline" size="sm" className="gap-2 h-8 px-3 text-xs">
                  <LogIn className="h-3.5 w-3.5" />
                  <span className="hidden lg:inline">Autentificare</span>
                </Button>
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" className="h-16 w-16 p-0 [&_svg]:!size-12">
                <Menu strokeWidth={2.5} />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[280px] sm:w-[320px]">
              <SheetHeader>
                <SheetTitle className="text-left">Meniu</SheetTitle>
              </SheetHeader>
              
              <div className="flex flex-col gap-4 mt-6">
                {/* Main Navigation Links */}
                <div className="flex flex-col gap-2">
                  <Link
                    to="/"
                    onClick={() => setIsMenuOpen(false)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                      isActive("/") ? "bg-primary/10 text-primary" : "hover:bg-muted"
                    }`}
                  >
                    <Home className="h-5 w-5" />
                    <span className="font-medium">Acasă</span>
                  </Link>
                  <Link
                    to="/firme"
                    onClick={() => setIsMenuOpen(false)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                      isActive("/firme") ? "bg-primary/10 text-primary" : "hover:bg-muted"
                    }`}
                  >
                    <Building2 className="h-5 w-5" />
                    <span className="font-medium">Servicii</span>
                  </Link>
                  <Link
                    to="/parteneri"
                    onClick={() => setIsMenuOpen(false)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                      isActive("/parteneri") ? "bg-primary/10 text-primary" : "hover:bg-muted"
                    }`}
                  >
                    <Building2 className="h-5 w-5" />
                    <span className="font-medium">Parteneri</span>
                  </Link>
                  <Link
                    to="/contact"
                    onClick={() => setIsMenuOpen(false)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                      isActive("/contact") ? "bg-primary/10 text-primary" : "hover:bg-muted"
                    }`}
                  >
                    <Phone className="h-5 w-5" />
                    <span className="font-medium">Contact</span>
                  </Link>
                  <Link
                    to="/articole"
                    onClick={() => setIsMenuOpen(false)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                      isActive("/articole") ? "bg-primary/10 text-primary" : "hover:bg-muted"
                    }`}
                  >
                    <FileText className="h-5 w-5" />
                    <span className="font-medium">Articole</span>
                  </Link>
                </div>

                {/* User/Admin Links */}
                {session && authReady && (
                  <div className="border-t pt-4 mt-2">
                    <div className="flex flex-col gap-2">
                      {isAdmin ? (
                        <>
                          <Link
                            to="/admin"
                            onClick={() => setIsMenuOpen(false)}
                            className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-muted transition-colors"
                          >
                            <Shield className="h-5 w-5" />
                            <span className="font-medium">Admin Dashboard</span>
                          </Link>
                          <Link
                            to="/admin/users"
                            onClick={() => setIsMenuOpen(false)}
                            className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-muted transition-colors"
                          >
                            <Users className="h-5 w-5" />
                            <span className="font-medium">Utilizatori</span>
                          </Link>
                          <Link
                            to="/admin/funeral-homes"
                            onClick={() => setIsMenuOpen(false)}
                            className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-muted transition-colors"
                          >
                            <Building2 className="h-5 w-5" />
                            <span className="font-medium">Firme Funerare</span>
                          </Link>
                          <Link
                            to="/admin/statistici"
                            onClick={() => setIsMenuOpen(false)}
                            className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-muted transition-colors"
                          >
                            <BarChart3 className="h-5 w-5" />
                            <span className="font-medium">Statistici</span>
                          </Link>
                          <Link
                            to="/admin/aprobari"
                            onClick={() => setIsMenuOpen(false)}
                            className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-muted transition-colors"
                          >
                            <ClipboardCheck className="h-5 w-5" />
                            <span className="font-medium">De aprobat</span>
                          </Link>
                        </>
                      ) : (
                        <>
                          <Link
                            to="/dashboard"
                            onClick={() => setIsMenuOpen(false)}
                            className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-muted transition-colors"
                          >
                            <span className="font-medium">Administrare</span>
                          </Link>
                          <Link
                            to="/settings"
                            onClick={() => setIsMenuOpen(false)}
                            className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-muted transition-colors"
                          >
                            <Settings className="h-5 w-5" />
                            <span className="font-medium">Setări</span>
                          </Link>
                        </>
                      )}
                    </div>
                  </div>
                )}

                {/* Auth Button */}
                <div className="border-t pt-4 mt-2">
                  {session ? (
                    <Button 
                      className="w-full justify-start gap-3" 
                      variant="outline"
                      onClick={() => {
                        handleLogout();
                        setIsMenuOpen(false);
                      }}
                    >
                      <LogOut className="h-5 w-5" />
                      <span>Deconectare</span>
                    </Button>
                  ) : (
                    <Link to="/auth" onClick={() => setIsMenuOpen(false)}>
                      <Button className="w-full justify-start gap-3">
                        <LogIn className="h-5 w-5" />
                        <span>Autentificare</span>
                      </Button>
                    </Link>
                  )}
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
