export interface FirmScoreCounts {
  totalLeads: number;
  answeredLeads: number;
  validLeads: number;
  resolvedLeads: number;
  lostLeads: number;
  unprocessedLeads: number;
  missedLeads: number;
  /** Sum of per-lead speed credits (1 = finalized within 7 days, 0 = after 30 days). */
  speedPoints?: number;
}

export interface FirmScoreResult extends FirmScoreCounts {
  score: number;
  stars: number;
  answerRate: number;
  resolveRate: number;
  processRate: number;
  label: string;
  tone: "excellent" | "good" | "average" | "poor" | "unknown";
  insufficientData: boolean;
  realScore: number;
  isNew: boolean;
  qualityRate: number;
  speedRate: number;
  tips: string[];
}

export const MIN_LEADS_FOR_SCORE = 10;
export const NEW_FIRM_START_SCORE = 80;
export const SCORE_WINDOW_DAYS = 90;

export const WEIGHTS = {
  answer: 50,
  quality: 20,
  resolve: 20,
  speed: 10,
};

export function computeFirmScore(counts: FirmScoreCounts): FirmScoreResult {
  const { totalLeads, answeredLeads, validLeads, resolvedLeads, unprocessedLeads } = counts;

  const answerRate = totalLeads > 0 ? answeredLeads / totalLeads : 0;
  const qualityRate = answeredLeads > 0 ? validLeads / answeredLeads : 0;
  const resolveRate = validLeads > 0 ? Math.min(resolvedLeads, validLeads) / validLeads : 0;
  const processRate = resolveRate;
  const speedRate = resolvedLeads > 0 ? Math.min(1, (counts.speedPoints ?? 0) / resolvedLeads) : 0;

  const realScore =
    WEIGHTS.answer * answerRate +
    WEIGHTS.quality * qualityRate +
    WEIGHTS.resolve * resolveRate +
    WEIGHTS.speed * speedRate;

  const n = Math.min(totalLeads, MIN_LEADS_FOR_SCORE) / MIN_LEADS_FOR_SCORE;
  const score = Math.round(n * realScore + (1 - n) * NEW_FIRM_START_SCORE);
  const isNew = totalLeads < MIN_LEADS_FOR_SCORE;
  const insufficientData = false;

  const tips: string[] = [];
  if (totalLeads > 0 && answerRate < 0.8) tips.push("Răspunde la mai multe apeluri — apelurile nepreluate scad scorul cel mai mult.");
  if (answeredLeads > 0 && qualityRate < 0.6) tips.push("Discută mai pe larg cu clienții (peste 40 de secunde).");
  if (validLeads > 0 && resolveRate < 0.5) tips.push("Marchează „Finalizat” lead-urile duse la capăt.");
  if (resolvedLeads > 0 && speedRate < 0.7) tips.push("Marchează rezultatul în cel mult 7 zile de la apel.");

  let label = "Slab";
  let tone: FirmScoreResult["tone"] = "poor";
  if (isNew) {
    label = `Nouă (${totalLeads}/${MIN_LEADS_FOR_SCORE} apeluri)`;
    tone = "unknown";
  } else if (score >= 85) {
    label = "Excelent";
    tone = "excellent";
  } else if (score >= 70) {
    label = "Bun";
    tone = "good";
  } else if (score >= 50) {
    label = "Mediu";
    tone = "average";
  }

  return {
    ...counts,
    unprocessedLeads,
    score,
    stars: Math.max(1, Math.min(5, Math.round((score / 100) * 5))),
    answerRate,
    resolveRate,
    processRate,
    label,
    tone,
    insufficientData,
    realScore: Math.round(realScore),
    isNew,
    qualityRate,
    speedRate,
    tips,
  };
}

export const SCORE_TONE_CLASS: Record<FirmScoreResult["tone"], string> = {
  excellent: "bg-emerald-500/15 text-emerald-700 border-emerald-500/30 dark:text-emerald-400",
  good: "bg-lime-500/15 text-lime-700 border-lime-500/30 dark:text-lime-400",
  average: "bg-amber-500/15 text-amber-700 border-amber-500/30 dark:text-amber-400",
  poor: "bg-destructive/10 text-destructive border-destructive/30",
  unknown: "bg-muted text-muted-foreground border-border",
};

export interface FirmScoreRow extends FirmScoreResult {
  funeralHomeId: string;
  funeralHomeName: string;
  subscriptionActive: boolean;
}

interface RawScoreRow {
  funeral_home_id: string;
  funeral_home_name: string;
  subscription_active: boolean | null;
  total_leads: number | string;
  answered_leads: number | string;
  valid_leads: number | string;
  resolved_leads: number | string;
  lost_leads: number | string;
  unprocessed_leads: number | string;
  missed_leads: number | string;
  speed_points?: number | string | null;
}

export function mapScoreRow(row: RawScoreRow): FirmScoreRow {
  const counts: FirmScoreCounts = {
    totalLeads: Number(row.total_leads) || 0,
    answeredLeads: Number(row.answered_leads) || 0,
    validLeads: Number(row.valid_leads) || 0,
    resolvedLeads: Number(row.resolved_leads) || 0,
    lostLeads: Number(row.lost_leads) || 0,
    unprocessedLeads: Number(row.unprocessed_leads) || 0,
    missedLeads: Number(row.missed_leads) || 0,
    speedPoints: Number(row.speed_points) || 0,
  };
  return {
    ...computeFirmScore(counts),
    funeralHomeId: row.funeral_home_id,
    funeralHomeName: row.funeral_home_name,
    subscriptionActive: !!row.subscription_active,
  };
}
