/**
 * Coloanele firmelor pe care le poate citi publicul.
 * Numarul real (`phone`) NU este expus niciodata in browser —
 * toate apelurile trec prin numarul Twilio de tracking.
 */
export const PUBLIC_FIRM_COLUMNS =
  "id, name, logo, description, county, city, price_range, rating, review_count, email, tracking_phone, subscription_active, created_at, updated_at";

/** Numarul afisabil public: doar numarul de tracking, altfel gol. */
export function publicPhone(trackingPhone?: string | null): string {
  return trackingPhone ?? "";
}
