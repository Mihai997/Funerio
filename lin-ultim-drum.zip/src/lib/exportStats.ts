import * as XLSX from "xlsx";
import { format } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { getLeadStatus, QUALIFIED_LEAD_SECONDS } from "@/lib/leadStatus";
import { maskPhone } from "@/lib/phoneMask";

export type StatsPeriod = "total" | "year" | "month";

const PERIOD_LABEL: Record<StatsPeriod, string> = {
  total: "Total",
  year: "Ultimul an",
  month: "Ultima lună",
};

const slugify = (value: string) =>
  value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");

const periodStart = (period: StatsPeriod): Date | null => {
  const now = new Date();
  if (period === "year") return new Date(now.getFullYear() - 1, now.getMonth(), now.getDate());
  if (period === "month") return new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
  return null;
};

const formatDuration = (seconds: number) => {
  const s = Math.max(0, Math.floor(seconds || 0));
  return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
};

const STATUS_LABEL: Record<string, string> = {
  initiated: "Inițiat",
  "in-progress": "În desfășurare",
  completed: "Finalizat",
  "no-answer": "Fără răspuns",
  busy: "Ocupat",
  failed: "Eșuat",
  canceled: "Anulat",
};

export interface ExportStatsInput {
  funeralHomeId: string;
  funeralHomeName: string;
  period: StatsPeriod;
  averageOrderValue: number;
  completionRate: number;
  potentialClients?: number;
  totalOrders?: number;
  totalRevenue?: number;
  monthlyStats?: { month: string; revenue: number; orders: number }[];
  topServices?: { name: string; count: number; revenue: number }[];
  topPackages?: { name: string; count: number; revenue: number }[];
}

export const exportFirmStatsToExcel = async ({
  funeralHomeId,
  funeralHomeName,
  period,
  averageOrderValue,
  completionRate,
  potentialClients,
  totalOrders,
  totalRevenue,
  monthlyStats = [],
  topServices = [],
  topPackages = [],
}: ExportStatsInput) => {
  let query = supabase
    .from("call_logs")
    .select("caller_name, caller_phone, call_status, call_duration, started_at, outcome")
    .eq("funeral_home_id", funeralHomeId)
    .order("started_at", { ascending: false });

  const start = periodStart(period);
  if (start) query = query.gte("started_at", start.toISOString());

  const { data, error } = await query;
  if (error) throw error;

  const calls = data || [];
  const leads = calls.filter((c) => (c.call_duration || 0) >= QUALIFIED_LEAD_SECONDS);
  const conversion = calls.length > 0 ? (leads.length / calls.length) * 100 : 0;

  const summaryRows = [
    ["Firmă", funeralHomeName],
    ["Perioadă", PERIOD_LABEL[period]],
    ["Generat la", format(new Date(), "dd.MM.yyyy HH:mm")],
    [],
    ["Indicator", "Valoare"],
    ["Total apeluri", calls.length],
    [`Apeluri de minimum ${QUALIFIED_LEAD_SECONDS} secunde (leads)`, leads.length],
    ["Rată conversie apeluri", `${conversion.toFixed(1)}%`],
    ["Apeluri nepreluate", calls.filter((c) => getLeadStatus(c).label === "Nepreluat").length],
    ["Apeluri scurte", calls.filter((c) => getLeadStatus(c).label === "Apel scurt").length],
    ["Leads finalizate", calls.filter((c) => getLeadStatus(c).label === "Finalizat").length],
    ["Durată medie apel (mm:ss)", formatDuration(calls.length ? calls.reduce((a, c) => a + (c.call_duration || 0), 0) / calls.length : 0)],
    ["Potențiali clienți", potentialClients ?? leads.length],
    ["Total comenzi", totalOrders ?? 0],
    ["Venit total", `${(totalRevenue ?? 0).toFixed(0)} RON`],
    ["Valoare medie", `${averageOrderValue.toFixed(0)} RON`],
    ["Rată finalizare", `${completionRate.toFixed(0)}%`],
  ];

  const callRows = [
    ["Data și ora", "Persoană de contact", "Telefon apelant", "Durată (sec)", "Durată (mm:ss)", "Status", "Lead facturabil"],
    ...calls.map((c) => [
      format(new Date(c.started_at), "dd.MM.yyyy HH:mm"),
      c.caller_name || "-",
      maskPhone(c.caller_phone),
      c.call_duration || 0,
      formatDuration(c.call_duration || 0),
      getLeadStatus(c).label,
      (c.call_duration || 0) >= QUALIFIED_LEAD_SECONDS ? "Da" : "Nu",
    ]),
  ];

  const workbook = XLSX.utils.book_new();

  const summarySheet = XLSX.utils.aoa_to_sheet(summaryRows);
  summarySheet["!cols"] = [{ wch: 34 }, { wch: 24 }];
  ["A1", "A2", "A3", "A5", "B5"].forEach((ref) => {
    if (summarySheet[ref]) summarySheet[ref].s = { font: { bold: true } };
  });
  XLSX.utils.book_append_sheet(workbook, summarySheet, "Sumar");

  const callsSheet = XLSX.utils.aoa_to_sheet(callRows);
  callsSheet["!cols"] = [{ wch: 18 }, { wch: 24 }, { wch: 18 }, { wch: 13 }, { wch: 14 }, { wch: 16 }, { wch: 16 }];
  XLSX.utils.book_append_sheet(workbook, callsSheet, "Apeluri");

  const addSheet = (name: string, rows: (string | number)[][], cols: number[]) => {
    const sh = XLSX.utils.aoa_to_sheet(rows);
    sh["!cols"] = cols.map((wch) => ({ wch }));
    XLSX.utils.book_append_sheet(workbook, sh, name);
  };
  addSheet("Evoluție lunară", [["Lună", "Venit (RON)", "Leads"], ...monthlyStats.map((m) => [m.month, Math.round(m.revenue), m.orders])], [14, 14, 10]);
  addSheet("Top servicii", [["Serviciu", "Comenzi", "Venit (RON)"], ...topServices.map((t) => [t.name, t.count, Math.round(t.revenue)])], [36, 10, 14]);
  addSheet("Top pachete", [["Pachet", "Comenzi", "Venit (RON)"], ...topPackages.map((t) => [t.name, t.count, Math.round(t.revenue)])], [36, 10, 14]);

  const fileName = `funerio-statistici-${slugify(funeralHomeName)}-${period}-${format(new Date(), "yyyy-MM-dd")}.xlsx`;
  XLSX.writeFile(workbook, fileName);

  return { total: calls.length, leads: leads.length, fileName };
};
