export const MAX_UPLOAD_BYTES = 10 * 1024 * 1024;
export const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];

const supportsWebp = () => {
  const canvas = document.createElement("canvas");
  canvas.width = 1;
  canvas.height = 1;
  return canvas.toDataURL("image/webp").startsWith("data:image/webp");
};

const loadImage = (file: File) =>
  new Promise<HTMLImageElement>((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Imaginea nu a putut fi citită."));
    };
    img.src = url;
  });

export interface ResizedImage {
  blob: Blob;
  extension: string;
  contentType: string;
}

export const resizeImage = async (file: File, maxSize = 800, quality = 0.85): Promise<ResizedImage> => {
  const img = await loadImage(file);
  const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
  const width = Math.round(img.width * scale);
  const height = Math.round(img.height * scale);

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Procesarea imaginii nu este suportată de acest browser.");
  ctx.drawImage(img, 0, 0, width, height);

  const useWebp = supportsWebp();
  const contentType = useWebp ? "image/webp" : "image/jpeg";

  const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, contentType, quality));
  if (!blob) throw new Error("Imaginea nu a putut fi procesată.");

  return { blob, extension: useWebp ? "webp" : "jpg", contentType };
};
