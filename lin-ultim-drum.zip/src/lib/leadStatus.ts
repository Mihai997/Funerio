/**
 * Statusuri de business pentru lead-uri (apeluri).
 *
 * - missed    : firma nu a raspuns (durata 0)
 * - short     : a raspuns, dar sub pragul de calificare (apel informativ)
 * - qualified : apel peste prag -> lead real, facturabil
 * - completed : firma a marcat manual comanda ca finalizata
 */

export const QUALIFIED_LEAD_SECONDS = 40;

export type LeadStatusKey = "missed" | "short" | "qualified" | "completed";

export interface LeadStatusInfo {
  key: LeadStatusKey;
  label: string;
  className: string;
}

export const LEAD_STATUS_META: Record<LeadStatusKey, LeadStatusInfo> = {
  missed: {
    key: "missed",
    label: "Nepreluat",
    className: "bg-destructive/10 text-destructive border-destructive/30",
  },
  short: {
    key: "short",
    label: "Apel scurt",
    className: "bg-muted text-muted-foreground border-border",
  },
  qualified: {
    key: "qualified",
    label: "Lead calificat",
    className: "bg-sky-500/15 text-sky-700 border-sky-500/30 dark:text-sky-400",
  },
  completed: {
    key: "completed",
    label: "Finalizat",
    className: "bg-emerald-500/15 text-emerald-700 border-emerald-500/30 dark:text-emerald-400",
  },
};

export const LEAD_STATUS_OPTIONS = [
  LEAD_STATUS_META.missed,
  LEAD_STATUS_META.short,
  LEAD_STATUS_META.qualified,
  LEAD_STATUS_META.completed,
];

export interface LeadStatusInput {
  call_duration?: number | null;
  outcome?: string | null;
}

export function getLeadStatusKey(call: LeadStatusInput): LeadStatusKey {
  const duration = call.call_duration ?? 0;
  if (call.outcome === "resolved") return "completed";
  if (duration <= 0) return "missed";
  if (duration < QUALIFIED_LEAD_SECONDS) return "short";
  return "qualified";
}

export function getLeadStatus(call: LeadStatusInput): LeadStatusInfo {
  return LEAD_STATUS_META[getLeadStatusKey(call)];
}

export function isQualifiedLead(call: LeadStatusInput): boolean {
  return (call.call_duration ?? 0) >= QUALIFIED_LEAD_SECONDS;
}
