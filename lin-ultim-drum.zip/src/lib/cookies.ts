export interface CookieConsent {
  essential: boolean;
  analytics: boolean;
  marketing: boolean;
}

const COOKIE_CONSENT_KEY = "cookie-consent-preferences";

export function getCookieConsent(): CookieConsent | null {
  try {
    const stored = localStorage.getItem(COOKIE_CONSENT_KEY);
    if (!stored) return null;
    return JSON.parse(stored) as CookieConsent;
  } catch {
    return null;
  }
}

export function setCookieConsent(consent: CookieConsent): void {
  localStorage.setItem(COOKIE_CONSENT_KEY, JSON.stringify(consent));
}

export function hasConsentFor(category: keyof CookieConsent): boolean {
  const consent = getCookieConsent();
  if (!consent) return false;
  return consent[category];
}

export function clearCookieConsent(): void {
  localStorage.removeItem(COOKIE_CONSENT_KEY);
}
