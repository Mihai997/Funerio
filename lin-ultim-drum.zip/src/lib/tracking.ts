import { supabase } from "@/integrations/supabase/client";

export type SiteEventName =
  | "page_view"
  | "wizard_start"
  | "wizard_step_2"
  | "wizard_step_3"
  | "wizard_complete"
  | "view_firms"
  | "call_requested"
  | "quote_requested";

const SESSION_KEY = "funerio_session_id";

const getSessionId = (): string => {
  if (typeof window === "undefined") return "server";
  try {
    let id = sessionStorage.getItem(SESSION_KEY);
    if (!id) {
      id = crypto.randomUUID();
      sessionStorage.setItem(SESSION_KEY, id);
    }
    return id;
  } catch {
    return "anonymous";
  }
};

interface TrackPayload {
  county?: string | null;
  city?: string | null;
  path?: string;
  metadata?: Record<string, unknown>;
}

/** Fire-and-forget anonymous event logging. Never blocks or throws. */
export const trackEvent = (name: SiteEventName, payload: TrackPayload = {}) => {
  try {
    void supabase
      .from("site_events")
      .insert({
        event_name: name,
        session_id: getSessionId(),
        path: payload.path ?? (typeof window !== "undefined" ? window.location.pathname : null),
        county: payload.county || null,
        city: payload.city || null,
        metadata: (payload.metadata ?? null) as never,
      })
      .then(({ error }) => {
        if (error) console.debug("track error", error.message);
      });
  } catch {
    // tracking must never break the app
  }
};
