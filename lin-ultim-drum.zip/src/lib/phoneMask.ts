/**
 * Masking pentru numerele clientilor afisate firmelor.
 * Firmele nu trebuie sa vada numarul complet - apelul se face prin Twilio.
 */
export function maskPhone(phone?: string | null): string {
  if (!phone) return "Număr ascuns";
  const local = phone.startsWith("+40") ? phone.replace("+40", "0") : phone;
  const digits = local.replace(/\D/g, "");
  if (digits.length < 6) return "Număr ascuns";
  const prefix = digits.slice(0, 2);
  const last = digits.slice(-3);
  return `${prefix}xx xxx ${last}`;
}
