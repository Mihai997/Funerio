export interface Package {
  id: string;
  name: string;
  description: string;
  price: number;
  includedServices: string[]; // service IDs
}

export interface FuneralHome {
  id: string;
  name: string;
  logo: string;
  description: string;
  location: {
    county: string;
    city: string;
  };
  priceRange: "€" | "€€" | "€€€";
  rating: number;
  reviewCount: number;
  phone: string;
  email: string;
  services: Service[];
  packages: Package[];
}

export interface Service {
  id: string;
  name: string;
  category: ServiceCategory;
  description: string;
  price: number;
  priceUnit: string;
}

export type ServiceCategory = 
  | "transport"
  | "sicriu"
  | "flori"
  | "masa"
  | "pomeni"
  | "ceremonie"
  | "documente"
  | "crematoriu"
  | "altele";

export const serviceCategories: { value: ServiceCategory; label: string }[] = [
  { value: "transport", label: "Transport" },
  { value: "sicriu", label: "Sicrie și Cosciuge" },
  { value: "flori", label: "Aranjamente Florale" },
  { value: "masa", label: "Servicii de Masă" },
  { value: "pomeni", label: "Organizare Pomeni" },
  { value: "ceremonie", label: "Ceremonii Religioase" },
  { value: "documente", label: "Acte și Documente" },
  { value: "crematoriu", label: "Servicii Crematoriu" },
  { value: "altele", label: "Alte Servicii" },
];

export const romanianCounties = [
  "Alba", "Arad", "Argeș", "Bacău", "Bihor", "Bistrița-Năsăud", "Botoșani", "Brașov",
  "Brăila", "București", "Buzău", "Caraș-Severin", "Călărași", "Cluj", "Constanța",
  "Covasna", "Dâmbovița", "Dolj", "Galați", "Giurgiu", "Gorj", "Harghita", "Hunedoara",
  "Ialomița", "Iași", "Ilfov", "Maramureș", "Mehedinți", "Mureș", "Neamț", "Olt",
  "Prahova", "Satu Mare", "Sălaj", "Sibiu", "Suceava", "Teleorman", "Timiș", "Tulcea",
  "Vaslui", "Vâlcea", "Vrancea"
];

export interface FilterState {
  county: string;
  city: string;
  priceRange: string[];
  services: ServiceCategory[];
}
