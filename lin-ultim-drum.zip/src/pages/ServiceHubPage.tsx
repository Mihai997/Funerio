import { Link, Navigate, useParams } from "react-router-dom";
import Navigation from "@/components/Navigation";
import Seo from "@/components/Seo";
import { ChevronRight } from "lucide-react";
import { slugify } from "@/lib/slug";
import { getLanding, landingCities, serviceLandings } from "@/content/serviceLandings";

const SITE_URL = "https://funerio.ro";

interface Props {
  landingSlug?: string;
}

const ServiceHubPage = ({ landingSlug }: Props) => {
  const params = useParams();
  const slug = landingSlug ?? params.serviceSlug ?? "";
  const landing = getLanding(slug);

  if (!landing) return <Navigate to="/servicii" replace />;

  const title = landing.label;
  const jsonLd = [
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "Acasă", item: `${SITE_URL}/` },
        { "@type": "ListItem", position: 2, name: "Servicii", item: `${SITE_URL}/servicii` },
        { "@type": "ListItem", position: 3, name: title, item: `${SITE_URL}${landing.base}` },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Seo
        title={`${title} în România — firme verificate | Funerio`}
        description={`${title}: alege orașul și compară firmele verificate din zona ta, cu prețuri transparente și disponibilitate non-stop.`}
        jsonLd={jsonLd}
      />
      <Navigation />

      <div className="container mx-auto px-4 py-8 sm:px-6">
        <nav aria-label="Breadcrumb" className="mb-6 flex flex-wrap items-center gap-1 text-sm text-muted-foreground">
          <Link to="/" className="hover:text-primary">Acasă</Link>
          <ChevronRight className="h-3 w-3" />
          <Link to="/servicii" className="hover:text-primary">Servicii</Link>
          <ChevronRight className="h-3 w-3" />
          <span className="text-foreground">{title}</span>
        </nav>

        <header className="mb-8 max-w-3xl mx-auto text-center">
          <h1 className="mb-3 text-2xl font-bold md:text-4xl">{title} în România</h1>
          <p className="text-sm text-muted-foreground md:text-lg">
            Alege orașul pentru a vedea firmele disponibile, serviciile incluse și prețurile de pornire.
          </p>
        </header>

        <section className="mb-12">
          <h2 className="mb-4 text-xl font-semibold">Alege orașul</h2>
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {landingCities.map((c) => (
              <Link
                key={c.city}
                to={`${landing.base}/${slugify(c.city)}`}
                className="rounded-lg border px-4 py-3 text-sm hover:border-primary hover:text-primary"
              >
                {title} {c.city}
              </Link>
            ))}
          </div>
        </section>

        <section>
          <h2 className="mb-4 text-xl font-semibold">Alte servicii</h2>
          <div className="flex flex-wrap gap-2">
            {serviceLandings
              .filter((s) => s.slug !== landing.slug)
              .map((s) => (
                <Link
                  key={s.slug}
                  to={s.base}
                  className="rounded-full border px-4 py-2 text-sm hover:border-primary hover:text-primary"
                >
                  {s.label}
                </Link>
              ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default ServiceHubPage;
