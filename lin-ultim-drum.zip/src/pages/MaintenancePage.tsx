import { useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";

const MaintenancePage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const SECRET_KEY = "funerio2025"; // Schimbă această cheie secretă

  useEffect(() => {
    // Verifică dacă utilizatorul are cheia secretă în URL
    const bypassKey = searchParams.get("access");
    const hasAccess = sessionStorage.getItem("maintenance_bypass");

    if (bypassKey === SECRET_KEY) {
      sessionStorage.setItem("maintenance_bypass", "true");
      navigate("/");
    } else if (hasAccess === "true") {
      navigate("/");
    }
  }, [searchParams, navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 via-background to-secondary/10">
      <div className="max-w-md w-full mx-4">
        <div className="bg-card border border-border rounded-lg shadow-lg p-8 text-center">
          <div className="mb-6">
            <div className="w-20 h-20 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
              <svg
                className="w-10 h-10 text-primary"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"
                />
              </svg>
            </div>
          </div>
          
          <h1 className="text-3xl font-bold text-foreground mb-3">
            Pagină în lucru
          </h1>
          
          <p className="text-muted-foreground mb-6">
            Lucrăm pentru a vă oferi cea mai bună experiență. Vă mulțumim pentru răbdare!
          </p>
          
          <div className="bg-muted/50 rounded-lg p-4">
            <p className="text-sm text-muted-foreground">
              Site-ul va fi disponibil în curând
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MaintenancePage;
