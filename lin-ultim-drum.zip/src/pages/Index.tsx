import { Link } from "react-router-dom";
import Navigation from "@/components/Navigation";
import Seo from "@/components/Seo";
import HomeWizard from "@/components/HomeWizard";
import { articles } from "@/content/articles";
import { landingCities } from "@/content/serviceLandings";
import { slugify } from "@/lib/slug";

const topCities = landingCities.slice(0, 12).map((c) => c.city);


const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Seo
        title="Funerio — Servicii funerare verificate în România"
        description="Compară firme de pompe funebre verificate. Prețuri transparente, oferte rapide, disponibili 24/7."
      />
      <Navigation />

      <main>
        <section className="bg-gradient-to-b from-secondary/50 to-background py-8 md:py-12">
          <div className="container mx-auto px-4 sm:px-6">
            <div className="mx-auto max-w-2xl">
              <blockquote className="mb-7 text-center text-lg italic text-foreground sm:text-xl md:text-2xl">
                În momentele grele, <span className="text-primary font-semibold">Funerio</span> îți oferă sprijinul de
                care ai nevoie pentru a găsi servicii funerare de încredere.
              </blockquote>
              <HomeWizard />
            </div>
          </div>
        </section>
      </main>

      <section className="border-t bg-secondary/20 py-10">
        <div className="container mx-auto px-4 sm:px-6">
          <h2 className="mb-4 text-xl font-semibold">Servicii funerare în orașele mari</h2>
          <div className="mb-8 flex flex-wrap gap-2">
            {topCities.map((city) => (
              <Link
                key={city}
                to={`/servicii-funerare/${slugify(city)}`}
                className="rounded-full border px-4 py-2 text-sm hover:border-primary hover:text-primary"
              >
                Servicii funerare {city}
              </Link>
            ))}
            <Link
              to="/servicii"
              className="rounded-full border px-4 py-2 text-sm hover:border-primary hover:text-primary"
            >
              Vezi toate orașele
            </Link>
          </div>

          <h2 className="mb-4 text-xl font-semibold">Ghiduri utile</h2>
          <ul className="grid gap-2 md:grid-cols-2 lg:grid-cols-3">
            {articles.slice(0, 6).map((a) => (
              <li key={a.slug}>
                <Link to={`/articole/${a.slug}`} className="text-sm text-primary hover:underline">
                  {a.title}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t py-8 sm:py-12">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8 mb-6 sm:mb-8">
            <div>
              <h4 className="font-semibold mb-4">Funerio</h4>
              <p className="text-sm text-muted-foreground">
                Platforma care te ajută să găsești cele mai bune servicii funerare din România.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Link-uri Rapide</h4>
              <div className="space-y-2">
                <Link to="/" className="block text-sm text-muted-foreground hover:text-primary">Acasă</Link>
                <Link to="/firme" className="block text-sm text-muted-foreground hover:text-primary">Firme</Link>
                <Link to="/servicii" className="block text-sm text-muted-foreground hover:text-primary">Servicii</Link>
                <Link to="/articole" className="block text-sm text-muted-foreground hover:text-primary">Articole</Link>
                <Link to="/contact" className="block text-sm text-muted-foreground hover:text-primary">Contact</Link>
                <Link to="/faq" className="block text-sm text-muted-foreground hover:text-primary">Întrebări Frecvente</Link>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <div className="space-y-2">
                <Link to="/terms" className="block text-sm text-muted-foreground hover:text-primary">Termeni și Condiții</Link>
                <Link to="/privacy" className="block text-sm text-muted-foreground hover:text-primary">Politica de Confidențialitate</Link>
                <Link to="/gdpr" className="block text-sm text-muted-foreground hover:text-primary">GDPR</Link>
                <Link to="/return-policy" className="block text-sm text-muted-foreground hover:text-primary">Politica de Retur</Link>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <p className="text-sm text-muted-foreground">Email: contact@funerio.ro</p>
              <p className="text-sm text-muted-foreground">Telefon: 0800 123 456</p>
              <p className="text-sm text-muted-foreground">Program: 24/7</p>
            </div>
          </div>
          <div className="text-center text-sm text-muted-foreground border-t pt-8">
            © 2025 Funerio. Toate drepturile rezervate.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
