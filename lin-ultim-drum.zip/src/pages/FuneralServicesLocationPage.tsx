import { useParams } from "react-router-dom";
import ServiceLandingPage from "./ServiceLandingPage";
import CountyLandingPage from "./CountyLandingPage";
import { getCityBySlug } from "@/content/serviceLandings";

/** /servicii-funerare/:slug — resolves to a city landing page or a county hub. */
const FuneralServicesLocationPage = () => {
  const { slug = "" } = useParams();
  if (getCityBySlug(slug)) return <ServiceLandingPage landingSlug="servicii-funerare" />;
  return <CountyLandingPage />;
};

export default FuneralServicesLocationPage;
