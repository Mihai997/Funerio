import { Link } from "react-router-dom";
import Navigation from "@/components/Navigation";
import Seo from "@/components/Seo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Phone, Mail, MapPin, Clock, Building2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { z } from "zod";
import { useState } from "react";

const contactSchema = z.object({
  name: z.string().trim().min(2, "Numele trebuie să aibă cel puțin 2 caractere").max(100, "Numele este prea lung"),
  email: z.string().trim().email("Email invalid").max(255, "Email-ul este prea lung"),
  phone: z.string().trim().min(10, "Numărul de telefon trebuie să aibă cel puțin 10 cifre").max(20, "Numărul de telefon este prea lung"),
  companyName: z.string().trim().min(2, "Numele firmei trebuie să aibă cel puțin 2 caractere").max(200, "Numele firmei este prea lung"),
  city: z.string().trim().min(2, "Orașul trebuie să aibă cel puțin 2 caractere").max(100, "Orașul este prea lung"),
  county: z.string().trim().min(2, "Județul trebuie să aibă cel puțin 2 caractere").max(100, "Județul este prea lung"),
  message: z.string().trim().max(2000, "Mesajul este prea lung").optional(),
});

const ContactPage = () => {
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);

    const form = e.currentTarget;

    try {
      const formData = new FormData(form);
      const data = {
        name: formData.get("name") as string,
        email: formData.get("email") as string,
        phone: formData.get("phone") as string,
        companyName: formData.get("companyName") as string,
        city: formData.get("city") as string,
        county: formData.get("county") as string,
        message: (formData.get("message") as string) || "",
      };

      const validatedData = contactSchema.parse(data);

      const emailData = {
        name: validatedData.name,
        email: validatedData.email,
        phone: validatedData.phone,
        companyName: validatedData.companyName,
        message: `Locație: ${validatedData.city}, Județul ${validatedData.county}\n\n${validatedData.message || "Doresc să mă înscriu pe platforma Funerio."}`,
      };

      const { error } = await supabase.functions.invoke("send-contact-email", {
        body: emailData,
      });

      if (error) throw error;

      toast.success("Cererea a fost trimisă cu succes! Vă vom contacta în curând.");
      form.reset();
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
      } else {
        console.error("Error sending contact email:", error);
        toast.error("A apărut o eroare. Vă rugăm încercați din nou.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Seo
        title="Contact Funerio — Înscrie-ți firma"
        description="Contactează echipa Funerio: telefon, email și formular de înscriere pentru firmele de servicii funerare."
      />
      <Navigation />

      <div className="container mx-auto px-4 py-12">
        <div className="mx-auto max-w-6xl">
          <div className="mb-10 text-center">
            <h1 className="mb-3 text-4xl font-bold">Contact</h1>
            <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
              Scrie-ne sau sună-ne. Îți răspundem în maxim 24 de ore.
            </p>
          </div>

          <div className="grid gap-8 lg:grid-cols-2">
            {/* Registration Form */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-primary" />
                  Formular de Înscriere
                </CardTitle>
                <p className="mt-2 text-sm text-muted-foreground">
                  Completează datele de mai jos și te vom contacta pentru a finaliza înscrierea.
                </p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="companyName">Nume Firmă *</Label>
                    <Input
                      id="companyName"
                      name="companyName"
                      placeholder="Ex: Pompe Funebre Exemplu SRL"
                      required
                      disabled={isLoading}
                    />
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="city">Oraș *</Label>
                      <Input id="city" name="city" placeholder="Ex: București" required disabled={isLoading} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="county">Județ *</Label>
                      <Input id="county" name="county" placeholder="Ex: Ilfov" required disabled={isLoading} />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="name">Persoană de Contact *</Label>
                    <Input id="name" name="name" placeholder="Numele dumneavoastră" required disabled={isLoading} />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="contact@firma.ro"
                      required
                      disabled={isLoading}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Telefon *</Label>
                    <Input
                      id="phone"
                      name="phone"
                      type="tel"
                      placeholder="07XX XXX XXX"
                      required
                      disabled={isLoading}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message">Mesaj (opțional)</Label>
                    <Textarea
                      id="message"
                      name="message"
                      placeholder="Adaugă orice informații suplimentare despre firma ta..."
                      className="min-h-[100px]"
                      disabled={isLoading}
                    />
                  </div>

                  <Button type="submit" className="w-full" size="lg" disabled={isLoading}>
                    {isLoading ? "Se trimite..." : "Trimite Cererea de Înscriere"}
                  </Button>

                  <p className="text-center text-xs text-muted-foreground">
                    Prin trimiterea formularului ești de acord cu{" "}
                    <a href="/termeni" className="underline hover:text-primary">
                      termenii și condițiile
                    </a>{" "}
                    și{" "}
                    <a href="/gdpr" className="underline hover:text-primary">
                      politica GDPR
                    </a>
                  </p>
                </form>
              </CardContent>
            </Card>

            {/* Contact Information */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Date de Contact</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start gap-4">
                    <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-full bg-primary/10">
                      <Phone className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="mb-1 font-semibold">Telefon</h3>
                      <p className="text-muted-foreground">0800 123 456</p>
                      <p className="mt-1 text-sm text-muted-foreground">Luni - Vineri, 09:00 - 18:00</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-full bg-primary/10">
                      <Mail className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="mb-1 font-semibold">Email</h3>
                      <p className="text-muted-foreground">contact@funerio.ro</p>
                      <p className="mt-1 text-sm text-muted-foreground">Răspundem în maxim 24 de ore</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-full bg-primary/10">
                      <MapPin className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="mb-1 font-semibold">Sediu</h3>
                      <p className="text-muted-foreground">București, România</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-secondary/30">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-full bg-primary/10">
                      <Clock className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="mb-2 font-semibold">Proces Rapid de Activare</h3>
                      <p className="text-sm text-muted-foreground">
                        După primirea cererii, echipa noastră te va contacta în maxim 24 de ore pentru a-ți activa
                        contul și a te ghida în configurarea profilului firmei.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="flex flex-col items-start gap-3 pt-6">
                  <h3 className="font-semibold">Vrei să vezi pachetele pentru parteneri?</h3>
                  <p className="text-sm text-muted-foreground">
                    Compară pachetele Standard și Premium și alege ce ți se potrivește.
                  </p>
                  <Link to="/parteneri">
                    <Button variant="outline" className="rounded-full">
                      Vezi pachetele
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;
