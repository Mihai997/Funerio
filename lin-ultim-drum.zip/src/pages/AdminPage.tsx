import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Session } from "@supabase/supabase-js";
import Navigation from "@/components/Navigation";
import { toast } from "sonner";
import DoveLoader from "@/components/brand/DoveLoader";
import CallLogsTable from "@/components/CallLogsTable";
import AdminStats from "@/components/admin/AdminStats";
import FirmScoreTable from "@/components/admin/FirmScoreTable";


interface FuneralHome {
  id: string;
  name: string;
  city: string;
  county: string;
  email: string;
  phone: string;
}

const AdminPage = () => {
  const navigate = useNavigate();
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [funeralHomes, setFuneralHomes] = useState<FuneralHome[]>([]);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);

      if (event === "SIGNED_OUT") {
        setIsAdmin(false);
        navigate("/auth");
      }
    });

    const initializePage = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setSession(session);

      if (!session) {
        setLoading(false);
        navigate("/auth");
        return;
      }

      await checkAdminRole(session.user.id);
    };

    void initializePage();

    return () => subscription.unsubscribe();
  }, [navigate]);

  const checkAdminRole = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", userId)
        .eq("role", "admin")
        .maybeSingle();

      if (error) throw error;

      if (!data) {
        toast.error("Nu aveți permisiuni de administrator.");
        navigate("/");
        return;
      }

      setIsAdmin(true);
      await loadFuneralHomes();
    } catch (error) {
      console.error("Error checking admin role:", error);
      toast.error("Eroare la verificarea rolului.");
      navigate("/");
    } finally {
      setLoading(false);
    }
  };

  const loadFuneralHomes = async () => {
    try {
      const { data, error } = await supabase
        .from("funeral_homes")
        .select("id, name, city, county, email, phone")
        .order("name", { ascending: true });

      if (error) throw error;

      setFuneralHomes(data || []);
    } catch (error) {
      console.error("Error loading funeral homes:", error);
      toast.error("Eroare la încărcarea firmelor.");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="flex items-center justify-center h-[calc(100vh-80px)]">
          <DoveLoader label="Se încarcă administrarea" />
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Gestionați apelurile și lead-urile din platformă
          </p>
        </div>

        <div className="space-y-8">
          <AdminStats />

          <FirmScoreTable />

          <CallLogsTable
            showFuneralHomeName={true}
            limit={20}
            title="Toate Apelurile (Leads)"
            funeralHomes={funeralHomes.map(h => ({ id: h.id, name: h.name }))}
          />
        </div>

      </div>
    </div>
  );
};

export default AdminPage;
