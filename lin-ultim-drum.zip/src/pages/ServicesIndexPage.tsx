import { Link } from "react-router-dom";
import Navigation from "@/components/Navigation";
import Seo from "@/components/Seo";
import { slugify } from "@/lib/slug";
import { landingCities, serviceLandings } from "@/content/serviceLandings";

const SITE_URL = "https://funerio.ro";

const counties = Array.from(new Set(landingCities.map((c) => c.county))).sort((a, b) =>
  a.localeCompare(b, "ro")
);

const ServicesIndexPage = () => {
  const jsonLd = [
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "Acasă", item: `${SITE_URL}/` },
        { "@type": "ListItem", position: 2, name: "Servicii", item: `${SITE_URL}/servicii` },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Seo
        title="Servicii funerare pe orașe și tipuri | Funerio"
        description="Toate serviciile funerare disponibile pe Funerio, organizate pe tip de serviciu, oraș și județ. Găsește rapid firmele din zona ta."
        jsonLd={jsonLd}
      />
      <Navigation />

      <div className="container mx-auto px-4 py-8 sm:px-6">
        <header className="mb-10 max-w-3xl mx-auto text-center">
          <h1 className="mb-3 text-2xl font-bold md:text-4xl">Servicii funerare în România</h1>
          <p className="text-sm text-muted-foreground md:text-lg">
            Alege tipul de serviciu sau orașul pentru a vedea firmele verificate, prețurile de pornire și
            disponibilitatea.
          </p>
        </header>

        <section className="mb-12">
          <h2 className="mb-4 text-xl font-semibold">Tipuri de servicii</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {serviceLandings.map((s) => (
              <Link
                key={s.slug}
                to={s.base}
                className="rounded-xl border p-5 transition-colors hover:border-primary"
              >
                <h3 className="mb-1 font-semibold">{s.label}</h3>
                <p className="text-sm text-muted-foreground">
                  {s.intro.replace(/\{city\}/g, "orașul tău").replace(/\{county\}/g, "județul tău")}
                </p>
              </Link>
            ))}
          </div>
        </section>

        <section className="mb-12">
          <h2 className="mb-4 text-xl font-semibold">Servicii funerare pe orașe</h2>
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {landingCities.map((c) => (
              <Link
                key={c.city}
                to={`/servicii-funerare/${slugify(c.city)}`}
                className="rounded-lg border px-4 py-3 text-sm hover:border-primary hover:text-primary"
              >
                Servicii funerare {c.city}
              </Link>
            ))}
          </div>
        </section>

        <section>
          <h2 className="mb-4 text-xl font-semibold">Servicii funerare pe județe</h2>
          <div className="flex flex-wrap gap-2">
            {counties.map((county) => (
              <Link
                key={county}
                to={`/servicii-funerare/${slugify(county)}`}
                className="rounded-full border px-4 py-2 text-sm hover:border-primary hover:text-primary"
              >
                {county}
              </Link>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default ServicesIndexPage;
