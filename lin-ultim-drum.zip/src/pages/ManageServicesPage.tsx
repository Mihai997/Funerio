import { useEffect, useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import Navigation from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, ArrowLeft, Package, Search, ArrowUpDown, ArrowUp, ArrowDown, Percent } from "lucide-react";
import { serviceCategories, ServiceCategory } from "@/types/funeral";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import DoveLoader from "@/components/brand/DoveLoader";
import BrandState from "@/components/brand/BrandState";

interface Service {
  id: string;
  name: string;
  description: string;
  price: number;
  price_unit: string;
  category: ServiceCategory;
}

interface PackageData {
  id: string;
  name: string;
  description: string;
  price: number;
}

type SortField = "name" | "price" | "category";
type SortDir = "asc" | "desc";

const ManageServicesPage = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [funeralHomeId, setFuneralHomeId] = useState<string | null>(null);
  const [services, setServices] = useState<Service[]>([]);
  const [packages, setPackages] = useState<PackageData[]>([]);

  // Search, filter, sort
  const [searchQuery, setSearchQuery] = useState("");
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [sortField, setSortField] = useState<SortField>("name");
  const [sortDir, setSortDir] = useState<SortDir>("asc");

  // Inline price editing
  const [editingPriceId, setEditingPriceId] = useState<string | null>(null);
  const [editingPriceValue, setEditingPriceValue] = useState("");

  // Bulk selection
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkPriceDialogOpen, setBulkPriceDialogOpen] = useState(false);
  const [bulkPricePercent, setBulkPricePercent] = useState("");
  const [bulkPriceDirection, setBulkPriceDirection] = useState<"increase" | "decrease">("increase");

  // Delete confirmation
  const [deleteTarget, setDeleteTarget] = useState<{ type: "service" | "package" | "bulk"; id?: string } | null>(null);

  // Service form state
  const [serviceDialogOpen, setServiceDialogOpen] = useState(false);
  const [editingService, setEditingService] = useState<Service | null>(null);
  const [serviceName, setServiceName] = useState("");
  const [serviceDescription, setServiceDescription] = useState("");
  const [servicePrice, setServicePrice] = useState("");
  const [servicePriceUnit, setServicePriceUnit] = useState("buc");
  const [serviceCategory, setServiceCategory] = useState<ServiceCategory>("transport");
  const [duplicateWarning, setDuplicateWarning] = useState(false);

  // Package form state
  const [packageDialogOpen, setPackageDialogOpen] = useState(false);
  const [editingPackage, setEditingPackage] = useState<PackageData | null>(null);
  const [packageName, setPackageName] = useState("");
  const [packageDescription, setPackageDescription] = useState("");
  const [packagePrice, setPackagePrice] = useState("");
  const [selectedServices, setSelectedServices] = useState<string[]>([]);

  useEffect(() => {
    checkAuthAndLoadData();
  }, []);

  // Duplicate name check
  useEffect(() => {
    if (!serviceName.trim()) {
      setDuplicateWarning(false);
      return;
    }
    const isDuplicate = services.some(
      (s) => s.name.toLowerCase() === serviceName.trim().toLowerCase() && s.id !== editingService?.id
    );
    setDuplicateWarning(isDuplicate);
  }, [serviceName, services, editingService]);

  const checkAuthAndLoadData = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) { navigate("/auth"); return; }

      const { data: fhData, error: fhError } = await supabase
        .from("funeral_homes")
        .select("id")
        .eq("owner_id", session.user.id)
        .maybeSingle();

      if (fhError) throw fhError;
      if (!fhData) {
        toast.error("Nu există o firmă asociată acestui cont.");
        navigate("/dashboard");
        return;
      }

      setFuneralHomeId(fhData.id);
      await loadServices(fhData.id);
      await loadPackages(fhData.id);
      setLoading(false);
    } catch (error) {
      console.error("Error:", error);
      toast.error("Eroare la încărcarea datelor.");
      setLoading(false);
    }
  };

  const loadServices = async (fhId: string) => {
    const { data, error } = await supabase
      .from("services")
      .select("*")
      .eq("funeral_home_id", fhId)
      .order("name");

    if (error) {
      console.error("Error loading services:", error);
      toast.error("Eroare la încărcarea serviciilor.");
    } else {
      setServices(data || []);
    }
  };

  const loadPackages = async (fhId: string) => {
    const { data, error } = await supabase
      .from("packages")
      .select(`*, package_services(service_id)`)
      .eq("funeral_home_id", fhId)
      .order("name");

    if (error) {
      console.error("Error loading packages:", error);
      toast.error("Eroare la încărcarea pachetelor.");
    } else {
      setPackages(data || []);
    }
  };

  // Filtered & sorted services
  const filteredServices = useMemo(() => {
    let result = services.filter((s) => {
      const matchesSearch = s.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = filterCategory === "all" || s.category === filterCategory;
      return matchesSearch && matchesCategory;
    });

    result.sort((a, b) => {
      let cmp = 0;
      if (sortField === "name") cmp = a.name.localeCompare(b.name, "ro");
      else if (sortField === "price") cmp = a.price - b.price;
      else if (sortField === "category") cmp = a.category.localeCompare(b.category);
      return sortDir === "asc" ? cmp : -cmp;
    });

    return result;
  }, [services, searchQuery, filterCategory, sortField, sortDir]);

  // Category counts
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    services.forEach((s) => {
      counts[s.category] = (counts[s.category] || 0) + 1;
    });
    return counts;
  }, [services]);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortField(field);
      setSortDir("asc");
    }
  };

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <ArrowUpDown className="h-3 w-3 ml-1 opacity-40" />;
    return sortDir === "asc" ? <ArrowUp className="h-3 w-3 ml-1" /> : <ArrowDown className="h-3 w-3 ml-1" />;
  };

  // Inline price save
  const handleInlinePriceSave = async (serviceId: string) => {
    const newPrice = parseFloat(editingPriceValue);
    if (isNaN(newPrice) || newPrice < 0) {
      toast.error("Preț invalid.");
      setEditingPriceId(null);
      return;
    }

    try {
      const { error } = await supabase.from("services").update({ price: newPrice }).eq("id", serviceId);
      if (error) throw error;
      setServices((prev) => prev.map((s) => (s.id === serviceId ? { ...s, price: newPrice } : s)));
      toast.success("Preț actualizat!");
    } catch {
      toast.error("Eroare la actualizarea prețului.");
    }
    setEditingPriceId(null);
  };

  // Bulk selection
  const toggleSelectAll = () => {
    if (selectedIds.size === filteredServices.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredServices.map((s) => s.id)));
    }
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  // Bulk delete
  const handleBulkDelete = async () => {
    if (!funeralHomeId) return;
    try {
      const { error } = await supabase.from("services").delete().in("id", Array.from(selectedIds));
      if (error) throw error;
      toast.success(`${selectedIds.size} servicii șterse!`);
      setSelectedIds(new Set());
      loadServices(funeralHomeId);
    } catch {
      toast.error("Eroare la ștergerea serviciilor.");
    }
    setDeleteTarget(null);
  };

  // Bulk price adjust
  const handleBulkPriceAdjust = async () => {
    if (!funeralHomeId) return;
    const percent = parseFloat(bulkPricePercent);
    if (isNaN(percent) || percent <= 0) {
      toast.error("Introduceți un procent valid.");
      return;
    }

    const multiplier = bulkPriceDirection === "increase" ? 1 + percent / 100 : 1 - percent / 100;

    try {
      const updates = services
        .filter((s) => selectedIds.has(s.id))
        .map((s) => supabase.from("services").update({ price: Math.round(s.price * multiplier * 100) / 100 }).eq("id", s.id));

      await Promise.all(updates);
      toast.success(`Prețuri ajustate cu ${percent}%!`);
      setBulkPriceDialogOpen(false);
      setBulkPricePercent("");
      setSelectedIds(new Set());
      loadServices(funeralHomeId);
    } catch {
      toast.error("Eroare la ajustarea prețurilor.");
    }
  };

  // Confirm delete handler
  const confirmDelete = async () => {
    if (!deleteTarget) return;
    if (deleteTarget.type === "bulk") {
      await handleBulkDelete();
      return;
    }

    try {
      const table = deleteTarget.type === "service" ? "services" : "packages";
      const { error } = await supabase.from(table).delete().eq("id", deleteTarget.id!);
      if (error) throw error;
      toast.success(`${deleteTarget.type === "service" ? "Serviciu" : "Pachet"} șters cu succes!`);
      if (funeralHomeId) {
        if (deleteTarget.type === "service") loadServices(funeralHomeId);
        else loadPackages(funeralHomeId);
      }
    } catch {
      toast.error("Eroare la ștergere.");
    }
    setDeleteTarget(null);
  };

  const handleSaveService = async () => {
    if (!funeralHomeId) return;
    if (!serviceName || !servicePrice) {
      toast.error("Completați toate câmpurile obligatorii.");
      return;
    }

    try {
      const serviceData = {
        name: serviceName,
        description: serviceDescription,
        price: parseFloat(servicePrice),
        price_unit: servicePriceUnit,
        category: serviceCategory,
        funeral_home_id: funeralHomeId,
      };

      if (editingService) {
        const { error } = await supabase.from("services").update(serviceData).eq("id", editingService.id);
        if (error) throw error;
        toast.success("Serviciu actualizat cu succes!");
      } else {
        const { error } = await supabase.from("services").insert(serviceData);
        if (error) throw error;
        toast.success("Serviciu adăugat cu succes!");
      }

      setServiceDialogOpen(false);
      resetServiceForm();
      loadServices(funeralHomeId);
    } catch (error) {
      console.error("Error saving service:", error);
      toast.error("Eroare la salvarea serviciului.");
    }
  };

  const handleEditService = (service: Service) => {
    setEditingService(service);
    setServiceName(service.name);
    setServiceDescription(service.description);
    setServicePrice(service.price.toString());
    setServicePriceUnit(service.price_unit);
    setServiceCategory(service.category);
    setServiceDialogOpen(true);
  };

  const resetServiceForm = () => {
    setEditingService(null);
    setServiceName("");
    setServiceDescription("");
    setServicePrice("");
    setServicePriceUnit("buc");
    setServiceCategory("transport");
    setDuplicateWarning(false);
  };

  const handleSavePackage = async () => {
    if (!funeralHomeId) return;
    if (!packageName || !packagePrice) {
      toast.error("Completați toate câmpurile obligatorii.");
      return;
    }

    try {
      const packageData = {
        name: packageName,
        description: packageDescription,
        price: parseFloat(packagePrice),
        funeral_home_id: funeralHomeId,
      };

      let packageId: string;

      if (editingPackage) {
        const { error } = await supabase.from("packages").update(packageData).eq("id", editingPackage.id);
        if (error) throw error;
        packageId = editingPackage.id;
        await supabase.from("package_services").delete().eq("package_id", packageId);
        toast.success("Pachet actualizat cu succes!");
      } else {
        const { data, error } = await supabase.from("packages").insert(packageData).select().single();
        if (error) throw error;
        packageId = data.id;
        toast.success("Pachet adăugat cu succes!");
      }

      if (selectedServices.length > 0) {
        const packageServicesData = selectedServices.map((serviceId) => ({
          package_id: packageId,
          service_id: serviceId,
        }));
        const { error: psError } = await supabase.from("package_services").insert(packageServicesData);
        if (psError) throw psError;
      }

      setPackageDialogOpen(false);
      resetPackageForm();
      loadPackages(funeralHomeId);
    } catch (error) {
      console.error("Error saving package:", error);
      toast.error("Eroare la salvarea pachetului.");
    }
  };

  const handleEditPackage = async (pkg: PackageData) => {
    setEditingPackage(pkg);
    setPackageName(pkg.name);
    setPackageDescription(pkg.description);
    setPackagePrice(pkg.price.toString());

    const { data } = await supabase.from("package_services").select("service_id").eq("package_id", pkg.id);
    if (data) setSelectedServices(data.map((ps) => ps.service_id));

    setPackageDialogOpen(true);
  };

  const resetPackageForm = () => {
    setEditingPackage(null);
    setPackageName("");
    setPackageDescription("");
    setPackagePrice("");
    setSelectedServices([]);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="flex items-center justify-center h-[calc(100vh-80px)]">
          <DoveLoader label="Se încarcă serviciile" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <Button variant="outline" onClick={() => navigate("/dashboard")} size="lg" className="mb-4 gap-2 text-base">
            <ArrowLeft className="h-5 w-5" />
            Înapoi
          </Button>
          <h1 className="text-xl md:text-3xl font-bold">Gestionare Servicii și Pachete</h1>
        </div>

        <Tabs defaultValue="services" className="space-y-6">
          <TabsList>
            <TabsTrigger value="services">Servicii ({services.length})</TabsTrigger>
            <TabsTrigger value="packages">Pachete ({packages.length})</TabsTrigger>
          </TabsList>

          {/* ===== SERVICES TAB ===== */}
          <TabsContent value="services">
            <Card>
              <CardHeader>
                <div className="flex flex-col gap-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Servicii</CardTitle>
                      <CardDescription>Gestionați serviciile oferite de firma dvs.</CardDescription>
                    </div>
                    <Dialog open={serviceDialogOpen} onOpenChange={(open) => { setServiceDialogOpen(open); if (!open) resetServiceForm(); }}>
                      <DialogTrigger asChild>
                        <Button>
                          <Plus className="h-4 w-4 mr-2" />
                          Adaugă Serviciu
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>{editingService ? "Editează Serviciu" : "Adaugă Serviciu Nou"}</DialogTitle>
                          <DialogDescription>Completați informațiile despre serviciu.</DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="service-name">Nume *</Label>
                            <Input id="service-name" value={serviceName} onChange={(e) => setServiceName(e.target.value)} />
                            {duplicateWarning && (
                              <p className="text-sm text-destructive mt-1">⚠ Un serviciu cu acest nume există deja.</p>
                            )}
                          </div>
                          <div>
                            <Label htmlFor="service-description">Descriere</Label>
                            <Textarea id="service-description" value={serviceDescription} onChange={(e) => setServiceDescription(e.target.value)} />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label htmlFor="service-price">Preț (RON) *</Label>
                              <Input id="service-price" type="number" step="0.01" value={servicePrice} onChange={(e) => setServicePrice(e.target.value)} />
                            </div>
                            <div>
                              <Label htmlFor="service-unit">Unitate</Label>
                              <Input id="service-unit" value={servicePriceUnit} onChange={(e) => setServicePriceUnit(e.target.value)} placeholder="buc, km, oră" />
                            </div>
                          </div>
                          <div>
                            <Label htmlFor="service-category">Categorie</Label>
                            <Select value={serviceCategory} onValueChange={(value) => setServiceCategory(value as ServiceCategory)}>
                              <SelectTrigger id="service-category"><SelectValue /></SelectTrigger>
                              <SelectContent>
                                {serviceCategories.map((cat) => (
                                  <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setServiceDialogOpen(false)}>Anulează</Button>
                          <Button onClick={handleSaveService}>{editingService ? "Actualizează" : "Adaugă"}</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>

                  {/* Search + Filter row */}
                  <div className="flex flex-col sm:flex-row gap-3">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Caută serviciu..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-9"
                      />
                    </div>
                    <Select value={filterCategory} onValueChange={setFilterCategory}>
                      <SelectTrigger className="w-full sm:w-[200px]">
                        <SelectValue placeholder="Toate categoriile" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Toate categoriile</SelectItem>
                        {serviceCategories.map((cat) => (
                          <SelectItem key={cat.value} value={cat.value}>
                            {cat.label} ({categoryCounts[cat.value] || 0})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Category badges summary */}
                  {services.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {serviceCategories
                        .filter((cat) => categoryCounts[cat.value])
                        .map((cat) => (
                          <Badge
                            key={cat.value}
                            variant={filterCategory === cat.value ? "default" : "secondary"}
                            className="cursor-pointer"
                            onClick={() => setFilterCategory(filterCategory === cat.value ? "all" : cat.value)}
                          >
                            {cat.label}: {categoryCounts[cat.value]}
                          </Badge>
                        ))}
                    </div>
                  )}

                  {/* Bulk actions */}
                  {selectedIds.size > 0 && (
                    <div className="flex items-center gap-3 p-3 rounded-md bg-muted">
                      <span className="text-sm font-medium">{selectedIds.size} selectate</span>
                      <Button variant="destructive" size="sm" onClick={() => setDeleteTarget({ type: "bulk" })}>
                        <Trash2 className="h-3 w-3 mr-1" /> Șterge
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => setBulkPriceDialogOpen(true)}>
                        <Percent className="h-3 w-3 mr-1" /> Ajustare preț
                      </Button>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {filteredServices.length === 0 ? (
                  <BrandState title={services.length === 0 ? "Nu există servicii adăugate încă." : "Niciun serviciu nu corespunde filtrelor."} />
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-10">
                          <Checkbox
                            checked={selectedIds.size === filteredServices.length && filteredServices.length > 0}
                            onCheckedChange={toggleSelectAll}
                          />
                        </TableHead>
                        <TableHead className="cursor-pointer select-none" onClick={() => toggleSort("name")}>
                          <span className="flex items-center">Nume <SortIcon field="name" /></span>
                        </TableHead>
                        <TableHead className="cursor-pointer select-none" onClick={() => toggleSort("category")}>
                          <span className="flex items-center">Categorie <SortIcon field="category" /></span>
                        </TableHead>
                        <TableHead>Descriere</TableHead>
                        <TableHead className="text-right cursor-pointer select-none" onClick={() => toggleSort("price")}>
                          <span className="flex items-center justify-end">Preț <SortIcon field="price" /></span>
                        </TableHead>
                        <TableHead className="text-right">Acțiuni</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredServices.map((service) => (
                        <TableRow key={service.id} data-state={selectedIds.has(service.id) ? "selected" : undefined}>
                          <TableCell>
                            <Checkbox
                              checked={selectedIds.has(service.id)}
                              onCheckedChange={() => toggleSelect(service.id)}
                            />
                          </TableCell>
                          <TableCell className="font-medium">{service.name}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{serviceCategories.find((c) => c.value === service.category)?.label}</Badge>
                          </TableCell>
                          <TableCell className="max-w-md truncate">{service.description}</TableCell>
                          <TableCell className="text-right">
                            {editingPriceId === service.id ? (
                              <Input
                                type="number"
                                step="0.01"
                                value={editingPriceValue}
                                onChange={(e) => setEditingPriceValue(e.target.value)}
                                onBlur={() => handleInlinePriceSave(service.id)}
                                onKeyDown={(e) => {
                                  if (e.key === "Enter") handleInlinePriceSave(service.id);
                                  if (e.key === "Escape") setEditingPriceId(null);
                                }}
                                className="w-24 ml-auto text-right h-8"
                                autoFocus
                              />
                            ) : (
                              <span
                                className="cursor-pointer hover:underline hover:text-primary transition-colors"
                                onClick={() => {
                                  setEditingPriceId(service.id);
                                  setEditingPriceValue(service.price.toString());
                                }}
                                title="Click pentru a edita prețul"
                              >
                                {service.price} RON/{service.price_unit}
                              </span>
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-1">
                              <Button variant="ghost" size="sm" onClick={() => handleEditService(service)}>
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="sm" onClick={() => setDeleteTarget({ type: "service", id: service.id })}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ===== PACKAGES TAB ===== */}
          <TabsContent value="packages">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Pachete</CardTitle>
                    <CardDescription>Gestionați pachetele de servicii oferite.</CardDescription>
                  </div>
                  <Dialog open={packageDialogOpen} onOpenChange={(open) => { setPackageDialogOpen(open); if (!open) resetPackageForm(); }}>
                    <DialogTrigger asChild>
                      <Button>
                        <Package className="h-4 w-4 mr-2" />
                        Adaugă Pachet
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>{editingPackage ? "Editează Pachet" : "Adaugă Pachet Nou"}</DialogTitle>
                        <DialogDescription>Completați informațiile despre pachet.</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="package-name">Nume *</Label>
                          <Input id="package-name" value={packageName} onChange={(e) => setPackageName(e.target.value)} />
                        </div>
                        <div>
                          <Label htmlFor="package-description">Descriere</Label>
                          <Textarea id="package-description" value={packageDescription} onChange={(e) => setPackageDescription(e.target.value)} />
                        </div>
                        <div>
                          <Label htmlFor="package-price">Preț Pachet (RON) *</Label>
                          <Input id="package-price" type="number" step="0.01" value={packagePrice} onChange={(e) => setPackagePrice(e.target.value)} />
                          {selectedServices.length > 0 && packagePrice && (
                            <div className="text-xs text-muted-foreground mt-1">
                              Valoare servicii individuale:{" "}
                              <span className="font-medium">
                                {services
                                  .filter((s) => selectedServices.includes(s.id))
                                  .reduce((sum, s) => sum + s.price, 0)
                                  .toFixed(2)}{" "}
                                RON
                              </span>
                              {" → "}
                              <span className="font-medium text-primary">
                                Economie:{" "}
                                {(
                                  services
                                    .filter((s) => selectedServices.includes(s.id))
                                    .reduce((sum, s) => sum + s.price, 0) - parseFloat(packagePrice || "0")
                                ).toFixed(2)}{" "}
                                RON
                              </span>
                            </div>
                          )}
                        </div>
                        <div>
                          <Label>Servicii Incluse</Label>
                          <div className="border rounded-md p-4 space-y-2 max-h-48 overflow-y-auto">
                            {services.length === 0 ? (
                              <p className="text-sm text-muted-foreground">Nu există servicii disponibile.</p>
                            ) : (
                              services.map((service) => (
                                <div key={service.id} className="flex items-center space-x-2">
                                  <Checkbox
                                    id={`pkg-service-${service.id}`}
                                    checked={selectedServices.includes(service.id)}
                                    onCheckedChange={(checked) => {
                                      if (checked) setSelectedServices([...selectedServices, service.id]);
                                      else setSelectedServices(selectedServices.filter((id) => id !== service.id));
                                    }}
                                  />
                                  <label htmlFor={`pkg-service-${service.id}`} className="text-sm cursor-pointer flex-1">
                                    {service.name} - {service.price} RON/{service.price_unit}
                                  </label>
                                </div>
                              ))
                            )}
                          </div>
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setPackageDialogOpen(false)}>Anulează</Button>
                        <Button onClick={handleSavePackage}>{editingPackage ? "Actualizează" : "Adaugă"}</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                {packages.length === 0 ? (
                  <BrandState title="Nu există pachete adăugate încă." />
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nume</TableHead>
                        <TableHead>Descriere</TableHead>
                        <TableHead>Servicii Incluse</TableHead>
                        <TableHead className="text-right">Valoare Servicii</TableHead>
                        <TableHead className="text-right">Preț Pachet</TableHead>
                        <TableHead className="text-right">Acțiuni</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {packages.map((pkg: any) => {
                        const packageServiceIds = (pkg.package_services || []).map((ps: any) => ps.service_id);
                        const includedServices = services.filter((s) => packageServiceIds.includes(s.id));
                        const totalServiceValue = includedServices.reduce((sum, s) => sum + s.price, 0);

                        return (
                          <TableRow key={pkg.id}>
                            <TableCell className="font-medium">{pkg.name}</TableCell>
                            <TableCell className="max-w-xs">{pkg.description}</TableCell>
                            <TableCell>
                              <div className="flex flex-wrap gap-1">
                                {includedServices.length === 0 ? (
                                  <span className="text-muted-foreground text-sm">Niciun serviciu</span>
                                ) : (
                                  includedServices.map((s) => (
                                    <Badge key={s.id} variant="secondary" className="text-xs">
                                      {s.name}
                                    </Badge>
                                  ))
                                )}
                              </div>
                            </TableCell>
                            <TableCell className="text-right text-muted-foreground">
                              {totalServiceValue > 0 ? `${totalServiceValue.toFixed(2)} RON` : "-"}
                            </TableCell>
                            <TableCell className="text-right font-medium">
                              {pkg.price} RON
                              {totalServiceValue > pkg.price && (
                                <div className="text-xs text-primary">
                                  -{(totalServiceValue - pkg.price).toFixed(2)} RON
                                </div>
                              )}
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-1">
                                <Button variant="ghost" size="sm" onClick={() => handleEditPackage(pkg)}>
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="sm" onClick={() => setDeleteTarget({ type: "package", id: pkg.id })}>
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmați ștergerea</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteTarget?.type === "bulk"
                ? `Sigur doriți să ștergeți ${selectedIds.size} servicii selectate? Această acțiune nu poate fi anulată.`
                : deleteTarget?.type === "service"
                  ? "Sigur doriți să ștergeți acest serviciu? Această acțiune nu poate fi anulată."
                  : "Sigur doriți să ștergeți acest pachet? Această acțiune nu poate fi anulată."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Anulează</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Șterge
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Bulk Price Adjustment Dialog */}
      <Dialog open={bulkPriceDialogOpen} onOpenChange={setBulkPriceDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Ajustare prețuri în masă</DialogTitle>
            <DialogDescription>
              Ajustați prețurile pentru {selectedIds.size} servicii selectate.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex gap-3">
              <Select value={bulkPriceDirection} onValueChange={(v) => setBulkPriceDirection(v as "increase" | "decrease")}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="increase">Mărire</SelectItem>
                  <SelectItem value="decrease">Reducere</SelectItem>
                </SelectContent>
              </Select>
              <div className="relative flex-1">
                <Input
                  type="number"
                  step="0.1"
                  placeholder="Procent"
                  value={bulkPricePercent}
                  onChange={(e) => setBulkPricePercent(e.target.value)}
                />
                <Percent className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBulkPriceDialogOpen(false)}>Anulează</Button>
            <Button onClick={handleBulkPriceAdjust}>Aplică</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ManageServicesPage;
