import { Link, Navigate, useParams } from "react-router-dom";
import Navigation from "@/components/Navigation";
import Seo from "@/components/Seo";
import FuneralHomeCard from "@/components/FuneralHomeCard";
import BrandState from "@/components/brand/BrandState";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronRight, Phone } from "lucide-react";
import { useFuneralHomes } from "@/hooks/useFuneralHomes";
import { slugify } from "@/lib/slug";
import {
  citiesInCounty,
  getCityBySlug,
  getLanding,
  serviceLandings,
} from "@/content/serviceLandings";
import { articles } from "@/content/articles";

const SITE_URL = "https://funerio.ro";

interface Props {
  /** Landing slug when the route has a fixed service (e.g. /servicii-funerare/:citySlug) */
  landingSlug?: string;
}

const fill = (template: string, city: string, county: string) =>
  template.replace(/\{city\}/g, city).replace(/\{county\}/g, county);

const ServiceLandingPage = ({ landingSlug }: Props) => {
  const params = useParams();
  const slug = landingSlug ?? params.serviceSlug ?? "";
  const citySlug = params.citySlug ?? params.slug ?? "";
  const landing = getLanding(slug);
  const cityEntry = getCityBySlug(citySlug);
  const { funeralHomes, loading } = useFuneralHomes();

  if (!landing) return <Navigate to="/servicii" replace />;
  if (!cityEntry) return <Navigate to={landing.base} replace />;

  const { city, county } = cityEntry;
  const path = `${landing.base}/${citySlug}`;

  const countyHomes = funeralHomes.filter((h) => h.location.county === county);
  const cityHomes = countyHomes.filter((h) => h.location.city === city);
  const relevant = (cityHomes.length > 0 ? cityHomes : countyHomes).filter((h) =>
    landing.category ? h.services.some((s) => s.category === landing.category) : true
  );
  const shown = relevant.length > 0 ? relevant : cityHomes.length > 0 ? cityHomes : countyHomes;

  const prices = shown.flatMap((h) => h.packages.map((p) => p.price)).filter((p) => p > 0);
  const minPrice = prices.length > 0 ? Math.min(...prices) : null;

  const nearby = citiesInCounty(county).filter((c) => c.city !== city).slice(0, 6);
  const faq = landing.faq.map((f) => ({ q: fill(f.q, city, county), a: fill(f.a, city, county) }));

  const jsonLd: Record<string, unknown>[] = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      name: fill(landing.h1, city, county),
      serviceType: landing.label,
      areaServed: { "@type": "City", name: city, containedInPlace: { "@type": "AdministrativeArea", name: county } },
      provider: { "@type": "Organization", name: "Funerio", url: `${SITE_URL}/` },
      description: fill(landing.metaDescription, city, county),
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "Acasă", item: `${SITE_URL}/` },
        { "@type": "ListItem", position: 2, name: landing.label, item: `${SITE_URL}${landing.base}` },
        { "@type": "ListItem", position: 3, name: city, item: `${SITE_URL}${path}` },
      ],
    },
  ];

  if (faq.length > 0) {
    jsonLd.push({
      "@context": "https://schema.org",
      "@type": "FAQPage",
      mainEntity: faq.map((f) => ({
        "@type": "Question",
        name: f.q,
        acceptedAnswer: { "@type": "Answer", text: f.a },
      })),
    });
  }

  return (
    <div className="min-h-screen bg-background">
      <Seo
        title={fill(landing.metaTitle, city, county)}
        description={fill(landing.metaDescription, city, county)}
        jsonLd={jsonLd}
        noindex={!loading && shown.length === 0}
      />
      <Navigation />

      <div className="container mx-auto px-4 py-8 sm:px-6">
        <nav aria-label="Breadcrumb" className="mb-6 flex flex-wrap items-center gap-1 text-sm text-muted-foreground">
          <Link to="/" className="hover:text-primary">Acasă</Link>
          <ChevronRight className="h-3 w-3" />
          <Link to={landing.base} className="hover:text-primary">{landing.label}</Link>
          <ChevronRight className="h-3 w-3" />
          <span className="text-foreground">{city}</span>
        </nav>

        <header className="mb-8 max-w-3xl mx-auto text-center">
          <h1 className="mb-3 text-2xl font-bold md:text-4xl">{fill(landing.h1, city, county)}</h1>
          <p className="text-sm text-muted-foreground md:text-lg">{fill(landing.intro, city, county)}</p>
          <div className="mt-5 flex flex-wrap gap-3 text-sm">
            {!loading && (
              <span className="rounded-full bg-secondary px-4 py-2">
                {shown.length} {shown.length === 1 ? "firmă disponibilă" : "firme disponibile"}
              </span>
            )}
            {minPrice !== null && (
              <span className="rounded-full bg-secondary px-4 py-2">Preț de la {minPrice} RON</span>
            )}
            <span className="rounded-full bg-secondary px-4 py-2">Disponibilitate 24/7</span>
          </div>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <Link to={`/cere-oferta?county=${encodeURIComponent(county)}&city=${encodeURIComponent(city)}`}>
              <Button size="lg" className="w-full gap-2 sm:w-auto">
                <Phone className="h-4 w-4" /> Cere ofertă în {city}
              </Button>
            </Link>
            <Link to={`/firme?county=${encodeURIComponent(county)}&city=${encodeURIComponent(city)}`}>
              <Button size="lg" variant="outline" className="w-full sm:w-auto">Vezi toate firmele</Button>
            </Link>
          </div>
        </header>

        <section className="mb-12">
          <h2 className="mb-5 text-xl font-semibold md:text-2xl">
            Firme de {landing.label.toLowerCase()} în {cityHomes.length > 0 ? city : county}
          </h2>
          {loading ? (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {[1, 2, 3].map((i) => <Skeleton key={i} className="h-72 rounded-lg" />)}
            </div>
          ) : shown.length === 0 ? (
            <BrandState
              title={`Momentan nu avem firme listate în ${city}.`}
              description="Trimite o cerere de ofertă și te punem în legătură cu firmele din zonă."
            />
          ) : (
            <>
              {cityHomes.length === 0 && (
                <p className="mb-4 text-sm text-muted-foreground">
                  Nu există încă firme cu sediul în {city}; afișăm firmele din județul {county} care deservesc zona.
                </p>
              )}
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {shown.map((home) => <FuneralHomeCard key={home.id} funeralHome={home} />)}
              </div>
            </>
          )}
        </section>

        {faq.length > 0 && (
          <section className="mb-12 max-w-3xl mx-auto">
            <h2 className="mb-5 text-xl font-semibold md:text-2xl">Întrebări frecvente</h2>
            <div className="space-y-5">
              {faq.map((f) => (
                <div key={f.q}>
                  <h3 className="mb-1 font-semibold">{f.q}</h3>
                  <p className="text-sm text-muted-foreground">{f.a}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        <section className="mb-12">
          <h2 className="mb-4 text-xl font-semibold">Alte servicii în {city}</h2>
          <div className="flex flex-wrap gap-2">
            {serviceLandings
              .filter((s) => s.slug !== landing.slug)
              .map((s) => (
                <Link
                  key={s.slug}
                  to={`${s.base}/${citySlug}`}
                  className="rounded-full border px-4 py-2 text-sm hover:border-primary hover:text-primary"
                >
                  {s.label} {city}
                </Link>
              ))}
          </div>
        </section>

        {nearby.length > 0 && (
          <section className="mb-12">
            <h2 className="mb-4 text-xl font-semibold">{landing.label} în apropiere</h2>
            <div className="flex flex-wrap gap-2">
              <Link
                to={`/servicii-funerare/${slugify(county)}`}
                className="rounded-full border px-4 py-2 text-sm hover:border-primary hover:text-primary"
              >
                Județul {county}
              </Link>
              {nearby.map((c) => (
                <Link
                  key={c.city}
                  to={`${landing.base}/${slugify(c.city)}`}
                  className="rounded-full border px-4 py-2 text-sm hover:border-primary hover:text-primary"
                >
                  {c.city}
                </Link>
              ))}
            </div>
          </section>
        )}

        <section className="mb-4">
          <h2 className="mb-4 text-xl font-semibold">Ghiduri utile</h2>
          <ul className="grid gap-2 md:grid-cols-2">
            {articles.slice(0, 4).map((a) => (
              <li key={a.slug}>
                <Link to={`/articole/${a.slug}`} className="text-sm text-primary hover:underline">
                  {a.title}
                </Link>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
};

export default ServiceLandingPage;
