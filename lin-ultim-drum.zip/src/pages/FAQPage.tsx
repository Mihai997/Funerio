import Navigation from "@/components/Navigation";
import Seo from "@/components/Seo";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const FAQ_ITEMS: Array<{ q: string; a: string }> = [
  { q: "Ce este Funerio?", a: "Funerio este o platformă online care conectează familiile cu furnizori de servicii funerare verificați din întreaga țară." },
  { q: "Este gratuit să folosesc Funerio?", a: "Da, utilizarea platformei este complet gratuită pentru utilizatori. Plata se face direct către furnizor." },
  { q: "Cum funcționează platforma?", a: "Cauți servicii în zona ta, compari prețuri, soliciți o ofertă, iar furnizorul te contactează pentru finalizare." },
  { q: "Ce servicii pot găsi pe Funerio?", a: "Sicrie, transport funerar, înmormântări, cremări, coroane, îmbălsămare, ceremonii religioase și pachete complete." },
  { q: "Cât durează până primesc un răspuns?", a: "De obicei vei fi contactat în 2–4 ore. În cazuri de urgență, furnizorul răspunde imediat." },
  { q: "Sunt datele mele în siguranță?", a: "Da, comunicările sunt criptate și respectăm strict reglementările GDPR." },
];


const FAQPage = () => {
  const faqJsonLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: FAQ_ITEMS.map((item) => ({
      "@type": "Question",
      name: item.q,
      acceptedAnswer: { "@type": "Answer", text: item.a },
    })),
  };

  return (
    <div className="min-h-screen bg-background">
      <Seo
        title="Întrebări frecvente despre servicii funerare | Funerio"
        description="Răspunsuri la cele mai frecvente întrebări despre platformă, prețuri, oferte și confidențialitate."
        jsonLd={faqJsonLd}
      />
      <Navigation />
      
      
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold mb-4">Întrebări Frecvente (FAQ)</h1>
          <p className="text-lg text-muted-foreground mb-8">
            Găsiți răspunsuri la cele mai frecvente întrebări despre serviciile Funerio
          </p>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Despre Platformă</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger>Ce este Funerio?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Funerio este o platformă online care conectează familiile care au nevoie de servicii funerare cu furnizori verificați din întreaga țară. Oferim transparență totală asupra prețurilor și serviciilor, permițând compararea ușoară a ofertelor.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-2">
                  <AccordionTrigger>Este gratuit să folosesc Funerio?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Da, utilizarea platformei Funerio este complet gratuită pentru utilizatori. Puteți căuta, compara și solicita oferte fără niciun cost. Plata se face direct către furnizorul de servicii ales.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-3">
                  <AccordionTrigger>Cum funcționează platforma?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    <ol className="list-decimal pl-6 space-y-2">
                      <li>Căutați servicii funerare în zona dorită</li>
                      <li>Comparați prețuri și servicii oferite de diferiți furnizori</li>
                      <li>Selectați serviciile necesare și solicitați o ofertă</li>
                      <li>Furnizorul vă va contacta pentru a discuta detaliile și a finaliza rezervarea</li>
                    </ol>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-4">
                  <AccordionTrigger>Este nevoie de cont pentru a solicita oferte?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Nu este obligatoriu să aveți cont pentru a solicita oferte. Puteți completa formularul de contact cu datele dumneavoastră și veți primi răspuns de la furnizor. Contul este necesar doar pentru furnizorii care doresc să își gestioneze serviciile pe platformă.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Servicii și Prețuri</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-5">
                  <AccordionTrigger>Ce servicii pot găsi pe Funerio?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Pe platformă găsiți o gamă completă de servicii funerare: sicrie, catafalc, transport funerar, înmormântări, cremări, coroane funerare, îmbălsămare, servicii de ceremonie religioasă și laică, pachete complete personalizabile și multe altele.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-6">
                  <AccordionTrigger>Prețurile afișate sunt finale?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Prețurile afișate pe platformă sunt indicative și servesc pentru comparație. Prețul final poate varia în funcție de cerințele specifice, locație și servicii suplimentare. Veți primi o ofertă detaliată de la furnizor după solicitare.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-7">
                  <AccordionTrigger>Pot solicita servicii personalizate?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Da, absolut. Puteți selecta individual serviciile de care aveți nevoie sau puteți opta pentru pachete predefinite. De asemenea, puteți lăsa un mesaj cu cerințe specifice în formularul de solicitare și furnizorul vă va contacta pentru a discuta detaliile.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-8">
                  <AccordionTrigger>Cum se face plata?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Plata se efectuează direct către furnizorul de servicii ales. Puteți alege între plată online (card/transfer bancar) sau plată la sediul firmei (cash sau card). Detaliile complete despre plată vor fi discutate cu furnizorul.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Solicitarea Ofertelor</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-9">
                  <AccordionTrigger>Cât durează până primesc un răspuns?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    De obicei, veți fi contactat de către furnizor în maximum 2-4 ore de la trimiterea solicitării. În cazuri de urgență, furnizorul va răspunde imediat. Recomandăm să lăsați un număr de telefon pentru a fi contactat rapid.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-10">
                  <AccordionTrigger>Pot solicita oferte de la mai mulți furnizori?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Da, puteți compara serviciile mai multor furnizori și puteți trimite solicitări separate către fiecare. Acest lucru vă permite să obțineți cea mai bună ofertă pentru nevoile dumneavoastră.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-11">
                  <AccordionTrigger>Ce informații trebuie să furnizez?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Pentru o ofertă completă, vă rugăm să furnizați: numele complet, email, număr de telefon și orice detalii suplimentare relevante (locație biserică, cimitir, morgă, cerințe speciale). Cu cât informațiile sunt mai complete, cu atât oferta va fi mai precisă.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-12">
                  <AccordionTrigger>Pot anula o solicitare?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Da, puteți anula o solicitare contactând direct furnizorul prin telefon sau email. Pentru detalii despre politica de anulare și eventuale costuri, discutați cu furnizorul ales.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Pentru Furnizori</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-13">
                  <AccordionTrigger>Cum pot înregistra firma pe platformă?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Accesați pagina de Contact și completați formularul cu detaliile firmei dumneavoastră. Echipa noastră vă va contacta pentru a discuta despre procesul de onboarding și tarifele asociate.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-14">
                  <AccordionTrigger>Cât costă să fiu listat pe Funerio?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Funerio oferă pachete flexibile în funcție de nevoile dumneavoastră. Contactați-ne pentru o ofertă personalizată. Primele 3 luni sunt cu reducere specială pentru noii parteneri.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-15">
                  <AccordionTrigger>Cum gestionez serviciile și prețurile?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    După înregistrare, veți avea acces la un panou de administrare unde puteți adăuga, edita sau șterge servicii, gestiona pachete, actualiza prețuri și vizualiza solicitările primite.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-16">
                  <AccordionTrigger>Primesc notificări când cineva solicită o ofertă?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Da, veți primi notificări prin email imediat ce cineva solicită o ofertă pentru serviciile dumneavoastră. De asemenea, puteți gestiona notificările din panoul de administrare.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Confidențialitate și Securitate</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-17">
                  <AccordionTrigger>Sunt datele mele în siguranță?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Da, Funerio utilizează cele mai moderne măsuri de securitate pentru protejarea datelor dumneavoastră. Toate comunicările sunt criptate și respectăm strict reglementările GDPR. Consultați Politica de Confidențialitate pentru detalii complete.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-18">
                  <AccordionTrigger>Cu cine sunt partajate datele mele?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Datele dumneavoastră sunt partajate doar cu furnizorii de la care solicitați oferte. Nu vindem și nu partajăm datele cu terțe părți pentru scopuri de marketing. Consultați Politica de Confidențialitate pentru informații detaliate.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-19">
                  <AccordionTrigger>Pot șterge contul meu?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Da, puteți solicita ștergerea contului oricând contactându-ne la privacy@servicii-funerare.ro. Vom procesa solicitarea în maximum 30 de zile și vom șterge toate datele personale, cu excepția celor pe care suntem obligați legal să le păstrăm.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-20">
                  <AccordionTrigger>Folosiți cookie-uri?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Da, folosim cookie-uri pentru a îmbunătăți experiența de navigare și pentru analiză. Puteți gestiona preferințele de cookie-uri prin banner-ul afișat la prima vizită sau în setările browser-ului. Consultați Politica de Cookie-uri pentru detalii.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>

          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Mai aveți întrebări?</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Dacă nu ați găsit răspunsul la întrebarea dumneavoastră, echipa noastră este disponibilă să vă ajute:
              </p>
              <div className="space-y-2">
                <p className="font-medium">Email: contact@servicii-funerare.ro</p>
                <p className="font-medium">Telefon: 0800 123 456 (disponibil 24/7)</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default FAQPage;
