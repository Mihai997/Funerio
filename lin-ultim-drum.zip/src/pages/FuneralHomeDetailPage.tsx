import { useState, useMemo, useEffect, useCallback } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import Navigation from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { MapPin, Phone, Mail, ArrowLeft, ShoppingCart, Package as PackageIcon, ListChecks, ChevronDown, Sparkles } from "lucide-react";
import { FuneralHome, serviceCategories } from "@/types/funeral";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useIsMobile } from "@/hooks/use-mobile";
import Seo from "@/components/Seo";
import DoveLoader from "@/components/brand/DoveLoader";
import CustomPackageDialog from "@/components/CustomPackageDialog";
import doveLogo from "@/assets/funerio-dove.png";
import { PUBLIC_FIRM_COLUMNS, publicPhone } from "@/lib/publicFirm";

const FuneralHomeDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [funeralHome, setFuneralHome] = useState<FuneralHome | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [selectedPackageId, setSelectedPackageId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("all-services");
  const [showPhoneNumber, setShowPhoneNumber] = useState(false);
  const [expandedPackages, setExpandedPackages] = useState<Set<string>>(new Set());
  const [customPackageOpen, setCustomPackageOpen] = useState(false);

  useEffect(() => {
    if (id) {
      loadFuneralHome(id);
    }
  }, [id]);

  const loadFuneralHome = async (homeId: string) => {
    try {
      setLoading(true);

      const [homeRes, servicesRes, packagesRes] = await Promise.all([
        supabase.from('funeral_homes').select(PUBLIC_FIRM_COLUMNS).eq('id', homeId).single(),
        supabase.from('services').select('*').eq('funeral_home_id', homeId).eq('approval_status', 'approved'),
        supabase.from('packages').select(`*, package_services ( service_id )`).eq('funeral_home_id', homeId).eq('approval_status', 'approved'),
      ]);
      if (homeRes.error) throw homeRes.error;
      if (servicesRes.error) throw servicesRes.error;
      if (packagesRes.error) throw packagesRes.error;
      const home = homeRes.data;
      const services = servicesRes.data;
      const packages = packagesRes.data;

      // Doar numarul de tracking Twilio este afisat public
      const displayPhone = publicPhone(home.tracking_phone);

      // Map to FuneralHome type
      const mappedHome: FuneralHome = {
        id: home.id,
        name: home.name,
        logo: home.logo || '🕊️',
        description: home.description,
        location: {
          county: home.county,
          city: home.city,
        },
        priceRange: home.price_range as "€" | "€€" | "€€€",
        rating: Number(home.rating) || 0,
        reviewCount: home.review_count || 0,
        phone: displayPhone, // Use tracking phone for call tracking
        email: home.email,
        services: (services || []).map(s => ({
          id: s.id,
          name: s.name,
          category: s.category,
          description: s.description,
          price: Number(s.price),
          priceUnit: s.price_unit,
        })),
        packages: (packages || []).map(p => ({
          id: p.id,
          name: p.name,
          description: p.description,
          price: Number(p.price),
          includedServices: (p.package_services || []).map((ps: any) => ps.service_id),
        })),
      };

      setFuneralHome(mappedHome);
    } catch (error) {
      console.error('Error loading funeral home:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleServiceToggle = (serviceId: string) => {
    setSelectedServices(prev =>
      prev.includes(serviceId)
        ? prev.filter(id => id !== serviceId)
        : [...prev, serviceId]
    );
  };

  const togglePackageExpand = useCallback((packageId: string) => {
    setExpandedPackages(prev => {
      const next = new Set(prev);
      if (next.has(packageId)) {
        next.delete(packageId);
      } else {
        next.add(packageId);
      }
      return next;
    });
  }, []);

  const totalCost = useMemo(() => {
    if (!funeralHome) return 0;
    
    // If a package is selected, return the package price
    if (selectedPackageId) {
      const selectedPackage = funeralHome.packages.find(p => p.id === selectedPackageId);
      return selectedPackage?.price || 0;
    }
    
    // Otherwise, sum up individual service prices
    return selectedServices.reduce((sum, serviceId) => {
      const service = funeralHome.services.find(s => s.id === serviceId);
      return sum + (service?.price || 0);
    }, 0);
  }, [selectedServices, selectedPackageId, funeralHome]);

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    // Reset selection when switching tabs
    if (value === "all-services") {
      setSelectedServices([]);
      setSelectedPackageId(null);
    }
  };

  const handleProceedToCheckout = () => {
    if (selectedServices.length === 0) {
      toast.error("Selectează cel puțin un serviciu");
      return;
    }

    if (!funeralHome) return;

    // Navigate to checkout page with state
    navigate(`/firme/${id}/checkout`, {
      state: {
        selectedServices,
        selectedPackageId,
        totalCost,
        funeralHome: {
          id: funeralHome.id,
          name: funeralHome.name,
          email: funeralHome.email,
        }
      }
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="container mx-auto px-4 py-12">
          <DoveLoader label="Se încarcă firma" />
        </div>
      </div>
    );
  }

  if (!funeralHome) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="container mx-auto px-4 py-12 text-center">
          <h1 className="text-2xl font-bold mb-4">Firma nu a fost găsită</h1>
          <Link to="/firme">
            <Button>Înapoi la Lista de Firme</Button>
          </Link>
        </div>
      </div>
    );
  }

  const servicesByCategory = serviceCategories.map(category => ({
    ...category,
    services: funeralHome.services.filter(s => s.category === category.value),
  })).filter(cat => cat.services.length > 0);

  return (
    <div className="min-h-screen bg-background">
      <Seo
        title={`${funeralHome.name} — Servicii funerare în ${funeralHome.location.city} | Funerio`}
        description={(funeralHome.description || `${funeralHome.name} oferă servicii funerare în ${funeralHome.location.city}, ${funeralHome.location.county}.`).slice(0, 155)}
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "LocalBusiness",
          name: funeralHome.name,
          description: funeralHome.description,
          telephone: funeralHome.phone,
          email: funeralHome.email,
          address: {
            "@type": "PostalAddress",
            addressLocality: funeralHome.location.city,
            addressRegion: funeralHome.location.county,
            addressCountry: "RO",
          },
          aggregateRating: funeralHome.reviewCount > 0 ? {
            "@type": "AggregateRating",
            ratingValue: funeralHome.rating,
            reviewCount: funeralHome.reviewCount,
          } : undefined,
        }}
      />
      <Navigation />
      
      
      <div className="container mx-auto px-4 py-8">
        <Link to="/firme" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary mb-6">
          <ArrowLeft className="h-4 w-4" />
          Înapoi la Lista de Firme
        </Link>

        {/* Company Header */}
        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-6">
              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-muted">
                <img src={doveLogo} alt="Funerio" className="h-8 w-8" />
              </div>
              
              <div className="flex-1">
                <h1 className="text-3xl font-bold mb-3">{funeralHome.name}</h1>
                
                <div className="flex items-center gap-2 mb-4">
                  <MapPin className="h-5 w-5 text-muted-foreground" />
                  <span className="text-lg">{funeralHome.location.city}, Județul {funeralHome.location.county}</span>
                </div>
                
                <p className="text-muted-foreground mb-4">{funeralHome.description}</p>
                
                <div className="flex items-center gap-2 text-sm mb-4">
                  <Mail className="h-4 w-4 text-primary" />
                  <span className="text-muted-foreground">{funeralHome.email}</span>
                </div>

                {/* Contact Button inside card */}
                {!funeralHome.phone ? (
                  <p className="text-sm text-muted-foreground">
                    Această firmă nu are momentan apel disponibil. Poți trimite o cerere de ofertă.
                  </p>
                ) : isMobile ? (
                  <a href={`tel:${funeralHome.phone}`}>
                    <Button size="lg" className="w-full sm:w-auto text-lg py-6">
                      <Phone className="mr-2 h-5 w-5" />
                      Contactează Firma
                    </Button>
                  </a>
                ) : (
                  <div className="flex items-center gap-3">
                    <Button 
                      size="lg" 
                      className="text-lg py-6 px-8"
                      onClick={() => setShowPhoneNumber(!showPhoneNumber)}
                    >
                      <Phone className="mr-2 h-5 w-5" />
                      {showPhoneNumber ? funeralHome.phone : "Contactează Firma"}
                    </Button>
                    {showPhoneNumber && (
                      <p className="text-sm text-muted-foreground">
                        Apelează la numărul de mai sus
                      </p>
                    )}
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        <div>
            <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-6">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="all-services" className="gap-2">
                  <ListChecks className="h-4 w-4" />
                  Toate Serviciile
                </TabsTrigger>
                <TabsTrigger value="packages" className="gap-2">
                  <PackageIcon className="h-4 w-4" />
                  Pachete
                </TabsTrigger>
              </TabsList>

              {/* All Services Tab */}
              <TabsContent value="all-services" className="space-y-8">
                <div>
                  <h2 className="text-2xl font-bold mb-2">Servicii Disponibile</h2>
                  <p className="text-muted-foreground">
                    Iată toate serviciile oferite de {funeralHome.name}. Poți alege din pachetele predefinite sau crea un pachet personalizat.
                  </p>
                </div>

                {servicesByCategory.map(category => (
                  <div key={category.value} className="space-y-4">
                    <h3 className="text-xl font-semibold">{category.label}</h3>
                    <div className="grid sm:grid-cols-2 gap-4">
                      {category.services.map(service => (
                        <Card key={service.id} className="group hover:shadow-md transition-all">
                          <CardContent className="p-4">
                            <div className="flex justify-between items-start mb-2">
                              <h4 className="font-semibold text-base leading-snug pr-2">{service.name}</h4>
                              <Badge variant="secondary" className="shrink-0 text-sm font-bold">
                                {service.price.toLocaleString("ro-RO")} RON
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                              {service.description}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              Preț per {service.priceUnit}
                            </p>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                ))}
              </TabsContent>

              {/* Packages Tab */}
              <TabsContent value="packages" className="space-y-6">
                <Card className="border-primary/40 bg-primary/5">
                  <CardContent className="p-4 sm:p-6 flex flex-col sm:flex-row sm:items-center gap-4">
                    <div className="flex-1">
                      <h2 className="text-lg font-bold mb-1">Pachet personalizat</h2>
                      <p className="text-sm text-muted-foreground">
                        Alege exact serviciile de care ai nevoie și primești o ofertă de la {funeralHome.name}.
                      </p>
                    </div>
                    <Button
                      size="lg"
                      className="rounded-full w-full sm:w-auto shrink-0"
                      onClick={() => setCustomPackageOpen(true)}
                    >
                      <Sparkles className="mr-2 h-5 w-5" />
                      Creează pachetul tău
                    </Button>
                  </CardContent>
                </Card>

                <div>
                  <h2 className="text-2xl font-bold mb-4">Pachete Predefinite</h2>
                  <p className="text-muted-foreground mb-6">
                    Alege unul dintre pachetele noastre predefinite pentru o experiență simplificată.
                  </p>
                </div>

                <div className="grid gap-4">
                  {funeralHome.packages.map(pkg => {
                    const isExpanded = expandedPackages.has(pkg.id);
                    return (
                      <Collapsible key={pkg.id} open={isExpanded} onOpenChange={() => togglePackageExpand(pkg.id)}>
                        <Card className="transition-all hover:shadow-md">
                          <CollapsibleTrigger className="w-full text-left">
                            <CardContent className="p-4 flex items-center justify-between gap-3">
                              <h3 className="font-semibold text-base flex-1 min-w-0 truncate">{pkg.name}</h3>
                              <span className="text-lg font-bold text-primary whitespace-nowrap">
                                {pkg.price.toLocaleString("ro-RO")} RON
                              </span>
                              <ChevronDown className={`h-5 w-5 shrink-0 text-muted-foreground transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`} />
                            </CardContent>
                          </CollapsibleTrigger>
                          <CollapsibleContent>
                            <CardContent className="px-4 pb-4 pt-0 space-y-3">
                              <Separator />
                              <p className="text-sm text-muted-foreground">{pkg.description}</p>
                              <div className="space-y-2">
                                {pkg.includedServices.map(serviceId => {
                                  const service = funeralHome.services.find(s => s.id === serviceId);
                                  return service ? (
                                    <div key={service.id} className="flex items-center gap-2 text-sm">
                                      <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                                      <span>{service.name}</span>
                                    </div>
                                  ) : null;
                                })}
                              </div>
                            </CardContent>
                          </CollapsibleContent>
                        </Card>
                      </Collapsible>
                    );
                  })}
                </div>
              </TabsContent>

            </Tabs>
        </div>
      </div>

      <CustomPackageDialog
        open={customPackageOpen}
        onOpenChange={setCustomPackageOpen}
        funeralHome={funeralHome}
      />
    </div>
  );
};

export default FuneralHomeDetailPage;
