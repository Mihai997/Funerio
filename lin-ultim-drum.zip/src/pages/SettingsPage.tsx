import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Session } from "@supabase/supabase-js";
import Navigation from "@/components/Navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import DoveLoader from "@/components/brand/DoveLoader";
import LogoUploader from "@/components/LogoUploader";

interface FuneralHome {
  id: string;
  name: string;
  description: string;
  city: string;
  county: string;
  email: string;
  phone: string;
  price_range: string;
  logo: string | null;
}

const SettingsPage = () => {
  const navigate = useNavigate();
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [funeralHome, setFuneralHome] = useState<FuneralHome | null>(null);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (!session) {
        navigate("/auth");
      } else {
        loadFuneralHome(session.user.id);
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const loadFuneralHome = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from("funeral_homes")
        .select("*")
        .eq("owner_id", userId)
        .maybeSingle();

      if (error) throw error;

      if (!data) {
        toast.error("Nu aveți o firmă funerară asociată.");
        navigate("/");
        return;
      }

      setFuneralHome(data);
    } catch (error) {
      console.error("Error loading funeral home:", error);
      toast.error("Eroare la încărcarea datelor firmei.");
    }
  };

  const handleSave = async () => {
    if (!funeralHome) return;

    setSaving(true);
    try {
      const { error } = await supabase
        .from("funeral_homes")
        .update({
          name: funeralHome.name,
          description: funeralHome.description,
          city: funeralHome.city,
          county: funeralHome.county,
          email: funeralHome.email,
          phone: funeralHome.phone,
          price_range: funeralHome.price_range,
          logo: funeralHome.logo
        })
        .eq("id", funeralHome.id);

      if (error) throw error;

      toast.success("Datele au fost salvate cu succes!");
    } catch (error) {
      console.error("Error saving funeral home:", error);
      toast.error("Eroare la salvarea datelor.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="flex items-center justify-center h-[calc(100vh-80px)]">
          <DoveLoader label="Se încarcă setările" />
        </div>
      </div>
    );
  }

  if (!funeralHome) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8 max-w-2xl mx-auto">
          <h1 className="text-3xl font-bold">Setări Firmă</h1>
          <p className="text-muted-foreground mt-1">
            Actualizați detaliile firmei dumneavoastră
          </p>
        </div>

        <Card className="max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle>Informații Firmă</CardTitle>
            <CardDescription>
              Modificați informațiile despre firma dumneavoastră funerară
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nume Firmă</Label>
              <Input
                id="name"
                value={funeralHome.name}
                onChange={(e) => setFuneralHome({ ...funeralHome, name: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Descriere</Label>
              <Textarea
                id="description"
                value={funeralHome.description}
                onChange={(e) => setFuneralHome({ ...funeralHome, description: e.target.value })}
                rows={4}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="city">Oraș</Label>
                <Input
                  id="city"
                  value={funeralHome.city}
                  onChange={(e) => setFuneralHome({ ...funeralHome, city: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="county">Județ</Label>
                <Input
                  id="county"
                  value={funeralHome.county}
                  onChange={(e) => setFuneralHome({ ...funeralHome, county: e.target.value })}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={funeralHome.email}
                  onChange={(e) => setFuneralHome({ ...funeralHome, email: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Telefon</Label>
                <Input
                  id="phone"
                  value={funeralHome.phone}
                  onChange={(e) => setFuneralHome({ ...funeralHome, phone: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="price_range">Interval de Preț</Label>
              <Input
                id="price_range"
                value={funeralHome.price_range}
                onChange={(e) => setFuneralHome({ ...funeralHome, price_range: e.target.value })}
                placeholder="ex: 2000-5000 RON"
              />
            </div>

            <LogoUploader
              funeralHomeId={funeralHome.id}
              logo={funeralHome.logo}
              onChange={(logo) => setFuneralHome({ ...funeralHome, logo })}
            />


            <div className="pt-4">
              <Button onClick={handleSave} disabled={saving} className="w-full">
                {saving && <DoveLoader size="inline" className="mr-2" label="Se salvează" />}
                Salvează Modificările
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SettingsPage;
