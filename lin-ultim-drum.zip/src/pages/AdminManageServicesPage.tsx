import { useEffect, useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Session } from "@supabase/supabase-js";
import Navigation from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, ArrowLeft } from "lucide-react";
import DoveLoader from "@/components/brand/DoveLoader";
import BrandState from "@/components/brand/BrandState";

interface FuneralHome {
  id: string;
  name: string;
}

interface Service {
  id: string;
  name: string;
  description: string;
  price: number;
  price_unit: string;
  category: string;
}

interface Package {
  id: string;
  name: string;
  description: string;
  price: number;
  package_services?: Array<{ service_id: string }>;
}

const AdminManageServicesPage = () => {
  const navigate = useNavigate();
  const { funeralHomeId } = useParams<{ funeralHomeId: string }>();
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [funeralHome, setFuneralHome] = useState<FuneralHome | null>(null);
  
  const [services, setServices] = useState<Service[]>([]);
  const [packages, setPackages] = useState<Package[]>([]);
  
  const [serviceForm, setServiceForm] = useState({
    id: "",
    name: "",
    description: "",
    price: "",
    price_unit: "buc",
    category: "sicriu"
  });
  
  const [packageForm, setPackageForm] = useState({
    id: "",
    name: "",
    description: "",
    price: ""
  });
  
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [editingService, setEditingService] = useState(false);
  const [editingPackage, setEditingPackage] = useState(false);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (!session) {
        navigate("/auth");
      } else {
        checkAdminAndLoadData(session.user.id);
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate, funeralHomeId]);

  const checkAdminAndLoadData = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", userId)
        .eq("role", "admin")
        .maybeSingle();

      if (error) throw error;

      if (!data) {
        toast.error("Nu aveți permisiuni de administrator.");
        navigate("/");
        return;
      }

      setIsAdmin(true);
      
      if (funeralHomeId) {
        await loadFuneralHomeData(funeralHomeId);
      }
      
      setLoading(false);
    } catch (error) {
      console.error("Error checking admin role:", error);
      toast.error("Eroare la verificarea rolului.");
      navigate("/");
    }
  };

  const loadFuneralHomeData = async (fhId: string) => {
    try {
      const { data: fhData, error: fhError } = await supabase
        .from("funeral_homes")
        .select("id, name")
        .eq("id", fhId)
        .maybeSingle();

      if (fhError) throw fhError;
      
      if (!fhData) {
        toast.error("Firma nu a fost găsită.");
        navigate("/admin");
        return;
      }

      setFuneralHome(fhData);
      
      await loadServices(fhId);
      await loadPackages(fhId);
    } catch (error) {
      console.error("Error loading funeral home data:", error);
      toast.error("Eroare la încărcarea datelor.");
    }
  };

  const loadServices = async (fhId: string) => {
    try {
      const { data, error } = await supabase
        .from("services")
        .select("*")
        .eq("funeral_home_id", fhId)
        .order("name", { ascending: true });

      if (error) throw error;
      setServices(data || []);
    } catch (error) {
      console.error("Error loading services:", error);
      toast.error("Eroare la încărcarea serviciilor.");
    }
  };

  const loadPackages = async (fhId: string) => {
    try {
      const { data, error } = await supabase
        .from("packages")
        .select("*, package_services(service_id)")
        .eq("funeral_home_id", fhId)
        .order("name", { ascending: true });

      if (error) throw error;
      setPackages(data || []);
    } catch (error) {
      console.error("Error loading packages:", error);
      toast.error("Eroare la încărcarea pachetelor.");
    }
  };

  const handleSaveService = async () => {
    if (!funeralHomeId) return;
    
    try {
      const serviceData = {
        funeral_home_id: funeralHomeId,
        name: serviceForm.name,
        description: serviceForm.description,
        price: parseFloat(serviceForm.price),
        price_unit: serviceForm.price_unit,
        category: serviceForm.category as "sicriu" | "transport" | "flori" | "masa" | "documente" | "crematoriu" | "ceremonie" | "pomeni" | "altele"
      };

      if (editingService && serviceForm.id) {
        const { error } = await supabase
          .from("services")
          .update(serviceData)
          .eq("id", serviceForm.id);

        if (error) throw error;
        toast.success("Serviciu actualizat cu succes!");
      } else {
        const { error } = await supabase
          .from("services")
          .insert([serviceData]);

        if (error) throw error;
        toast.success("Serviciu adăugat cu succes!");
      }

      setServiceForm({ id: "", name: "", description: "", price: "", price_unit: "buc", category: "sicriu" });
      setEditingService(false);
      loadServices(funeralHomeId);
    } catch (error) {
      console.error("Error saving service:", error);
      toast.error("Eroare la salvarea serviciului.");
    }
  };

  const handleEditService = (service: Service) => {
    setServiceForm({
      id: service.id,
      name: service.name,
      description: service.description,
      price: service.price.toString(),
      price_unit: service.price_unit,
      category: service.category
    });
    setEditingService(true);
  };

  const handleDeleteService = async (id: string) => {
    if (!confirm("Sigur doriți să ștergeți acest serviciu?")) return;

    try {
      const { error } = await supabase
        .from("services")
        .delete()
        .eq("id", id);

      if (error) throw error;
      toast.success("Serviciu șters cu succes!");
      loadServices(funeralHomeId!);
    } catch (error) {
      console.error("Error deleting service:", error);
      toast.error("Eroare la ștergerea serviciului.");
    }
  };

  const handleSavePackage = async () => {
    if (!funeralHomeId) return;
    
    try {
      const packageData = {
        funeral_home_id: funeralHomeId,
        name: packageForm.name,
        description: packageForm.description,
        price: parseFloat(packageForm.price)
      };

      let packageId = packageForm.id;

      if (editingPackage && packageId) {
        const { error } = await supabase
          .from("packages")
          .update(packageData)
          .eq("id", packageId);

        if (error) throw error;

        await supabase
          .from("package_services")
          .delete()
          .eq("package_id", packageId);
      } else {
        const { data, error } = await supabase
          .from("packages")
          .insert([packageData])
          .select()
          .single();

        if (error) throw error;
        packageId = data.id;
      }

      if (selectedServices.length > 0) {
        const packageServices = selectedServices.map(serviceId => ({
          package_id: packageId,
          service_id: serviceId
        }));

        const { error: psError } = await supabase
          .from("package_services")
          .insert(packageServices);

        if (psError) throw psError;
      }

      toast.success(editingPackage ? "Pachet actualizat cu succes!" : "Pachet adăugat cu succes!");
      setPackageForm({ id: "", name: "", description: "", price: "" });
      setSelectedServices([]);
      setEditingPackage(false);
      loadPackages(funeralHomeId);
    } catch (error) {
      console.error("Error saving package:", error);
      toast.error("Eroare la salvarea pachetului.");
    }
  };

  const handleEditPackage = async (pkg: Package) => {
    setPackageForm({
      id: pkg.id,
      name: pkg.name,
      description: pkg.description,
      price: pkg.price.toString()
    });
    setEditingPackage(true);

    const serviceIds = pkg.package_services?.map(ps => ps.service_id) || [];
    setSelectedServices(serviceIds);
  };

  const handleDeletePackage = async (id: string) => {
    if (!confirm("Sigur doriți să ștergeți acest pachet?")) return;

    try {
      const { error } = await supabase
        .from("packages")
        .delete()
        .eq("id", id);

      if (error) throw error;
      toast.success("Pachet șters cu succes!");
      loadPackages(funeralHomeId!);
    } catch (error) {
      console.error("Error deleting package:", error);
      toast.error("Eroare la ștergerea pachetului.");
    }
  };

  const toggleServiceSelection = (serviceId: string) => {
    setSelectedServices(prev =>
      prev.includes(serviceId)
        ? prev.filter(id => id !== serviceId)
        : [...prev, serviceId]
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="flex items-center justify-center h-[calc(100vh-80px)]">
          <DoveLoader label="Se încarcă serviciile" />
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          {funeralHome && (
            <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight mb-2">
              {funeralHome.name}
            </h1>
          )}
          <p className="text-muted-foreground mb-4">Gestionare Servicii și Pachete</p>
          <Link to={`/admin/funeral-home/${funeralHomeId}/dashboard`}>
            <Button variant="outline" size="lg" className="gap-2 text-base">
              <ArrowLeft className="h-5 w-5" />
              Înapoi la administrare
            </Button>
          </Link>
        </div>

        <Tabs defaultValue="services" className="space-y-6">
          <TabsList>
            <TabsTrigger value="services">Servicii</TabsTrigger>
            <TabsTrigger value="packages">Pachete</TabsTrigger>
          </TabsList>

          {/* Services Tab - same as original */}
          <TabsContent value="services" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{editingService ? "Editare Serviciu" : "Adaugă Serviciu Nou"}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="service-name">Nume Serviciu</Label>
                    <Input
                      id="service-name"
                      value={serviceForm.name}
                      onChange={(e) => setServiceForm({ ...serviceForm, name: e.target.value })}
                      placeholder="Ex: Sicriu standard"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="service-category">Categorie</Label>
                    <Select
                      value={serviceForm.category}
                      onValueChange={(value) => setServiceForm({ ...serviceForm, category: value })}
                    >
                      <SelectTrigger id="service-category">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sicriu">Sicriu</SelectItem>
                        <SelectItem value="transport">Transport</SelectItem>
                        <SelectItem value="flori">Flori</SelectItem>
                        <SelectItem value="catering">Catering</SelectItem>
                        <SelectItem value="altele">Altele</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="service-price">Preț</Label>
                    <Input
                      id="service-price"
                      type="number"
                      step="0.01"
                      value={serviceForm.price}
                      onChange={(e) => setServiceForm({ ...serviceForm, price: e.target.value })}
                      placeholder="0.00"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="service-unit">Unitate</Label>
                    <Input
                      id="service-unit"
                      value={serviceForm.price_unit}
                      onChange={(e) => setServiceForm({ ...serviceForm, price_unit: e.target.value })}
                      placeholder="buc, ora, zi"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="service-description">Descriere</Label>
                  <Textarea
                    id="service-description"
                    value={serviceForm.description}
                    onChange={(e) => setServiceForm({ ...serviceForm, description: e.target.value })}
                    placeholder="Descrierea serviciului..."
                    rows={3}
                  />
                </div>

                <div className="flex gap-2">
                  <Button onClick={handleSaveService}>
                    {editingService ? "Actualizează" : "Adaugă"} Serviciu
                  </Button>
                  {editingService && (
                    <Button
                      variant="outline"
                      onClick={() => {
                        setServiceForm({ id: "", name: "", description: "", price: "", price_unit: "buc", category: "sicriu" });
                        setEditingService(false);
                      }}
                    >
                      Anulează
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Lista Servicii</CardTitle>
                <CardDescription>Serviciile oferite de această firmă</CardDescription>
              </CardHeader>
              <CardContent>
                {services.length === 0 ? (
                  <BrandState title="Nu există servicii adăugate încă." />
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nume</TableHead>
                        <TableHead>Categorie</TableHead>
                        <TableHead>Descriere</TableHead>
                        <TableHead>Preț</TableHead>
                        <TableHead className="text-right">Acțiuni</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {services.map((service) => (
                        <TableRow key={service.id}>
                          <TableCell className="font-medium">{service.name}</TableCell>
                          <TableCell className="capitalize">{service.category}</TableCell>
                          <TableCell className="max-w-xs truncate">{service.description}</TableCell>
                          <TableCell>{service.price} RON / {service.price_unit}</TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditService(service)}
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteService(service.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Packages Tab */}
          <TabsContent value="packages" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{editingPackage ? "Editare Pachet" : "Adaugă Pachet Nou"}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="package-name">Nume Pachet</Label>
                    <Input
                      id="package-name"
                      value={packageForm.name}
                      onChange={(e) => setPackageForm({ ...packageForm, name: e.target.value })}
                      placeholder="Ex: Pachet Standard"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="package-price">Preț Total</Label>
                    <Input
                      id="package-price"
                      type="number"
                      step="0.01"
                      value={packageForm.price}
                      onChange={(e) => setPackageForm({ ...packageForm, price: e.target.value })}
                      placeholder="0.00"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="package-description">Descriere</Label>
                  <Textarea
                    id="package-description"
                    value={packageForm.description}
                    onChange={(e) => setPackageForm({ ...packageForm, description: e.target.value })}
                    placeholder="Descrierea pachetului..."
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Servicii Incluse</Label>
                  <div className="border rounded-md p-4 space-y-2 max-h-60 overflow-y-auto">
                    {services.length === 0 ? (
                      <BrandState title="Nu există servicii disponibile." className="py-4" />
                    ) : (
                      services.map((service) => (
                        <div key={service.id} className="flex items-center space-x-2">
                          <Checkbox
                            id={`service-${service.id}`}
                            checked={selectedServices.includes(service.id)}
                            onCheckedChange={() => toggleServiceSelection(service.id)}
                          />
                          <label
                            htmlFor={`service-${service.id}`}
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                          >
                            {service.name} - {service.price} RON
                          </label>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button onClick={handleSavePackage}>
                    {editingPackage ? "Actualizează" : "Adaugă"} Pachet
                  </Button>
                  {editingPackage && (
                    <Button
                      variant="outline"
                      onClick={() => {
                        setPackageForm({ id: "", name: "", description: "", price: "" });
                        setSelectedServices([]);
                        setEditingPackage(false);
                      }}
                    >
                      Anulează
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Lista Pachete</CardTitle>
                <CardDescription>Pachetele oferite de această firmă</CardDescription>
              </CardHeader>
              <CardContent>
                {packages.length === 0 ? (
                  <BrandState title="Nu există pachete adăugate încă." />
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nume</TableHead>
                        <TableHead>Descriere</TableHead>
                        <TableHead>Servicii Incluse</TableHead>
                        <TableHead>Preț</TableHead>
                        <TableHead className="text-right">Acțiuni</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {packages.map((pkg) => (
                        <TableRow key={pkg.id}>
                          <TableCell className="font-medium">{pkg.name}</TableCell>
                          <TableCell className="max-w-xs truncate">{pkg.description}</TableCell>
                          <TableCell>
                            {pkg.package_services?.length || 0} servicii
                          </TableCell>
                          <TableCell>{pkg.price} RON</TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditPackage(pkg)}
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeletePackage(pkg.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminManageServicesPage;
