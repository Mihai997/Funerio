import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import Navigation from "@/components/Navigation";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import DoveLoader from "@/components/brand/DoveLoader";
import BrandState from "@/components/brand/BrandState";
import { Check, X, Package, Wrench, Search } from "lucide-react";
import { serviceCategories } from "@/types/funeral";

type Kind = "service" | "package";
interface Item {
  id: string;
  kind: Kind;
  name: string;
  description: string;
  price: number;
  price_unit?: string;
  category?: string;
  funeral_home_id: string;
  firmName: string;
  updated_at: string;
  includes?: string[];
}

const AdminApprovalsPage = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState<Item[]>([]);
  const [kindFilter, setKindFilter] = useState<"all" | Kind>("all");
  const [firmFilter, setFirmFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [rejecting, setRejecting] = useState<Item | null>(null);
  const [reason, setReason] = useState("");
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = async () => {
    const [firmsRes, svcRes, pkgRes] = await Promise.all([
      supabase.from("funeral_homes").select("id, name"),
      supabase.from("services").select("*").eq("approval_status", "pending"),
      supabase.from("packages").select("*, package_services ( services ( name ) )").eq("approval_status", "pending"),
    ]);
    if (svcRes.error || pkgRes.error) {
      toast.error("Eroare la încărcarea elementelor de aprobat.");
      return;
    }
    const firms = new Map((firmsRes.data || []).map((f) => [f.id, f.name]));
    const list: Item[] = [
      ...(svcRes.data || []).map((s: any) => ({
        id: s.id, kind: "service" as Kind, name: s.name, description: s.description, price: Number(s.price),
        price_unit: s.price_unit, category: s.category, funeral_home_id: s.funeral_home_id,
        firmName: firms.get(s.funeral_home_id) || "—", updated_at: s.updated_at,
      })),
      ...(pkgRes.data || []).map((p: any) => ({
        id: p.id, kind: "package" as Kind, name: p.name, description: p.description, price: Number(p.price),
        funeral_home_id: p.funeral_home_id, firmName: firms.get(p.funeral_home_id) || "—", updated_at: p.updated_at,
        includes: (p.package_services || []).map((ps: any) => ps.services?.name).filter(Boolean),
      })),
    ].sort((a, b) => a.updated_at.localeCompare(b.updated_at));
    setItems(list);
  };

  useEffect(() => {
    const init = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) { navigate("/auth"); return; }
      const { data } = await supabase.from("user_roles").select("role")
        .eq("user_id", session.user.id).eq("role", "admin").maybeSingle();
      if (!data) { toast.error("Nu aveți permisiuni de administrator."); navigate("/"); return; }
      await load();
      setLoading(false);
    };
    void init();
  }, [navigate]);

  const firms = useMemo(() => {
    const m = new Map<string, string>();
    items.forEach((i) => m.set(i.funeral_home_id, i.firmName));
    return [...m.entries()].sort((a, b) => a[1].localeCompare(b[1]));
  }, [items]);

  const filtered = items.filter((i) =>
    (kindFilter === "all" || i.kind === kindFilter) &&
    (firmFilter === "all" || i.funeral_home_id === firmFilter) &&
    (!search || `${i.name} ${i.firmName}`.toLowerCase().includes(search.toLowerCase()))
  );

  const review = async (item: Item, status: "approved" | "rejected", why?: string) => {
    setBusyId(item.id);
    const { data: { user } } = await supabase.auth.getUser();
    const payload = {
      approval_status: status,
      rejection_reason: status === "rejected" ? why : null,
      reviewed_at: new Date().toISOString(),
      reviewed_by: user?.id ?? null,
    };
    const { error } = item.kind === "service"
      ? await supabase.from("services").update(payload).eq("id", item.id)
      : await supabase.from("packages").update(payload).eq("id", item.id);
    setBusyId(null);
    if (error) { toast.error("Nu s-a putut salva decizia."); return; }
    toast.success(status === "approved" ? "Aprobat — acum este vizibil pe site." : "Refuzat. Firma va vedea motivul.");
    setItems((prev) => prev.filter((i) => i.id !== item.id));
  };

  const confirmReject = async () => {
    if (!rejecting) return;
    if (reason.trim().length < 3) { toast.error("Scrieți motivul refuzului."); return; }
    await review(rejecting, "rejected", reason.trim());
    setRejecting(null);
    setReason("");
  };

  if (loading) return <DoveLoader />;

  const count = (k: Kind) => items.filter((i) => i.kind === k).length;

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="container mx-auto px-4 py-8 max-w-5xl">
        <div className="mb-6 text-center">
          <h1 className="text-3xl md:text-4xl font-bold">De aprobat</h1>
          <p className="text-muted-foreground mt-2">Servicii și pachete adăugate sau modificate de firme ({items.length} în așteptare)</p>
        </div>

        <div className="flex flex-col md:flex-row gap-3 mb-6">
          <Tabs value={kindFilter} onValueChange={(v) => setKindFilter(v as any)}>
            <TabsList>
              <TabsTrigger value="all">Toate ({items.length})</TabsTrigger>
              <TabsTrigger value="service">Servicii ({count("service")})</TabsTrigger>
              <TabsTrigger value="package">Pachete ({count("package")})</TabsTrigger>
            </TabsList>
          </Tabs>
          <Select value={firmFilter} onValueChange={setFirmFilter}>
            <SelectTrigger className="rounded-full md:w-56"><SelectValue placeholder="Firmă" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Toate firmele</SelectItem>
              {firms.map(([id, name]) => <SelectItem key={id} value={id}>{name}</SelectItem>)}
            </SelectContent>
          </Select>
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Caută după nume sau firmă" className="pl-9 rounded-full" />
          </div>
        </div>

        {filtered.length === 0 ? (
          <Card><CardContent><BrandState title="Nimic de aprobat momentan." /></CardContent></Card>
        ) : (
          <div className="space-y-3">
            {filtered.map((item) => (
              <Card key={`${item.kind}-${item.id}`}>
                <CardContent className="p-4 flex flex-col md:flex-row md:items-start gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      {item.kind === "package" ? <Package className="h-4 w-4 text-primary" /> : <Wrench className="h-4 w-4 text-primary" />}
                      <p className="font-semibold">{item.name}</p>
                      <Badge variant="outline" className="text-xs">{item.kind === "package" ? "Pachet" : "Serviciu"}</Badge>
                      {item.category && (
                        <Badge variant="secondary" className="text-xs">
                          {serviceCategories.find((c) => c.value === item.category)?.label}
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      {item.firmName} · trimis {new Date(item.updated_at).toLocaleDateString("ro-RO")}
                    </p>
                    <p className="font-bold mt-2">{item.price.toFixed(0)} RON{item.price_unit ? ` / ${item.price_unit}` : ""}</p>
                    {item.description && <p className="text-sm mt-1">{item.description}</p>}
                    {item.includes && item.includes.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-1">
                        {item.includes.map((n, i) => <Badge key={i} variant="outline" className="text-xs">{n}</Badge>)}
                      </div>
                    )}
                  </div>
                  <div className="flex gap-2 md:flex-col md:w-36">
                    <Button className="flex-1 gap-2 rounded-full" disabled={busyId === item.id} onClick={() => review(item, "approved")}>
                      <Check className="h-4 w-4" /> Aprobă
                    </Button>
                    <Button variant="outline" className="flex-1 gap-2 rounded-full text-destructive" disabled={busyId === item.id} onClick={() => { setRejecting(item); setReason(""); }}>
                      <X className="h-4 w-4" /> Refuză
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>

      <Dialog open={!!rejecting} onOpenChange={(o) => !o && setRejecting(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Refuză „{rejecting?.name}”</DialogTitle>
            <DialogDescription>Firma va vedea acest motiv și poate corecta elementul.</DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label htmlFor="reason">Motivul refuzului</Label>
            <Textarea id="reason" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Ex: prețul nu corespunde descrierii" />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRejecting(null)}>Anulează</Button>
            <Button variant="destructive" onClick={confirmReject} disabled={busyId === rejecting?.id}>Refuză</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminApprovalsPage;
