import { useState, useEffect } from "react";
import { useParams, useLocation, useNavigate, Link } from "react-router-dom";
import Navigation from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowLeft, CreditCard, Banknote } from "lucide-react";
import { toast } from "sonner";
import { FuneralHome } from "@/types/funeral";
import { supabase } from "@/integrations/supabase/client";
import DoveLoader from "@/components/brand/DoveLoader";
import BrandState from "@/components/brand/BrandState";
import { PUBLIC_FIRM_COLUMNS, publicPhone } from "@/lib/publicFirm";

const CheckoutPage = () => {
  const { id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const [funeralHome, setFuneralHome] = useState<FuneralHome | null>(null);
  const [loading, setLoading] = useState(true);
  
  const state = location.state as {
    selectedServices: string[];
    selectedPackageId: string | null;
    totalCost: number;
    funeralHome: {
      id: string;
      name: string;
      email: string;
    }
  } | null;

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    churchLocation: "",
    cemeteryLocation: "",
    morgueLocation: "",
    paymentMethod: "online" as "online" | "la-sediu",
  });

  const [acceptedTerms, setAcceptedTerms] = useState(false);

  useEffect(() => {
    if (id) {
      loadFuneralHome(id);
    }
  }, [id]);

  const loadFuneralHome = async (homeId: string) => {
    try {
      setLoading(true);

      const { data: home, error: homeError } = await supabase
        .from('funeral_homes')
        .select(PUBLIC_FIRM_COLUMNS)
        .eq('id', homeId)
        .single();

      if (homeError) throw homeError;

      const { data: services, error: servicesError } = await supabase
        .from('services')
        .select('*')
        .eq('funeral_home_id', homeId).eq('approval_status', 'approved');

      if (servicesError) throw servicesError;

      const { data: packages, error: packagesError } = await supabase
        .from('packages')
        .select(`
          *,
          package_services (
            service_id
          )
        `)
        .eq('funeral_home_id', homeId).eq('approval_status', 'approved');

      if (packagesError) throw packagesError;

      const mappedHome: FuneralHome = {
        id: home.id,
        name: home.name,
        logo: home.logo || '🕊️',
        description: home.description,
        location: {
          county: home.county,
          city: home.city,
        },
        priceRange: home.price_range as "€" | "€€" | "€€€",
        rating: Number(home.rating) || 0,
        reviewCount: home.review_count || 0,
        phone: publicPhone(home.tracking_phone),
        email: home.email,
        services: (services || []).map(s => ({
          id: s.id,
          name: s.name,
          category: s.category,
          description: s.description,
          price: Number(s.price),
          priceUnit: s.price_unit,
        })),
        packages: (packages || []).map(p => ({
          id: p.id,
          name: p.name,
          description: p.description,
          price: Number(p.price),
          includedServices: (p.package_services || []).map((ps: any) => ps.service_id),
        })),
      };

      setFuneralHome(mappedHome);
    } catch (error) {
      console.error('Error loading funeral home:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="container mx-auto px-4 py-12">
          <DoveLoader label="Se încarcă selecția" />
        </div>
      </div>
    );
  }

  if (!state || !funeralHome) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <BrandState title="Nu am găsit informații despre selecția ta." className="container mx-auto py-12">
          <Link to="/firme">
            <Button>Înapoi la Lista de Servicii</Button>
          </Link>
        </BrandState>
      </div>
    );
  }

  const selectedPackage = state.selectedPackageId 
    ? funeralHome.packages.find(p => p.id === state.selectedPackageId)
    : null;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validation
    if (!formData.name || !formData.email || !formData.phone) {
      toast.error("Te rog completează toate câmpurile obligatorii");
      return;
    }

    if (!acceptedTerms) {
      toast.error("Te rog acceptă Termenii și Condițiile");
      return;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      toast.error("Te rog introdu o adresă de email validă");
      return;
    }

    // Phone validation (basic Romanian phone format)
    const phoneRegex = /^(\+4|0)[0-9]{9}$/;
    if (!phoneRegex.test(formData.phone.replace(/\s/g, ""))) {
      toast.error("Te rog introdu un număr de telefon valid");
      return;
    }

    try {
      const services = state.selectedServices
        .map(serviceId => {
          const service = funeralHome.services.find(s => s.id === serviceId);
          return service ? { name: service.name, price: service.price } : null;
        })
        .filter((s): s is { name: string; price: number } => s !== null);

      const { error } = await supabase.functions.invoke('send-checkout-email', {
        body: {
          customerName: formData.name,
          customerEmail: formData.email,
          customerPhone: formData.phone,
          funeralHomeName: funeralHome.name,
          services,
          packageName: selectedPackage?.name,
          totalCost: state.totalCost,
          churchLocation: formData.churchLocation || undefined,
          cemeteryLocation: formData.cemeteryLocation || undefined,
          morgueLocation: formData.morgueLocation || undefined,
          paymentMethod: formData.paymentMethod,
        },
      });

      if (error) {
        console.error('Error sending email:', error);
        toast.error("A apărut o eroare la trimiterea solicitării");
        return;
      }

      toast.success("Solicitare trimisă cu succes! Veți fi contactat în curând.");
      
      setTimeout(() => {
        navigate(`/firme/${id}`);
      }, 2000);
    } catch (error) {
      console.error('Error:', error);
      toast.error("A apărut o eroare la trimiterea solicitării");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <Link 
          to={`/firme/${id}`} 
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary mb-6"
        >
          <ArrowLeft className="h-4 w-4" />
          Înapoi la Detalii
        </Link>

        <h1 className="text-2xl md:text-3xl font-bold mb-2">Finalizare Solicitare</h1>
        <p className="text-muted-foreground mb-8 text-sm md:text-base">
          Completează datele de contact pentru a trimite solicitarea către {funeralHome.name}
        </p>

        <div className="space-y-8">
          {/* Summary at top on mobile, side on desktop */}
          <Card className="lg:hidden">
            <CardHeader>
              <CardTitle className="text-lg">Sumar Comandă</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm font-semibold mb-2">Furnizor:</p>
                <p className="text-sm text-muted-foreground">{funeralHome.name}</p>
              </div>

              <Separator />

              {selectedPackage && (
                <div className="p-3 bg-primary/10 rounded-lg">
                  <p className="text-sm font-semibold text-primary">
                    {selectedPackage.name}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">Pachet predefinit</p>
                </div>
              )}

              <div className="space-y-2 max-h-48 overflow-y-auto">
                {state.selectedServices.map(serviceId => {
                  const service = funeralHome.services.find(s => s.id === serviceId);
                  return service ? (
                    <div key={service.id} className="flex justify-between text-sm">
                      <span className="flex-1 pr-2">{service.name}</span>
                      <span className="font-medium whitespace-nowrap">
                        {service.price.toLocaleString("ro-RO")} RON
                      </span>
                    </div>
                  ) : null;
                })}
              </div>
              
              <Separator />
              
              <div className="flex justify-between items-center text-lg font-bold">
                <span>Total Estimat:</span>
                <span className="text-primary">{state.totalCost.toLocaleString("ro-RO")} RON</span>
              </div>

              <p className="text-xs text-muted-foreground">
                * Prețul final poate varia în funcție de cerințele specifice
              </p>
            </CardContent>
          </Card>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Form */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Date de Contact</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nume Complet *</Label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder="Exemplu: Ion Popescu"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="exemplu@email.ro"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Telefon *</Label>
                    <Input
                      id="phone"
                      name="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder="0712345678"
                      required
                    />
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <Label className="text-base font-semibold">Locații</Label>
                    
                    <div className="space-y-2">
                      <Label htmlFor="churchLocation" className="text-sm">Locație Biserică</Label>
                      <Input
                        id="churchLocation"
                        name="churchLocation"
                        value={formData.churchLocation}
                        onChange={handleInputChange}
                        placeholder="Ex: Biserica Sfântul Nicolae, București"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="cemeteryLocation" className="text-sm">Locație Cimitir</Label>
                      <Input
                        id="cemeteryLocation"
                        name="cemeteryLocation"
                        value={formData.cemeteryLocation}
                        onChange={handleInputChange}
                        placeholder="Ex: Cimitirul Bellu, București"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="morgueLocation" className="text-sm">Locație Morgă</Label>
                      <Input
                        id="morgueLocation"
                        name="morgueLocation"
                        value={formData.morgueLocation}
                        onChange={handleInputChange}
                        placeholder="Ex: Spitalul Universitar de Urgență București"
                      />
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <Label>Metodă de Plată Preferată *</Label>
                    <RadioGroup
                      value={formData.paymentMethod}
                      onValueChange={(value) => 
                        setFormData({ ...formData, paymentMethod: value as "online" | "la-sediu" })
                      }
                    >
                      <div className="flex items-center space-x-3 p-3 rounded-lg border hover:bg-secondary/50 transition-colors cursor-pointer">
                        <RadioGroupItem value="online" id="online" />
                        <Label htmlFor="online" className="flex items-center gap-2 cursor-pointer flex-1">
                          <CreditCard className="h-5 w-5 text-primary" />
                          <div>
                            <p className="font-medium">Plată Online</p>
                            <p className="text-xs text-muted-foreground">Card sau transfer bancar</p>
                          </div>
                        </Label>
                      </div>

                      <div className="flex items-center space-x-3 p-3 rounded-lg border hover:bg-secondary/50 transition-colors cursor-pointer">
                        <RadioGroupItem value="la-sediu" id="la-sediu" />
                        <Label htmlFor="la-sediu" className="flex items-center gap-2 cursor-pointer flex-1">
                          <Banknote className="h-5 w-5 text-primary" />
                          <div>
                            <p className="font-medium">Plată la Sediul Firmei</p>
                            <p className="text-xs text-muted-foreground">Cash sau card la locație</p>
                          </div>
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <Separator />

                  <div className="flex items-start space-x-3">
                    <Checkbox 
                      id="terms" 
                      checked={acceptedTerms}
                      onCheckedChange={(checked) => setAcceptedTerms(checked as boolean)}
                      required
                    />
                    <Label htmlFor="terms" className="text-sm leading-relaxed cursor-pointer">
                      Sunt de acord cu <Link to="/terms" className="underline text-primary" target="_blank">Termenii și Condițiile</Link>, 
                      <Link to="/privacy" className="underline text-primary ml-1" target="_blank">Politica de Confidențialitate</Link> și 
                      <Link to="/gdpr" className="underline text-primary ml-1" target="_blank">GDPR</Link> *
                    </Label>
                  </div>

                  <Button type="submit" size="lg" className="w-full lg:hidden" disabled={!acceptedTerms}>
                    Trimite Solicitarea
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Summary - desktop only */}
            <div className="hidden lg:block lg:col-span-1">
              <Card className="sticky top-20">
                <CardHeader>
                  <CardTitle className="text-lg">Sumar Comandă</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm font-semibold mb-2">Furnizor:</p>
                    <p className="text-sm text-muted-foreground">{funeralHome.name}</p>
                  </div>

                  <Separator />

                  {selectedPackage && (
                    <div className="p-3 bg-primary/10 rounded-lg">
                      <p className="text-sm font-semibold text-primary">
                        {selectedPackage.name}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">Pachet predefinit</p>
                    </div>
                  )}

                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {state.selectedServices.map(serviceId => {
                      const service = funeralHome.services.find(s => s.id === serviceId);
                      return service ? (
                        <div key={service.id} className="flex justify-between text-sm">
                          <span className="flex-1 pr-2">{service.name}</span>
                          <span className="font-medium whitespace-nowrap">
                            {service.price.toLocaleString("ro-RO")} RON
                          </span>
                        </div>
                      ) : null;
                    })}
                  </div>
                  
                  <Separator />
                  
                  <div className="flex justify-between items-center text-lg font-bold">
                    <span>Total Estimat:</span>
                    <span className="text-primary">{state.totalCost.toLocaleString("ro-RO")} RON</span>
                  </div>

                  <p className="text-xs text-muted-foreground">
                    * Prețul final poate varia în funcție de cerințele specifice
                  </p>

                  <Button 
                    onClick={(e) => {
                      e.preventDefault();
                      const form = document.querySelector('form');
                      if (form) {
                        form.requestSubmit();
                      }
                    }}
                    size="lg" 
                    className="w-full"
                    disabled={!acceptedTerms}
                  >
                    Trimite Solicitarea
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
