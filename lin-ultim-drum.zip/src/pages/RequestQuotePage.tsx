import { useState, useMemo, useEffect } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Check, MapPin, Building2, User, Phone, Mail, ArrowRight, ArrowLeft, Home, X, ChevronDown } from "lucide-react";
import { romanianCounties, FuneralHome } from "@/types/funeral";
import { supabase } from "@/integrations/supabase/client";
import Seo from "@/components/Seo";
import { toast } from "@/hooks/use-toast";
import funerioLogo from "@/assets/funerio-logo.png";
import { romanianLocalities } from "@/data/romanianLocalities";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import DoveLoader from "@/components/brand/DoveLoader";
import BrandState from "@/components/brand/BrandState";
import { trackEvent } from "@/lib/tracking";
import { PUBLIC_FIRM_COLUMNS, publicPhone } from "@/lib/publicFirm";


const RequestQuotePage = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [funeralHomes, setFuneralHomes] = useState<FuneralHome[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedCounty, setSelectedCounty] = useState(searchParams.get("county") || "");
  const [selectedCity, setSelectedCity] = useState(searchParams.get("city") || "");
  const [selectedFirms, setSelectedFirms] = useState<string[]>([]);
  const [contactData, setContactData] = useState({
    name: "",
    phone: "",
    email: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [citySearchOpen, setCitySearchOpen] = useState(false);
  const [citySearch, setCitySearch] = useState("");

  useEffect(() => {
    loadFuneralHomes();
  }, []);

  const loadFuneralHomes = async () => {
    try {
      const { data: homes, error } = await supabase
        .from('funeral_homes')
        .select(PUBLIC_FIRM_COLUMNS);

      if (error) throw error;

      const mappedHomes: FuneralHome[] = (homes || []).map(home => ({
        id: home.id,
        name: home.name,
        logo: home.logo || '🕊️',
        description: home.description,
        location: {
          county: home.county,
          city: home.city,
        },
        priceRange: home.price_range as "€" | "€€" | "€€€",
        rating: Number(home.rating) || 0,
        reviewCount: home.review_count || 0,
        phone: publicPhone(home.tracking_phone),
        email: home.email,
        services: [],
        packages: [],
      }));

      setFuneralHomes(mappedHomes);
    } catch (error) {
      console.error('Error loading funeral homes:', error);
    } finally {
      setLoading(false);
    }
  };

  const availableCities = selectedCounty ? romanianLocalities[selectedCounty] || [] : [];

  const filteredFirms = useMemo(() => {
    if (!selectedCounty) return funeralHomes;
    return funeralHomes.filter(home => 
      home.location.county === selectedCounty || 
      (selectedCity && home.location.city === selectedCity)
    );
  }, [funeralHomes, selectedCounty, selectedCity]);

  const handleFirmToggle = (firmId: string) => {
    if (selectedFirms.includes(firmId)) {
      setSelectedFirms(selectedFirms.filter(id => id !== firmId));
    } else if (selectedFirms.length < 3) {
      setSelectedFirms([...selectedFirms, firmId]);
    } else {
      toast({
        title: "Maximum 3 firme",
        description: "Poți selecta maximum 3 firme pentru a primi oferte.",
        variant: "destructive",
      });
    }
  };

  const handleSubmit = async () => {
    if (!contactData.name || !contactData.phone) {
      toast({
        title: "Date incomplete",
        description: "Te rog completează numele și telefonul.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    try {
      const { error } = await supabase.functions.invoke('distribute-quote-request', {
        body: {
          county: selectedCounty,
          city: selectedCity,
          customer_name: contactData.name,
          customer_phone: contactData.phone,
          customer_email: contactData.email || undefined,
          funeral_home_ids: selectedFirms,
        },
      });
      if (error) throw error;

      trackEvent("quote_requested", {
        county: selectedCounty,
        city: selectedCity,
        metadata: { source: "request_quote_page", firms: selectedFirms.length },
      });
      setIsComplete(true);

      toast({
        title: "Cerere trimisă cu succes!",
        description: `Cererile tale au fost trimise către ${selectedFirms.length} ${selectedFirms.length === 1 ? 'firmă' : 'firme'}. Vei fi contactat în curând.`,
      });
    } catch (error) {
      console.error('Error submitting lead:', error);
      toast({
        title: "Eroare",
        description: "A apărut o eroare. Te rog încearcă din nou.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const canProceedStep1 = selectedCounty && selectedCity;
  const canProceedStep2 = selectedFirms.length > 0;
  const canProceedStep3 = contactData.name && contactData.phone;

  const stepLabels = ["Locație", "Firme", "Contact"];

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <DoveLoader label="Se încarcă firmele" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-secondary/30 to-background flex flex-col">
      <Seo
        title="Cere ofertă pentru servicii funerare | Funerio"
        description="Completează formularul și primește oferte personalizate de la firme verificate din zona ta."
      />
      {/* Header - Compact for mobile */}
      <header className="bg-card/80 backdrop-blur-sm border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/" className="flex items-center">
            <img src={funerioLogo} alt="Funerio" className="h-14 w-auto" />
          </Link>
          <Link to="/">
            <Button variant="ghost" size="sm" className="gap-2">
              <X className="h-5 w-5" />
              <span className="hidden sm:inline">Închide</span>
            </Button>
          </Link>
        </div>
      </header>

      {/* Progress Bar - Mobile optimized */}
      <div className="bg-card border-b px-4 py-4">
        <div className="container mx-auto max-w-lg">
          {/* Step indicators with labels */}
          <div className="flex items-center justify-center">
            {[1, 2, 3].map((step, index) => (
              <div key={step} className="flex items-center">
                <div className="flex flex-col items-center">
                  <div 
                    className={`w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center font-bold text-sm sm:text-base transition-all ${
                      currentStep >= step 
                        ? 'bg-primary text-primary-foreground shadow-lg' 
                        : 'bg-muted text-muted-foreground'
                    }`}
                  >
                    {currentStep > step ? <Check className="h-5 w-5" /> : step}
                  </div>
                  <span className={`mt-2 text-xs sm:text-sm ${currentStep === step ? 'text-primary font-medium' : 'text-muted-foreground'}`}>
                    {stepLabels[index]}
                  </span>
                </div>
                {step < 3 && (
                  <div className={`w-12 sm:w-16 h-1 mx-3 sm:mx-4 rounded -mt-6 ${currentStep > step ? 'bg-primary' : 'bg-muted'}`} />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content - Full height, mobile optimized */}
      <main className="flex-1 container mx-auto px-4 py-6 max-w-lg">
        
        {/* Success State */}
        {isComplete ? (
          <BrandState kind="success" title="Cerere trimisă!" className="min-h-[60vh]" description={`Cererile tale au fost trimise către ${selectedFirms.length} ${selectedFirms.length === 1 ? 'firmă' : 'firme'}. Vei fi contactat telefonic în cel mai scurt timp.`}>
            <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
              <Link to="/" className="w-full sm:w-auto">
                <Button size="lg" className="w-full gap-2">
                  <Home className="h-5 w-5" />
                  Înapoi Acasă
                </Button>
              </Link>
              <Link to="/firme" className="w-full sm:w-auto">
                <Button size="lg" variant="outline" className="w-full">
                  Vezi Toate Firmele
                </Button>
              </Link>
            </div>
          </BrandState>
        ) : (
          <>
            {/* Step 1: Location */}
            {currentStep === 1 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="text-center py-4">
                  <div className="w-16 h-16 sm:w-20 sm:h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <MapPin className="h-8 w-8 sm:h-10 sm:w-10 text-primary" />
                  </div>
                  <h2 className="text-xl sm:text-2xl font-bold mb-2">Unde te afli?</h2>
                  <p className="text-muted-foreground text-sm sm:text-base">
                    Selectează județul și localitatea pentru a găsi firmele din zona ta
                  </p>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <Label className="text-base font-medium mb-2 block">Județ *</Label>
                    <Select value={selectedCounty} onValueChange={(val) => { setSelectedCounty(val); setSelectedCity(""); }}>
                      <SelectTrigger className="h-14 text-base">
                        <SelectValue placeholder="Selectează județul" />
                      </SelectTrigger>
                      <SelectContent className="bg-background max-h-[50vh]">
                        {romanianCounties.map(county => (
                          <SelectItem key={county} value={county} className="py-3 text-base">{county}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label className="text-base font-medium mb-2 block">Localitate *</Label>
                    <Popover open={citySearchOpen} onOpenChange={setCitySearchOpen}>
                      <PopoverTrigger asChild>
                        <div
                          role="combobox"
                          aria-expanded={citySearchOpen}
                          className={`flex h-14 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 cursor-pointer [&>span]:line-clamp-1 ${!selectedCounty ? 'cursor-not-allowed opacity-50' : ''}`}
                        >
                          <span className={selectedCity ? 'text-foreground' : 'text-muted-foreground'}>
                            {selectedCity || (selectedCounty ? "Selectează localitatea" : "Selectează mai întâi județul")}
                          </span>
                          <ChevronDown className="h-4 w-4 opacity-50" />
                        </div>
                      </PopoverTrigger>
                      <PopoverContent className="w-[var(--radix-popover-trigger-width)] p-0" align="start" onOpenAutoFocus={(e) => { if (window.matchMedia("(pointer: coarse)").matches) e.preventDefault(); }}>
                        <Command>
                          <CommandInput 
                            placeholder="Caută localitatea..." 
                            value={citySearch}
                            onValueChange={setCitySearch}
                          />
                          <CommandList className="max-h-[40vh]">
                            <CommandEmpty>Nu s-a găsit nicio localitate.</CommandEmpty>
                            <CommandGroup>
                              {availableCities.map(city => (
                                <CommandItem
                                  key={city}
                                  value={city}
                                  onSelect={() => {
                                    setSelectedCity(city);
                                    setCitySearchOpen(false);
                                    setCitySearch("");
                                  }}
                                  className="py-3 text-base"
                                >
                                  <Check className={`mr-2 h-4 w-4 ${selectedCity === city ? "opacity-100" : "opacity-0"}`} />
                                  {city}
                                </CommandItem>
                              ))}
                            </CommandGroup>
                          </CommandList>
                        </Command>
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Select Firms */}
            {currentStep === 2 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="text-center py-4">
                  <div className="w-16 h-16 sm:w-20 sm:h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Building2 className="h-8 w-8 sm:h-10 sm:w-10 text-primary" />
                  </div>
                  <h2 className="text-xl sm:text-2xl font-bold mb-2">Alege Firmele</h2>
                  <p className="text-muted-foreground text-sm sm:text-base">
                    Selectează până la 3 firme ({selectedFirms.length}/3)
                  </p>
                </div>
                
                {filteredFirms.length === 0 ? (
                  <BrandState
                    title="Nu există firme în zona selectată."
                    description="Încearcă alt județ sau localitate."
                    className="bg-muted/30 rounded-xl"
                  />
                ) : (
                  <div className="space-y-3 max-h-[50vh] overflow-y-auto pb-24">
                    {filteredFirms.map(firm => (
                      <div 
                        key={firm.id}
                        className={`p-4 border-2 rounded-xl cursor-pointer transition-all active:scale-[0.98] ${
                          selectedFirms.includes(firm.id) 
                            ? 'border-primary bg-primary/5 shadow-md' 
                            : 'border-border hover:border-primary/50 bg-card'
                        }`}
                        onClick={() => handleFirmToggle(firm.id)}
                      >
                        <div className="flex items-center gap-4">
                          <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-colors ${
                            selectedFirms.includes(firm.id) 
                              ? 'bg-primary border-primary' 
                              : 'border-muted-foreground'
                          }`}>
                            {selectedFirms.includes(firm.id) && (
                              <Check className="h-4 w-4 text-primary-foreground" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="font-semibold text-base truncate">{firm.name}</h4>
                            <p className="text-sm text-muted-foreground truncate">{firm.location.city}, {firm.location.county}</p>
                          </div>
                          <span className="text-primary font-bold text-lg">{firm.priceRange}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Step 3: Contact Details */}
            {currentStep === 3 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="text-center py-4">
                  <div className="w-16 h-16 sm:w-20 sm:h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <User className="h-8 w-8 sm:h-10 sm:w-10 text-primary" />
                  </div>
                  <h2 className="text-xl sm:text-2xl font-bold mb-2">Datele Tale</h2>
                  <p className="text-muted-foreground text-sm sm:text-base">
                    Completează pentru a fi contactat
                  </p>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name" className="text-base font-medium mb-2 block">Nume complet *</Label>
                    <div className="relative">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                      <Input 
                        id="name"
                        className="pl-12 h-14 text-base"
                        placeholder="Introduceți numele complet"
                        value={contactData.name}
                        onChange={(e) => setContactData({...contactData, name: e.target.value})}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="phone" className="text-base font-medium mb-2 block">Telefon *</Label>
                    <div className="relative">
                      <Phone className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                      <Input 
                        id="phone"
                        className="pl-12 h-14 text-base"
                        placeholder="07XX XXX XXX"
                        type="tel"
                        inputMode="tel"
                        value={contactData.phone}
                        onChange={(e) => setContactData({...contactData, phone: e.target.value})}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="email" className="text-base font-medium mb-2 block">Email (opțional)</Label>
                    <div className="relative">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                      <Input 
                        id="email"
                        className="pl-12 h-14 text-base"
                        type="email"
                        inputMode="email"
                        placeholder="email@exemplu.com"
                        value={contactData.email}
                        onChange={(e) => setContactData({...contactData, email: e.target.value})}
                      />
                    </div>
                  </div>
                </div>

                {/* Summary */}
                <div className="bg-muted/50 p-4 rounded-xl border">
                  <h4 className="font-semibold mb-3 text-sm uppercase tracking-wide text-muted-foreground">Rezumat</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Locație:</span>
                      <span className="font-medium">{selectedCity}, {selectedCounty}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Firme selectate:</span>
                      <span className="font-medium">{selectedFirms.length}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Navigation Buttons - Fixed at bottom on mobile */}
            <div className="sticky bottom-0 left-0 right-0 bg-background/95 backdrop-blur-sm border-t mt-6 -mx-4 px-4 py-4">
              <div className="flex gap-3 max-w-lg mx-auto">
                {currentStep > 1 && (
                  <Button 
                    variant="outline" 
                    size="lg"
                    className="flex-1 h-14 text-base"
                    onClick={() => setCurrentStep(currentStep - 1)}
                  >
                    <ArrowLeft className="mr-2 h-5 w-5" /> Înapoi
                  </Button>
                )}
                
                {currentStep < 3 ? (
                  <Button 
                    size="lg"
                    className="flex-1 h-14 text-base"
                    onClick={() => setCurrentStep(currentStep + 1)}
                    disabled={(currentStep === 1 && !canProceedStep1) || (currentStep === 2 && !canProceedStep2)}
                  >
                    Continuă <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                ) : (
                  <Button 
                    size="lg"
                    className="flex-1 h-14 text-base"
                    onClick={handleSubmit}
                    disabled={!canProceedStep3 || isSubmitting}
                  >
                    {isSubmitting ? "Se trimite..." : "Trimite Cererea"}
                  </Button>
                )}
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
};

export default RequestQuotePage;
