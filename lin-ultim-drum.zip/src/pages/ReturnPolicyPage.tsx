import Navigation from "@/components/Navigation";
import Seo from "@/components/Seo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Info } from "lucide-react";

const ReturnPolicyPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Seo
        title="Politica de retur și anulare | Funerio"
        description="Regulile de anulare și retur pentru solicitările și serviciile rezervate prin Funerio."
      />
      <Navigation />
      
      
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold mb-8">Politica de Retur și Anulare</h1>
          
          <Alert className="mb-8">
            <Info className="h-4 w-4" />
            <AlertDescription>
              Funerio acționează ca platformă intermediară între clienți și furnizorii de servicii funerare. Politica de retur și anulare este stabilită individual de fiecare furnizor. Informațiile de mai jos reprezintă linii directoare generale.
            </AlertDescription>
          </Alert>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>1. Natura Serviciilor</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Serviciile funerare au un caracter deosebit și sunt supuse unor reglementări specifice. Din cauza naturii urgente și personalizate a acestor servicii, politicile de anulare și retur diferă semnificativ față de alte tipuri de servicii comerciale.
              </p>
              <p>
                Contractul pentru servicii funerare se încheie direct între client și furnizorul ales prin platformă. Astfel, fiecare furnizor poate avea termeni și condiții specifice privind anulările și rambursările.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>2. Dreptul de Retragere</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Conform legislației române și Directivei UE privind drepturile consumatorilor, serviciile funerare sunt exceptate de la dreptul de retragere în 14 zile prevăzut pentru majoritatea produselor și serviciilor. Acest lucru se datorează:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Caracterului urgent al serviciilor</li>
                <li>Personalizării serviciilor în funcție de cerințele clientului</li>
                <li>Naturii peribile a anumitor produse (flori, coroane)</li>
                <li>Faptului că serviciile sunt prestate imediat sau într-un termen foarte scurt</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>3. Anularea Solicitărilor</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <div>
                <h4 className="font-semibold text-foreground mb-2">3.1. Anulare înainte de confirmarea furnizorului</h4>
                <p>
                  Dacă furnizorul nu a confirmat încă solicitarea dumneavoastră și nu a început pregătirea serviciilor, puteți anula fără costuri suplimentare contactând direct furnizorul.
                </p>
              </div>

              <div className="mt-4">
                <h4 className="font-semibold text-foreground mb-2">3.2. Anulare după confirmarea furnizorului</h4>
                <p>
                  Odată ce furnizorul a confirmat rezervarea și a început pregătirea serviciilor (ex: comandă sicriu, rezervare corturi, pregătire transport), anularea poate atrage costuri pentru:
                </p>
                <ul className="list-disc pl-6 space-y-2 mt-2">
                  <li>Produse deja comandate sau personalizate</li>
                  <li>Servicii pentru care s-au făcut rezervări</li>
                  <li>Costuri administrative și de procesare</li>
                  <li>Pierderi suferite de furnizor din cauza imposibilității de a revinde serviciile</li>
                </ul>
                <p className="mt-2">
                  Costurile exacte vor fi comunicate de furnizor și depind de momentul anulării și de stadiul pregătirilor.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>4. Modificări ale Serviciilor</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Modificări minore ale serviciilor rezervate (ex: schimbarea orei, ajustări la decorațiuni) pot fi discutate cu furnizorul. În funcție de natura și momentul solicitării, acestea pot sau nu să implice costuri suplimentare.
              </p>
              <p>
                Modificări majore (ex: schimbarea locației, tipul sicriului, servicii complet diferite) sunt tratate ca o anulare urmată de o nouă rezervare și pot atrage costurile menționate anterior.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>5. Situații Excepționale</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                În cazuri excepționale (ex: forță majoră, situații medicale speciale), vă rugăm să contactați furnizorul pentru a discuta opțiunile disponibile. Furnizorii parteneri ai Funerio sunt instruiți să trateze fiecare situație cu empatie și flexibilitate.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>6. Rambursări</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <div>
                <h4 className="font-semibold text-foreground mb-2">6.1. Plăți în avans</h4>
                <p>
                  Dacă ați efectuat o plată în avans și doriți anularea, rambursarea va fi procesată de furnizor după deducerea costurilor justificate pentru servicii deja prestate sau produse comandate.
                </p>
              </div>

              <div className="mt-4">
                <h4 className="font-semibold text-foreground mb-2">6.2. Termene de rambursare</h4>
                <p>
                  Rambursările vor fi procesate de furnizor în maximum 14 zile lucrătoare de la aprobarea cererii. Banii vor fi returnați prin aceeași metodă de plată folosită la achiziție, dacă este posibil.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>7. Reclamații și Dispute</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                În cazul unor neînțelegeri cu furnizorul privind anulări sau rambursări:
              </p>
              <ol className="list-decimal pl-6 space-y-2">
                <li>Încercați mai întâi să rezolvați situația direct cu furnizorul</li>
                <li>Contactați echipa Funerio la contact@servicii-funerare.ro pentru mediere</li>
                <li>Puteți apela la Autoritatea Națională pentru Protecția Consumatorilor (ANPC)</li>
                <li>Aveți dreptul să utilizați platforma SOL (Soluționare Online a Litigiilor) a UE: <a href="https://ec.europa.eu/consumers/odr" className="underline text-primary" target="_blank" rel="noopener noreferrer">ec.europa.eu/consumers/odr</a></li>
              </ol>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>8. Calitatea Serviciilor</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Dacă serviciile prestate nu corespund celor agreate:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Informați imediat furnizorul despre problemă</li>
                <li>Documentați problema prin fotografii, dacă este posibil</li>
                <li>Furnizorul are obligația să remedieze situația sau să ofere compensații adecvate</li>
                <li>Funerio poate interveni ca mediator între părți</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>9. Rolul Funerio</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Funerio acționează ca platformă de conectare și nu este parte în contractul dintre client și furnizor. Cu toate acestea:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Monitorizăm satisfacția clienților și calitatea furnizorilor</li>
                <li>Oferim suport pentru medierea disputelor</li>
                <li>Putem suspenda sau elimina furnizori care nu respectă standardele noastre</li>
                <li>Colectăm și publicăm recenzii pentru a ajuta alți utilizatori</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>10. Recomandări pentru Clienți</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Pentru a evita complicațiile legate de anulări:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Citiți cu atenție descrierea serviciilor înainte de solicitare</li>
                <li>Clarificați toate detaliile cu furnizorul înainte de confirmare</li>
                <li>Solicitați termenii și condițiile specifice ale furnizorului în scris</li>
                <li>Păstrați toată corespondența și documentele legate de rezervare</li>
                <li>Contactați furnizorul cât mai repede posibil în caz de modificări</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>11. Contact</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Pentru întrebări despre politica de retur și anulare sau pentru asistență:
              </p>
              <p className="font-medium">Email: contact@servicii-funerare.ro</p>
              <p className="font-medium">Telefon: 0800 123 456 (disponibil 24/7)</p>
              <p className="text-sm mt-4">Ultima actualizare: Ianuarie 2025</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ReturnPolicyPage;
