import { useState } from "react";
import { Link } from "react-router-dom";
import Navigation from "@/components/Navigation";
import Seo from "@/components/Seo";
import BrandState from "@/components/brand/BrandState";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Calendar, Clock, ChevronRight } from "lucide-react";
import { articleCategories, articles } from "@/content/articles";

const SITE_URL = "https://funerio.ro";

const ArticlesPage = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Toate");

  const filteredArticles = articles.filter((article) => {
    const matchesSearch =
      article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      article.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "Toate" || article.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const formatDate = (dateStr: string) =>
    new Date(dateStr).toLocaleDateString("ro-RO", { day: "numeric", month: "long", year: "numeric" });

  const jsonLd = [
    {
      "@context": "https://schema.org",
      "@type": "ItemList",
      itemListElement: articles.map((a, i) => ({
        "@type": "ListItem",
        position: i + 1,
        name: a.title,
        url: `${SITE_URL}/articole/${a.slug}`,
      })),
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Seo
        title="Articole și ghiduri despre servicii funerare | Funerio"
        description="Ghiduri și articole utile despre organizarea serviciilor funerare, acte, costuri, ajutor de deces și sprijin emoțional."
        jsonLd={jsonLd}
      />
      <Navigation />

      <section className="bg-gradient-to-b from-secondary/50 to-background py-12 md:py-16">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="mb-4 text-3xl font-bold md:text-4xl lg:text-5xl">Articole și Ghiduri Utile</h1>
            <p className="mb-8 text-lg text-muted-foreground">
              Informații valoroase despre servicii funerare, acte, costuri, tradiții și sprijin emoțional.
            </p>

            <div className="relative mx-auto max-w-xl">
              <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Caută articole..."
                className="h-12 pl-12 text-lg"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </div>
      </section>

      <section className="border-b py-6">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="flex flex-wrap justify-center gap-2">
            {articleCategories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container mx-auto px-4 sm:px-6">
          {filteredArticles.length === 0 ? (
            <div className="py-12 text-center">
              <BrandState title="Nu am găsit articole care să corespundă căutării tale." />
            </div>
          ) : (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {filteredArticles.map((article) => (
                <Card key={article.slug} className="flex flex-col transition-shadow hover:shadow-lg">
                  <CardHeader>
                    <Badge variant="secondary" className="mb-2 w-fit">{article.category}</Badge>
                    <CardTitle className="text-lg leading-tight">
                      <Link to={`/articole/${article.slug}`} className="hover:text-primary">
                        {article.title}
                      </Link>
                    </CardTitle>
                    <CardDescription className="flex items-center gap-4 text-xs">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {formatDate(article.updated ?? article.date)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {article.readTime} min citire
                      </span>
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="mt-auto">
                    <p className="mb-4 text-sm text-muted-foreground">{article.excerpt}</p>
                    <Link to={`/articole/${article.slug}`}>
                      <Button
                        variant="outline"
                        className="h-10 gap-2 rounded-full border-primary/30 px-4 text-primary"
                      >
                        Citește articolul
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="bg-secondary/30 py-12">
        <div className="container mx-auto px-4 text-center sm:px-6">
          <h2 className="mb-4 text-2xl font-bold">Ai nevoie de ajutor?</h2>
          <p className="mx-auto mb-6 max-w-2xl text-muted-foreground">
            Dacă te afli într-un moment dificil și ai nevoie de sprijin, echipa noastră este aici pentru tine.
          </p>
          <div className="flex flex-col justify-center gap-4 sm:flex-row">
            <Link to="/firme">
              <Button size="lg">Caută Firme de Servicii Funerare</Button>
            </Link>
            <Link to="/contact">
              <Button size="lg" variant="outline">Contactează-ne</Button>
            </Link>
          </div>
        </div>
      </section>

      <footer className="border-t bg-card py-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground sm:px-6">
          © 2025 Funerio. Toate drepturile rezervate.
        </div>
      </footer>
    </div>
  );
};

export default ArticlesPage;
