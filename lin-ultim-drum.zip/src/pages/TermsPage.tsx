import Navigation from "@/components/Navigation";
import Seo from "@/components/Seo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const TermsPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Seo
        title="Termeni și condiții | Funerio"
        description="Termenii și condițiile de utilizare a platformei Funerio."
      />
      <Navigation />
      
      
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold mb-8">Termeni și Condiții</h1>
          
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>1. Acceptarea Termenilor</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Prin accesarea și utilizarea platformei Funerio, confirmați că ați citit, înțeles și sunteți de acord să respectați prezentii Termeni și Condiții. Dacă nu sunteți de acord cu acești termeni, vă rugăm să nu utilizați serviciile noastre.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>2. Descrierea Serviciului</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Funerio este o platformă online care facilitează conexiunea între utilizatori și furnizori de servicii funerare. Platforma permite:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Căutarea și compararea serviciilor funerare din România</li>
                <li>Solicitarea de oferte personalizate de la furnizori verificați</li>
                <li>Gestionarea serviciilor pentru furnizorii parteneri</li>
                <li>Accesul la informații transparente despre prețuri și servicii</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>3. Contul de Utilizator</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Pentru a accesa anumite funcționalități ale platformei, este necesar să creați un cont. Vă obligați să:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Furnizați informații corecte și actualizate</li>
                <li>Mențineți confidențialitatea datelor de autentificare</li>
                <li>Notificați imediat Funerio despre orice utilizare neautorizată a contului</li>
                <li>Răspundeți pentru toate activitățile desfășurate sub contul dumneavoastră</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>4. Utilizarea Platformei</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Vă angajați să utilizați platforma în mod legal și responsabil. Este interzis:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Încărcarea de conținut ilegal, ofensator sau care încalcă drepturile terților</li>
                <li>Utilizarea platformei pentru activități frauduloase sau înșelătoare</li>
                <li>Interferarea cu funcționarea normală a platformei</li>
                <li>Copierea, reproducerea sau distribuirea neautorizată a conținutului</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>5. Servicii și Prețuri</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Prețurile și serviciile afișate pe platformă sunt furnizate de partenerii noștri și pot fi modificate fără notificare prealabilă. Funerio nu este responsabil pentru:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Acuratețea informațiilor furnizate de terți</li>
                <li>Calitatea serviciilor oferite de furnizorii parteneri</li>
                <li>Modificări de preț sau indisponibilitatea serviciilor</li>
              </ul>
              <p className="mt-4">
                Prețurile afișate sunt estimative. Prețul final se stabilește prin negociere directă cu furnizorul ales.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>6. Procesarea Comenzilor</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Funerio acționează ca intermediar între utilizatori și furnizori. Solicitările trimise prin platformă sunt redirecționate către furnizorul selectat, care va prelua comunicarea ulterioară. Contractul de servicii se încheie direct între utilizator și furnizor.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>7. Proprietate Intelectuală</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Tot conținutul platformei Funerio, inclusiv dar fără a se limita la texte, grafice, logo-uri, imagini și software, este proprietatea Funerio sau a partenerilor săi și este protejat de legile privind drepturile de autor și proprietatea intelectuală.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>8. Limitarea Răspunderii</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Funerio nu poate fi făcut responsabil pentru:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Pierderi sau daune rezultate din utilizarea sau imposibilitatea de utilizare a platformei</li>
                <li>Acțiunile sau omisiunile furnizorilor parteneri</li>
                <li>Întreruperi temporare ale serviciului pentru mentenanță sau actualizări</li>
                <li>Erori sau inexactități în conținutul furnizat de terți</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>9. Modificarea Termenilor</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Funerio își rezervă dreptul de a modifica acești Termeni și Condiții în orice moment. Modificările vor fi publicate pe această pagină cu indicarea datei ultimei actualizări. Utilizarea continuă a platformei după publicarea modificărilor constituie acceptarea acestora.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>10. Legea Aplicabilă</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Prezentii Termeni și Condiții sunt guvernați de legislația română. Orice dispută va fi soluționată pe cale amiabilă sau, în caz contrar, de instanțele competente din România.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>11. Contact</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Pentru orice întrebări referitoare la acești Termeni și Condiții, vă rugăm să ne contactați la:
              </p>
              <p className="font-medium">Email: contact@servicii-funerare.ro</p>
              <p className="font-medium">Telefon: 0800 123 456</p>
              <p className="text-sm mt-4">Ultima actualizare: Ianuarie 2025</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default TermsPage;
