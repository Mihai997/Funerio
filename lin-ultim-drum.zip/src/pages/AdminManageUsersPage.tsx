import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Session } from "@supabase/supabase-js";
import Navigation from "@/components/Navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { UserPlus, Key, Trash2, Search } from "lucide-react";
import DoveLoader from "@/components/brand/DoveLoader";

interface FuneralHome {
  id: string;
  name: string;
  owner_id: string | null;
}

interface UserProfile {
  id: string;
  email: string;
  funeral_home?: FuneralHome;
}

const AdminManageUsersPage = () => {
  const navigate = useNavigate();
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [funeralHomes, setFuneralHomes] = useState<FuneralHome[]>([]);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [resetDialogOpen, setResetDialogOpen] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<string>("");
  const [newUserEmail, setNewUserEmail] = useState("");
  const [newUserPassword, setNewUserPassword] = useState("");
  const [newUserFuneralHome, setNewUserFuneralHome] = useState("");
  const [resetPassword, setResetPassword] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);

      if (event === "SIGNED_OUT") {
        setIsAdmin(false);
        navigate("/auth");
      }
    });

    const initializePage = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setSession(session);

      if (!session) {
        setLoading(false);
        navigate("/auth");
        return;
      }

      await checkAdminRole(session.user.id);
    };

    void initializePage();

    return () => subscription.unsubscribe();
  }, [navigate]);

  const checkAdminRole = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", userId)
        .eq("role", "admin")
        .maybeSingle();

      if (error) throw error;

      if (!data) {
        toast.error("Nu aveți permisiuni de administrator.");
        navigate("/");
        return;
      }

      setIsAdmin(true);
      await loadData();
    } catch (error) {
      console.error("Error checking admin role:", error);
      toast.error("Eroare la verificarea rolului.");
      navigate("/");
    } finally {
      setLoading(false);
    }
  };

  const loadData = async () => {
    await Promise.all([loadUsers(), loadFuneralHomes()]);
  };

  const loadUsers = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("No session");

      const response = await supabase.functions.invoke('admin-user-management', {
        body: { action: 'list-users' }
      });

      if (response.error) throw response.error;
      
      setUsers(response.data.users || []);
    } catch (error) {
      console.error("Error loading users:", error);
      toast.error("Eroare la încărcarea utilizatorilor.");
    }
  };

  const loadFuneralHomes = async () => {
    try {
      const { data, error } = await supabase
        .from("funeral_homes")
        .select("id, name, owner_id")
        .order("name", { ascending: true });

      if (error) throw error;
      setFuneralHomes(data || []);
    } catch (error) {
      console.error("Error loading funeral homes:", error);
      toast.error("Eroare la încărcarea firmelor.");
    }
  };

  const handleCreateUser = async () => {
    if (!newUserEmail || !newUserPassword || !newUserFuneralHome) {
      toast.error("Vă rugăm completați toate câmpurile, inclusiv firma funerară.");
      return;
    }

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("No session");

      const response = await supabase.functions.invoke('admin-user-management', {
        body: {
          action: 'create-user',
          email: newUserEmail,
          password: newUserPassword,
          funeralHomeId: newUserFuneralHome
        }
      });

      if (response.error) throw response.error;

      toast.success("Utilizator creat cu succes!");
      setCreateDialogOpen(false);
      setNewUserEmail("");
      setNewUserPassword("");
      setNewUserFuneralHome("");
      loadData();
    } catch (error) {
      console.error("Error creating user:", error);
      toast.error("Eroare la crearea utilizatorului.");
    }
  };

  const handleResetPassword = async () => {
    if (!resetPassword) {
      toast.error("Vă rugăm introduceți noua parolă.");
      return;
    }

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("No session");

      const response = await supabase.functions.invoke('admin-user-management', {
        body: {
          action: 'reset-password',
          userId: selectedUserId,
          password: resetPassword
        }
      });

      if (response.error) throw response.error;

      toast.success("Parola a fost resetată cu succes!");
      setResetDialogOpen(false);
      setResetPassword("");
      setSelectedUserId("");
    } catch (error) {
      console.error("Error resetting password:", error);
      toast.error("Eroare la resetarea parolei.");
    }
  };


  const handleDeleteUser = async (userId: string) => {
    if (!confirm("Sigur doriți să ștergeți acest utilizator?")) return;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("No session");

      const response = await supabase.functions.invoke('admin-user-management', {
        body: {
          action: 'delete-user',
          userId
        }
      });

      if (response.error) throw response.error;

      toast.success("Utilizator șters cu succes!");
      loadData();
    } catch (error) {
      console.error("Error deleting user:", error);
      toast.error("Eroare la ștergerea utilizatorului.");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="flex items-center justify-center h-[calc(100vh-80px)]">
          <DoveLoader label="Se încarcă utilizatorii" />
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  const availableFuneralHomes = funeralHomes.filter(fh => !fh.owner_id);

  const filteredUsers = users.filter((u) => {
    const q = searchQuery.toLowerCase();
    return (
      u.email.toLowerCase().includes(q) ||
      (u.funeral_home?.name.toLowerCase().includes(q) ?? false)
    );
  });

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8 flex flex-col gap-4 md:flex-row md:justify-between md:items-center">
          <div>
            <h1 className="text-3xl font-bold">Gestionare Utilizatori</h1>
            <p className="text-muted-foreground mt-1">
              Administrați utilizatorii și permisiunile acestora
            </p>
          </div>
          <div className="flex flex-col gap-3 md:flex-row-reverse md:items-center md:gap-3">
          <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <UserPlus className="h-4 w-4" />
                Utilizator Nou
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Creare Utilizator Nou</DialogTitle>
                <DialogDescription>
                  Creați un cont nou pentru un utilizator
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={newUserEmail}
                    onChange={(e) => setNewUserEmail(e.target.value)}
                    placeholder="email@exemplu.ro"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Parolă</Label>
                  <Input
                    id="password"
                    type="password"
                    value={newUserPassword}
                    onChange={(e) => setNewUserPassword(e.target.value)}
                    placeholder="Parolă"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="funeral-home">Firmă Funerară *</Label>
                  <Select value={newUserFuneralHome} onValueChange={setNewUserFuneralHome}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selectați firma" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableFuneralHomes.length === 0 ? (
                        <SelectItem value="no-homes" disabled>
                          Nu există firme disponibile
                        </SelectItem>
                      ) : (
                        availableFuneralHomes.map((fh) => (
                          <SelectItem key={fh.id} value={fh.id}>
                            {fh.name}
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
                  Anulează
                </Button>
                <Button onClick={handleCreateUser}>Creează</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
            <div className="relative md:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Caută după email sau firmă..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Utilizatori</CardTitle>
            <CardDescription>
              Lista tuturor utilizatorilor din platformă
            </CardDescription>
          </CardHeader>
          <CardContent>
            {/* Mobile cards */}
            <div className="md:hidden space-y-3">
              {filteredUsers.map((user) => (
                <div key={user.id} className="rounded-lg border bg-card p-4 space-y-2">
                  <p className="font-medium text-sm break-all">{user.email}</p>
                  <p className="text-sm text-muted-foreground">
                    {user.funeral_home ? user.funeral_home.name : "—"}
                  </p>
                  <div className="flex justify-end gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSelectedUserId(user.id);
                        setResetDialogOpen(true);
                      }}
                    >
                      <Key className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDeleteUser(user.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop table */}
            <div className="hidden md:block">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Email</TableHead>
                    <TableHead>Firmă Funerară</TableHead>
                    <TableHead className="text-right">Acțiuni</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        {user.funeral_home ? user.funeral_home.name : "—"}
                      </TableCell>
                      <TableCell className="text-right space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSelectedUserId(user.id);
                            setResetDialogOpen(true);
                          }}
                        >
                          <Key className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDeleteUser(user.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        <Dialog open={resetDialogOpen} onOpenChange={setResetDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Resetare Parolă</DialogTitle>
              <DialogDescription>
                Introduceți noua parolă pentru utilizator
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="new-password">Parolă Nouă</Label>
                <Input
                  id="new-password"
                  type="password"
                  value={resetPassword}
                  onChange={(e) => setResetPassword(e.target.value)}
                  placeholder="Parolă nouă"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setResetDialogOpen(false)}>
                Anulează
              </Button>
              <Button onClick={handleResetPassword}>Resetează</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default AdminManageUsersPage;
