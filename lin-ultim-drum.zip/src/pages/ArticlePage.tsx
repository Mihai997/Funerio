import { Link, Navigate, useParams } from "react-router-dom";
import Navigation from "@/components/Navigation";
import Seo from "@/components/Seo";
import ArticleBody from "@/components/ArticleBody";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar, ChevronRight, Clock } from "lucide-react";
import { articles, getArticleByLegacyId, getArticleBySlug } from "@/content/articles";

const SITE_URL = "https://funerio.ro";

const formatDate = (dateStr: string) =>
  new Date(dateStr).toLocaleDateString("ro-RO", { day: "numeric", month: "long", year: "numeric" });

const ArticlePage = () => {
  const { slug = "" } = useParams();
  const article = getArticleBySlug(slug);

  if (!article) {
    const legacy = getArticleByLegacyId(slug);
    if (legacy) return <Navigate to={`/articole/${legacy.slug}`} replace />;
    return <Navigate to="/articole" replace />;
  }

  const related = articles
    .filter((a) => a.slug !== article.slug && a.category === article.category)
    .concat(articles.filter((a) => a.slug !== article.slug))
    .filter((a, i, arr) => arr.findIndex((x) => x.slug === a.slug) === i)
    .slice(0, 3);

  const jsonLd = [
    {
      "@context": "https://schema.org",
      "@type": "Article",
      headline: article.title,
      description: article.metaDescription,
      datePublished: article.date,
      dateModified: article.updated ?? article.date,
      inLanguage: "ro-RO",
      mainEntityOfPage: `${SITE_URL}/articole/${article.slug}`,
      author: { "@type": "Organization", name: "Funerio" },
      publisher: { "@type": "Organization", name: "Funerio", url: `${SITE_URL}/` },
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "Acasă", item: `${SITE_URL}/` },
        { "@type": "ListItem", position: 2, name: "Articole", item: `${SITE_URL}/articole` },
        {
          "@type": "ListItem",
          position: 3,
          name: article.title,
          item: `${SITE_URL}/articole/${article.slug}`,
        },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Seo
        title={article.metaTitle}
        description={article.metaDescription}
        ogType="article"
        jsonLd={jsonLd}
      />
      <Navigation />

      <article className="container mx-auto px-4 py-8 sm:px-6 md:py-12">
        <nav aria-label="Breadcrumb" className="mb-6 flex flex-wrap items-center gap-1 text-sm text-muted-foreground">
          <Link to="/" className="hover:text-primary">Acasă</Link>
          <ChevronRight className="h-3 w-3" />
          <Link to="/articole" className="hover:text-primary">Articole</Link>
          <ChevronRight className="h-3 w-3" />
          <span className="text-foreground">{article.title}</span>
        </nav>

        <header className="mx-auto max-w-3xl">
          <Badge variant="secondary" className="mb-3">{article.category}</Badge>
          <h1 className="mb-4 text-2xl font-bold leading-tight md:text-4xl">{article.title}</h1>
          <div className="mb-8 flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              {formatDate(article.updated ?? article.date)}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {article.readTime} min citire
            </span>
          </div>
        </header>

        <div className="mx-auto max-w-3xl">
          <ArticleBody body={article.body} />
        </div>

        <section className="mx-auto mt-12 max-w-3xl rounded-2xl bg-secondary/40 p-6 text-center">
          <h2 className="mb-2 text-xl font-semibold">Ai nevoie de o firmă de servicii funerare?</h2>
          <p className="mb-5 text-sm text-muted-foreground">
            Compară firmele verificate din localitatea ta sau cere o ofertă și te contactează ele.
          </p>
          <div className="flex flex-col justify-center gap-3 sm:flex-row">
            <Link to="/cere-oferta"><Button size="lg" className="w-full sm:w-auto">Cere ofertă</Button></Link>
            <Link to="/firme"><Button size="lg" variant="outline" className="w-full sm:w-auto">Vezi firmele</Button></Link>
          </div>
        </section>

        {related.length > 0 && (
          <section className="mx-auto mt-12 max-w-5xl">
            <h2 className="mb-6 text-xl font-semibold">Articole similare</h2>
            <div className="grid gap-6 md:grid-cols-3">
              {related.map((item) => (
                <Card key={item.slug} className="transition-shadow hover:shadow-lg">
                  <CardHeader>
                    <Badge variant="secondary" className="mb-2 w-fit">{item.category}</Badge>
                    <CardTitle className="text-base leading-tight">
                      <Link to={`/articole/${item.slug}`} className="hover:text-primary">{item.title}</Link>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">{item.excerpt}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>
        )}
      </article>
    </div>
  );
};

export default ArticlePage;
