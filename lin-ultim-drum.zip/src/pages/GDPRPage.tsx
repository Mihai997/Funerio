import Navigation from "@/components/Navigation";
import Seo from "@/components/Seo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const GDPRPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Seo
        title="Conformitate GDPR | Funerio"
        description="Drepturile tale GDPR și modul în care Funerio respectă Regulamentul UE 2016/679."
      />
      <Navigation />
      
      
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold mb-8">Conformitate GDPR</h1>
          <p className="text-lg text-muted-foreground mb-8">
            Funerio se angajează să respecte Regulamentul General privind Protecția Datelor (GDPR - Regulamentul UE 2016/679)
          </p>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Ce este GDPR?</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Regulamentul General privind Protecția Datelor (GDPR) este o legislație a Uniunii Europene care protejează drepturile persoanelor fizice în ceea ce privește prelucrarea datelor lor personale. GDPR a intrat în vigoare pe 25 mai 2018 și se aplică tuturor organizațiilor care prelucrează date personale ale rezidenților UE.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Angajamentul Funerio față de GDPR</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Funerio este dedicat protejării confidențialității datelor dumneavoastră personale și respectării tuturor cerințelor GDPR. Ne angajăm să:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Procesăm datele dumneavoastră în mod legal, corect și transparent</li>
                <li>Colectăm date doar pentru scopuri specifice și legitime</li>
                <li>Limităm colectarea datelor la ceea ce este strict necesar</li>
                <li>Păstrăm datele exacte și actualizate</li>
                <li>Nu păstrăm datele mai mult decât este necesar</li>
                <li>Protejăm datele prin măsuri tehnice și organizatorice adecvate</li>
                <li>Respectăm toate drepturile dumneavoastră privind datele personale</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Drepturile Dumneavoastră conform GDPR</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <div>
                <h4 className="font-semibold text-foreground mb-2">1. Dreptul de acces (Art. 15 GDPR)</h4>
                <p>
                  Aveți dreptul să obțineți confirmarea dacă prelucrăm date despre dumneavoastră și, în caz afirmativ, să primiți o copie a acestor date împreună cu informații despre prelucrare.
                </p>
              </div>

              <div className="mt-4">
                <h4 className="font-semibold text-foreground mb-2">2. Dreptul la rectificare (Art. 16 GDPR)</h4>
                <p>
                  Puteți solicita corectarea datelor inexacte sau completarea datelor incomplete despre dumneavoastră.
                </p>
              </div>

              <div className="mt-4">
                <h4 className="font-semibold text-foreground mb-2">3. Dreptul la ștergere - "Dreptul de a fi uitat" (Art. 17 GDPR)</h4>
                <p>
                  Puteți solicita ștergerea datelor dumneavoastră în anumite circumstanțe, cum ar fi:
                </p>
                <ul className="list-disc pl-6 space-y-1 mt-2">
                  <li>Datele nu mai sunt necesare pentru scopurile pentru care au fost colectate</li>
                  <li>Vă retrageți consimțământul și nu există alt temei legal</li>
                  <li>Datele au fost prelucrate ilegal</li>
                </ul>
              </div>

              <div className="mt-4">
                <h4 className="font-semibold text-foreground mb-2">4. Dreptul la restricționarea prelucrării (Art. 18 GDPR)</h4>
                <p>
                  Puteți solicita limitarea prelucrării datelor în anumite situații, cum ar fi contestarea acurateței datelor sau opoziție la prelucrare.
                </p>
              </div>

              <div className="mt-4">
                <h4 className="font-semibold text-foreground mb-2">5. Dreptul la portabilitatea datelor (Art. 20 GDPR)</h4>
                <p>
                  Aveți dreptul să primiți datele pe care ni le-ați furnizat într-un format structurat, utilizat în mod curent și care poate fi citit automat, și să le transmiteți altui operator.
                </p>
              </div>

              <div className="mt-4">
                <h4 className="font-semibold text-foreground mb-2">6. Dreptul la opoziție (Art. 21 GDPR)</h4>
                <p>
                  Aveți dreptul să vă opuneți prelucrării datelor dumneavoastră în anumite circumstanțe, inclusiv pentru marketing direct.
                </p>
              </div>

              <div className="mt-4">
                <h4 className="font-semibold text-foreground mb-2">7. Dreptul de a nu face obiectul unor decizii automate (Art. 22 GDPR)</h4>
                <p>
                  Aveți dreptul să nu faceți obiectul unei decizii bazate exclusiv pe prelucrarea automată, inclusiv crearea de profiluri, care produce efecte juridice sau vă afectează în mod similar într-o măsură semnificativă.
                </p>
              </div>

              <div className="mt-4">
                <h4 className="font-semibold text-foreground mb-2">8. Dreptul de a depune plângere</h4>
                <p>
                  Aveți dreptul de a depune o plângere la autoritatea de supraveghere competentă dacă considerați că prelucrarea datelor dumneavoastră încalcă GDPR.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Cum Exercitați Aceste Drepturi</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Pentru a exercita oricare dintre drepturile de mai sus, vă rugăm să ne contactați la:
              </p>
              <div className="space-y-2 my-4">
                <p className="font-medium text-foreground">Email: privacy@servicii-funerare.ro</p>
                <p className="font-medium text-foreground">Telefon: 0800 123 456</p>
              </div>
              <p>
                Vom răspunde solicitării dumneavoastră fără întârzieri nejustificate și în orice caz în termen de o lună de la primirea cererii. Această perioadă poate fi prelungită cu două luni suplimentare în funcție de complexitatea și numărul de cereri.
              </p>
              <p className="mt-4">
                Pentru a vă verifica identitatea, este posibil să vă solicităm informații suplimentare.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Temeiul Legal al Prelucrării</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Conform GDPR, datele dumneavoastră personale sunt prelucrate pe baza următoarelor temeiuri legale:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li><strong>Art. 6(1)(a) - Consimțământ:</strong> Pentru activități de marketing și utilizarea anumitor cookie-uri</li>
                <li><strong>Art. 6(1)(b) - Executarea contractului:</strong> Pentru furnizarea serviciilor platformei</li>
                <li><strong>Art. 6(1)(c) - Obligație legală:</strong> Pentru conformarea cu cerințele fiscale și legale</li>
                <li><strong>Art. 6(1)(f) - Interes legitim:</strong> Pentru îmbunătățirea serviciilor, securitate și prevenirea fraudelor</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Măsuri de Securitate</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Conform Art. 32 GDPR, implementăm măsuri tehnice și organizatorice adecvate pentru a asigura un nivel de securitate corespunzător riscului:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Pseudonimizarea și criptarea datelor personale</li>
                <li>Capacitatea de a asigura confidențialitatea, integritatea, disponibilitatea și reziliența continue a sistemelor</li>
                <li>Capacitatea de restabilire a disponibilității și accesului la date în timp util în caz de incident</li>
                <li>Proces de testare, evaluare și apreciere regulate a eficienței măsurilor tehnice și organizatorice</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Încălcări ale Securității Datelor</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Conform Art. 33 și 34 GDPR, în cazul unei încălcări a securității datelor care prezintă un risc pentru drepturile și libertățile dumneavoastră:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Vom notifica autoritatea de supraveghere în termen de 72 de ore de la constatare</li>
                <li>Vă vom informa direct dacă încălcarea prezintă un risc ridicat pentru dumneavoastră</li>
                <li>Vom lua măsuri imediate pentru a limita impactul încălcării</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Transferuri Internaționale de Date</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Conform Art. 44-50 GDPR, datele dumneavoastră sunt stocate și procesate în Spațiul Economic European (SEE). În cazul unor transferuri în afara SEE, ne asigurăm că există garanții adecvate, cum ar fi:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Clauze Contractuale Standard aprobate de Comisia Europeană</li>
                <li>Certificări de conformitate</li>
                <li>Consimțământul dumneavoastră explicit</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Responsabilul cu Protecția Datelor (DPO)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Puteți contacta Responsabilul cu Protecția Datelor pentru orice întrebări legate de prelucrarea datelor dumneavoastră personale:
              </p>
              <p className="font-medium text-foreground mt-4">Email: dpo@servicii-funerare.ro</p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Autoritatea de Supraveghere</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Aveți dreptul de a depune o plângere la autoritatea națională de supraveghere:
              </p>
              <div className="mt-4 space-y-2">
                <p className="font-medium text-foreground">Autoritatea Națională de Supraveghere a Prelucrării Datelor cu Caracter Personal (ANSPDCP)</p>
                <p>B-dul G-ral. Gheorghe Magheru 28-30, Sector 1, București</p>
                <p>Email: anspdcp@dataprotection.ro</p>
                <p>Telefon: +40 318 059 211</p>
                <p>Website: <a href="https://www.dataprotection.ro" className="underline text-primary" target="_blank" rel="noopener noreferrer">www.dataprotection.ro</a></p>
              </div>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Linkuri către Alte Documente</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                Pentru informații mai detaliate despre cum prelucrăm datele dumneavoastră, vă rugăm să consultați:
              </p>
              <div className="space-y-2">
                <Link to="/privacy" className="block">
                  <Button variant="outline" className="w-full justify-start">
                    Politica de Confidențialitate
                  </Button>
                </Link>
                <Link to="/terms" className="block">
                  <Button variant="outline" className="w-full justify-start">
                    Termeni și Condiții
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Actualizări</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Această pagină poate fi actualizată periodic pentru a reflecta modificările în practicile noastre de prelucrare a datelor sau în legislația aplicabilă. Vă încurajăm să o verificați periodic.
              </p>
              <p className="text-sm mt-4">Ultima actualizare: Ianuarie 2025</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default GDPRPage;
