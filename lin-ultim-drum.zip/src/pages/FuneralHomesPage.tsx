import { useState, useMemo, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Skeleton } from "@/components/ui/skeleton";
import Navigation from "@/components/Navigation";
import FuneralHomeCard from "@/components/FuneralHomeCard";
import FilterDropdowns from "@/components/FilterDropdowns";
import { FilterState, FuneralHome } from "@/types/funeral";
import { supabase } from "@/integrations/supabase/client";
import Seo from "@/components/Seo";
import BrandState from "@/components/brand/BrandState";
import { trackEvent } from "@/lib/tracking";
import { PUBLIC_FIRM_COLUMNS, publicPhone } from "@/lib/publicFirm";


const FuneralHomesPage = () => {
  const [searchParams] = useSearchParams();
  const [funeralHomes, setFuneralHomes] = useState<FuneralHome[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState<FilterState>({
    county: searchParams.get("county") || "all",
    city: searchParams.get("city") || "",
    priceRange: [],
    services: [],
  });

  useEffect(() => {
    loadFuneralHomes();
    trackEvent("view_firms", {
      county: searchParams.get("county"),
      city: searchParams.get("city"),
      metadata: { source: "list_page" },
    });
  }, []);


  const loadFuneralHomes = async () => {
    try {
      setLoading(true);
      const [homesRes, servicesRes, packagesRes] = await Promise.all([
        supabase.from('funeral_homes').select(PUBLIC_FIRM_COLUMNS),
        supabase.from('services').select('*').eq('approval_status', 'approved'),
        supabase.from('packages').select(`*, package_services ( service_id )`).eq('approval_status', 'approved'),
      ]);
      if (homesRes.error) throw homesRes.error;
      if (servicesRes.error) throw servicesRes.error;
      if (packagesRes.error) throw packagesRes.error;
      const homes = homesRes.data;
      const services = servicesRes.data;
      const packages = packagesRes.data;

      const mappedHomes: FuneralHome[] = (homes || []).map(home => ({
        id: home.id,
        name: home.name,
        logo: home.logo || '🕊️',
        description: home.description,
        location: { county: home.county, city: home.city },
        priceRange: home.price_range as "€" | "€€" | "€€€",
        rating: Number(home.rating) || 0,
        reviewCount: home.review_count || 0,
        phone: publicPhone(home.tracking_phone),
        email: home.email,
        services: (services || [])
          .filter(s => s.funeral_home_id === home.id)
          .map(s => ({
            id: s.id, name: s.name, category: s.category,
            description: s.description, price: Number(s.price), priceUnit: s.price_unit,
          })),
        packages: (packages || [])
          .filter(p => p.funeral_home_id === home.id)
          .map(p => ({
            id: p.id, name: p.name, description: p.description,
            price: Number(p.price),
            includedServices: (p.package_services || []).map((ps: any) => ps.service_id),
          })),
      }));

      setFuneralHomes(mappedHomes);
    } catch (error) {
      console.error('Error loading funeral homes:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredHomes = useMemo(() => {
    const countyHomes = funeralHomes.filter(home => filters.county === "all" || home.location.county === filters.county);
    const hasCityMatches = filters.city && countyHomes.some(home => home.location.city === filters.city);
    return funeralHomes.filter(home => {
      if (filters.county !== "all" && home.location.county !== filters.county) return false;
      if (hasCityMatches && home.location.city !== filters.city) return false;
      if (filters.priceRange.length > 0 && !filters.priceRange.includes(home.priceRange)) return false;
      if (filters.services.length > 0) {
        const cats = home.services.map(s => s.category);
        if (!filters.services.every(s => cats.includes(s))) return false;
      }
      return true;
    });
  }, [filters, funeralHomes]);

  const sortedHomes = useMemo(() => {
    return [...filteredHomes].sort((a, b) => a.name.localeCompare(b.name));
  }, [filteredHomes]);

  const handleCountySelect = (county: string) => {
    setFilters(f => ({ ...f, county, city: "" }));
  };

  const handlePriceRangeToggle = (range: string) => {
    setFilters(f => ({
      ...f,
      priceRange: f.priceRange.includes(range)
        ? f.priceRange.filter(p => p !== range)
        : [...f.priceRange, range],
    }));
  };

  const handleServiceToggle = (service: string) => {
    setFilters(f => ({
      ...f,
      services: f.services.includes(service as any)
        ? f.services.filter(s => s !== service)
        : [...f.services, service as any],
    }));
  };

  const handleResetFilters = () => {
    setFilters({ county: "all", city: "", priceRange: [], services: [] });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="container mx-auto px-4 py-8">
          <Skeleton className="h-10 w-64 mb-3" />
          <Skeleton className="h-6 w-96 mb-8" />
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <Skeleton key={i} className="h-72 rounded-lg" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Seo
        title="Firme de servicii funerare în România | Funerio"
        description="Listă completă de firme de pompe funebre verificate. Filtrează după județ, preț și servicii."
      />
      <Navigation />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-2xl md:text-4xl font-bold mb-3">Servicii Funerare</h1>
          <p className="text-muted-foreground text-sm md:text-lg">
            Găsește firma potrivită pentru nevoile tale.
          </p>
        </div>

        <FilterDropdowns
          filters={filters}
          onCountySelect={handleCountySelect}
          onResetFilters={handleResetFilters}
        />

        <div className="mb-4 text-sm text-muted-foreground">
          Afișate {sortedHomes.length} {sortedHomes.length === 1 ? "firmă" : "firme"}
          {filters.city && !funeralHomes.some(home => home.location.county === filters.county && home.location.city === filters.city) && (
            <span className="mt-1 block">Nu există încă firme în {filters.city}; afișăm firmele disponibile din județul {filters.county}.</span>
          )}
        </div>

        {sortedHomes.length === 0 ? (
          <div className="text-center py-12">
            <BrandState title="Nu am găsit firme care să corespundă filtrelor selectate." description="Încearcă să modifici criteriile de căutare." />
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sortedHomes.map(home => (
              <FuneralHomeCard key={home.id} funeralHome={home} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default FuneralHomesPage;
