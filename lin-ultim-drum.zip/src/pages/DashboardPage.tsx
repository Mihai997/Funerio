import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { User, Session } from "@supabase/supabase-js";
import Navigation from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { TrendingUp, ShoppingCart, DollarSign, Package, Award, BarChart3, Settings, FileText, Download, CreditCard, Phone, PhoneCall, Clock, Check, Play, Square } from "lucide-react";
import { format, subMonths } from "date-fns";
import { ro } from "date-fns/locale";
import { Bar, BarChart, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Line, LineChart } from "recharts";
import ManageServicesEmbed from "@/components/dashboard/ManageServicesEmbed";
import RoiDashboard from "@/components/dashboard/RoiDashboard";

import FinalizeCallDialog, { type FinalizeFormData } from "@/components/dashboard/FinalizeCallDialog";
import OrderDetailDialog, { type OrderItem } from "@/components/dashboard/OrderDetailDialog";
import DoveLoader from "@/components/brand/DoveLoader";
import BrandState from "@/components/brand/BrandState";
import { exportFirmStatsToExcel } from "@/lib/exportStats";
import LeadStatusBadge from "@/components/LeadStatusBadge";
import { QUALIFIED_LEAD_SECONDS, getLeadStatusKey } from "@/lib/leadStatus";
import { maskPhone } from "@/lib/phoneMask";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface FuneralHome {
  id: string;
  name: string;
}

interface Order {
  id: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  total_price: number;
  status: string;
  created_at: string;
  order_type?: string;
  notes?: string | null;
  lead_source?: string | null;
}

interface Stats {
  totalOrders: number;
  potentialClients: number;
  totalRevenue: number;
  averageOrderValue: number;
  completionRate: number;
}

interface CallLog {
  id: string;
  caller_name: string | null;
  caller_phone: string | null;
  tracking_phone: string;
  real_phone: string;
  call_status: string;
  call_duration: number;
  started_at: string;
  ended_at: string | null;
  funeral_home_id: string;
  recording_url: string | null;
  outcome?: string | null;
  contact_person?: string | null;
  outcome_notes?: string | null;
  outcome_amount?: number | null;
}


interface MonthlyStats {
  month: string;
  revenue: number;
  orders: number;
}

interface TopItem {
  name: string;
  count: number;
  revenue: number;
}

const DashboardPage = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [funeralHome, setFuneralHome] = useState<FuneralHome | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [orderServices, setOrderServices] = useState<Record<string, string[]>>({});
  const [stats, setStats] = useState<Stats>({
    totalOrders: 0,
    potentialClients: 0,
    totalRevenue: 0,
    averageOrderValue: 0,
    completionRate: 0,
  });
  const [monthlyStats, setMonthlyStats] = useState<MonthlyStats[]>([]);
  const [topServices, setTopServices] = useState<TopItem[]>([]);
  const [topPackages, setTopPackages] = useState<TopItem[]>([]);
  const [timePeriod, setTimePeriod] = useState<"total" | "year" | "month">("total");
  const [callLogs, setCallLogs] = useState<CallLog[]>([]);
  const [finalizedCallIds, setFinalizedCallIds] = useState<Set<string>>(new Set());
  const [playingId, setPlayingId] = useState<string | null>(null);
  const audioRef = { current: null as HTMLAudioElement | null };
  const [finalizeDialogOpen, setFinalizeDialogOpen] = useState(false);
  const [finalizeCallLog, setFinalizeCallLog] = useState<CallLog | null>(null);
  const [callbackTarget, setCallbackTarget] = useState<CallLog | null>(null);
  const [callbackLoading, setCallbackLoading] = useState(false);

  interface FinalizedOrder {
    id: string;
    contactName?: string;
    phone: string;
    price: number;
    address: string;
    date: string;
    details: string;
    created_at: string;
  }
  const [localFinalizedOrders, setLocalFinalizedOrders] = useState<FinalizedOrder[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<OrderItem | null>(null);
  const [orderDetailOpen, setOrderDetailOpen] = useState(false);
  const [exporting, setExporting] = useState(false);

  const handleExportExcel = async () => {
    if (!funeralHome) return;
    setExporting(true);
    try {
      const result = await exportFirmStatsToExcel({
        funeralHomeId: funeralHome.id,
        funeralHomeName: funeralHome.name,
        period: timePeriod,
        averageOrderValue: stats.averageOrderValue,
        completionRate: stats.completionRate,
        potentialClients: stats.potentialClients,
        totalOrders: stats.totalOrders,
        totalRevenue: stats.totalRevenue,
        monthlyStats,
        topServices,
        topPackages,
      });
      toast.success(`Export finalizat: ${result.total} apeluri, ${result.leads} leads.`);
    } catch (error) {
      console.error("Export error:", error);
      toast.error("Eroare la generarea fișierului Excel.");
    } finally {
      setExporting(false);
    }
  };


  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (!session) {
        navigate("/auth");
      } else {
        checkUserRole(session.user.id);
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const checkUserRole = async (userId: string) => {
    try {
      const { data: adminData } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", userId)
        .eq("role", "admin")
        .maybeSingle();

      if (adminData) {
        navigate("/admin");
        return;
      }

      loadDashboardData(userId);
    } catch (error) {
      console.error("Error checking user role:", error);
      loadDashboardData(userId);
    }
  };

  const loadDashboardData = async (userId: string) => {
    try {
      const { data: fhData, error: fhError } = await supabase
        .from("funeral_homes")
        .select("id, name")
        .eq("owner_id", userId)
        .maybeSingle();

      if (fhError) throw fhError;
      
      if (!fhData) {
        toast.error("Nu există o firmă asociată acestui cont.");
        return;
      }

      setFuneralHome(fhData);

      const { data: allOrdersData, error: allOrdersError } = await supabase
        .from("orders")
        .select("*")
        .eq("funeral_home_id", fhData.id)
        .order("created_at", { ascending: false });

      if (allOrdersError) throw allOrdersError;

      const allOrders = allOrdersData || [];
      setOrders(allOrders);

      const now = new Date();
      let filteredOrders = allOrders;
      
      if (timePeriod === "year") {
        const oneYearAgo = new Date(now.getFullYear() - 1, now.getMonth(), now.getDate());
        filteredOrders = allOrders.filter(order => new Date(order.created_at) >= oneYearAgo);
      } else if (timePeriod === "month") {
        const oneMonthAgo = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
        filteredOrders = allOrders.filter(order => new Date(order.created_at) >= oneMonthAgo);
      }

      const totalOrders = filteredOrders.length;
      const totalRevenue = filteredOrders.reduce((sum, order) => sum + Number(order.total_price), 0);
      const completedOrders = filteredOrders.filter(order => order.status === "completed").length;
      const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
      const completionRate = totalOrders > 0 ? (completedOrders / totalOrders) * 100 : 0;

      setStats({ totalOrders, potentialClients: 0, totalRevenue, averageOrderValue, completionRate });

      // Monthly stats
      const monthlyData: { [key: string]: { revenue: number; orders: number } } = {};
      const currentDate = new Date();
      
      for (let i = 11; i >= 0; i--) {
        const month = subMonths(currentDate, i);
        const monthKey = format(month, "MMM yyyy", { locale: ro });
        monthlyData[monthKey] = { revenue: 0, orders: 0 };
      }

      allOrders.forEach(order => {
        const orderDate = new Date(order.created_at);
        const monthKey = format(orderDate, "MMM yyyy", { locale: ro });
        if (monthlyData[monthKey]) {
          monthlyData[monthKey].revenue += Number(order.total_price);
          monthlyData[monthKey].orders += 1;
        }
      });

      setMonthlyStats(Object.entries(monthlyData).map(([month, data]) => ({
        month, revenue: data.revenue, orders: data.orders
      })));

      // Load call logs
      const { data: callLogsData } = await supabase
        .from("call_logs")
        .select("id, caller_name, caller_phone, tracking_phone, real_phone, call_status, call_duration, started_at, ended_at, funeral_home_id, recording_url, outcome, contact_person, outcome_notes, outcome_amount")
        .eq("funeral_home_id", fhData.id)
        .order("started_at", { ascending: false })
        .limit(100);

      const logs = (callLogsData || []) as unknown as CallLog[];
      setCallLogs(logs);
      setStats(prev => ({
        ...prev,
        potentialClients: logs.filter(log => (log.call_duration ?? 0) >= QUALIFIED_LEAD_SECONDS).length,
      }));

      // Restore persisted finalized outcomes
      setFinalizedCallIds(new Set(logs.filter(l => l.outcome === "resolved").map(l => l.id)));
      setLocalFinalizedOrders(
        logs
          .filter(l => l.outcome === "resolved")
          .map(l => ({
            id: l.id,
            contactName: l.contact_person || undefined,
            phone: l.caller_phone || "",
            price: Number(l.outcome_amount) || 0,
            address: "",
            date: "",
            details: l.outcome_notes || "",
            created_at: l.started_at,
          }))
      );


      // Top services/packages
      const { data: orderItemsData, error: itemsError } = await supabase
        .from("order_items")
        .select("*, orders!inner(funeral_home_id)")
        .eq("orders.funeral_home_id", fhData.id);

      if (!itemsError && orderItemsData) {
        const byOrder: Record<string, string[]> = {};
        orderItemsData.forEach((item: any) => {
          if (!byOrder[item.order_id]) byOrder[item.order_id] = [];
          byOrder[item.order_id].push(item.item_name);
        });
        setOrderServices(byOrder);

        const servicesMap: { [key: string]: { count: number; revenue: number } } = {};
        const packagesMap: { [key: string]: { count: number; revenue: number } } = {};

        orderItemsData.forEach(item => {
          if (item.service_id) {
            if (!servicesMap[item.item_name]) servicesMap[item.item_name] = { count: 0, revenue: 0 };
            servicesMap[item.item_name].count += item.quantity;
            servicesMap[item.item_name].revenue += Number(item.item_price) * item.quantity;
          } else if (item.package_id) {
            if (!packagesMap[item.item_name]) packagesMap[item.item_name] = { count: 0, revenue: 0 };
            packagesMap[item.item_name].count += item.quantity;
            packagesMap[item.item_name].revenue += Number(item.item_price) * item.quantity;
          }
        });

        setTopServices(Object.entries(servicesMap)
          .map(([name, data]) => ({ name, ...data }))
          .sort((a, b) => b.revenue - a.revenue)
          .slice(0, 5));
        
        setTopPackages(Object.entries(packagesMap)
          .map(([name, data]) => ({ name, ...data }))
          .sort((a, b) => b.revenue - a.revenue)
          .slice(0, 5));
      }
    } catch (error) {
      console.error("Error loading dashboard data:", error);
      toast.error("Eroare la încărcarea datelor.");
    }
  };

  useEffect(() => {
    if (funeralHome && user) {
      loadDashboardData(user.id);
    }
  }, [timePeriod, funeralHome?.id]);

  const startCallback = async (log: CallLog) => {
    setCallbackLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("firm-callback", {
        body: { callLogId: log.id },
      });
      if (error) {
        let details = error.message;
        try {
          const ctx = (error as any)?.context;
          if (ctx?.text) details = await ctx.text();
        } catch (_e) {
          // ignore
        }
        console.error("firm-callback failed:", details);
        toast.error("Apelul nu a putut fi inițiat. Încearcă din nou.");
        return;
      }
      if ((data as any)?.error) {
        toast.error((data as any).error);
        return;
      }
      toast.success("Te sunăm acum pe numărul firmei. Răspunde pentru a fi conectat cu clientul.");
      setCallbackTarget(null);
      if (user) setTimeout(() => loadDashboardData(user.id), 45000);
    } finally {
      setCallbackLoading(false);
    }
  };


  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="flex items-center justify-center h-[calc(100vh-80px)]">
          <DoveLoader label="Se încarcă dashboard-ul" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="container mx-auto px-4 py-6">
        {/* Prominent firm name */}
        <div className="mb-6">
          {funeralHome && (
            <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight">
              {funeralHome.name}
            </h1>
          )}
          <p className="text-muted-foreground mt-1">Panou de administrare</p>
        </div>

        <Tabs defaultValue="statistici" className="w-full">
          <TabsList className="w-full grid h-auto grid-cols-3 gap-1 mb-6 lg:grid-cols-6">
            <TabsTrigger value="statistici" className="min-h-11 gap-1 px-1 text-xs sm:text-sm sm:px-2">
              <BarChart3 className="h-4 w-4 hidden lg:block" />
              Statistici
            </TabsTrigger>
            <TabsTrigger value="rezultate" className="min-h-11 gap-1 px-1 text-xs sm:text-sm sm:px-2">
              <Award className="h-4 w-4 hidden lg:block" />
              Rezultate
            </TabsTrigger>
            <TabsTrigger value="apeluri" className="min-h-11 gap-1 px-1 text-xs sm:text-sm sm:px-2">
              <Phone className="h-4 w-4 hidden lg:block" />
              Apeluri
            </TabsTrigger>
            <TabsTrigger value="oferte" className="min-h-11 gap-1 px-1 text-xs sm:text-sm sm:px-2 whitespace-normal text-center leading-tight">
              <ShoppingCart className="h-4 w-4 hidden lg:block shrink-0" />
              Oferte cerute
            </TabsTrigger>
            <TabsTrigger value="servicii" className="min-h-11 gap-1 px-1 text-xs sm:text-sm sm:px-2">
              <Settings className="h-4 w-4 hidden lg:block" />
              Servicii
            </TabsTrigger>
            <TabsTrigger value="financiar" className="min-h-11 gap-1 px-1 text-xs sm:text-sm sm:px-2">
              <FileText className="h-4 w-4 hidden lg:block" />
              Financiar
            </TabsTrigger>
          </TabsList>

          {/* TAB: Rezultate (ROI) */}
          <TabsContent value="rezultate">
            {funeralHome ? (
              <RoiDashboard funeralHomeId={funeralHome.id} />
            ) : (
              <p className="text-muted-foreground text-center py-8">Nu există o firmă asociată.</p>
            )}
          </TabsContent>


          {/* TAB 1: Statistici */}
          <TabsContent value="statistici">
            {/* Time period filter */}
            <div className="mb-6 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex gap-2">
                <Button 
                  variant={timePeriod === "total" ? "default" : "outline"}
                  onClick={() => setTimePeriod("total")}
                  size="sm"
                >
                  Total
                </Button>
                <Button 
                  variant={timePeriod === "year" ? "default" : "outline"}
                  onClick={() => setTimePeriod("year")}
                  size="sm"
                >
                  Ultimul An
                </Button>
                <Button 
                  variant={timePeriod === "month" ? "default" : "outline"}
                  onClick={() => setTimePeriod("month")}
                  size="sm"
                >
                  Ultima Lună
                </Button>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="w-full gap-2 sm:w-auto"
                disabled={exporting || !funeralHome}
                onClick={handleExportExcel}
              >
                <Download className="h-4 w-4" />
                {exporting ? "Se generează..." : "Exportă Excel"}
              </Button>
            </div>


            {/* Statistici firmă */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-xs sm:text-sm font-medium">Potențiali Clienți</CardTitle>
                  <ShoppingCart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.potentialClients}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-xs sm:text-sm font-medium">Total comenzi</CardTitle>
                  <ShoppingCart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.totalOrders}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-xs sm:text-sm font-medium">Valoare Medie</CardTitle>
                  <Package className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.averageOrderValue.toFixed(0)} RON</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-xs sm:text-sm font-medium">Rată Finalizare</CardTitle>
                  <Award className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.completionRate.toFixed(0)}%</div>
                </CardContent>
              </Card>
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Evoluție Venituri</CardTitle>
                  <CardDescription>Ultimele 12 luni</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={monthlyStats}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                        <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} />
                        <Tooltip 
                          contentStyle={{ backgroundColor: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "var(--radius)" }}
                          formatter={(value: number) => `${value.toFixed(0)} RON`}
                        />
                        <Line type="monotone" dataKey="revenue" stroke="hsl(var(--primary))" strokeWidth={2} name="Venit" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Evoluție Leads</CardTitle>
                  <CardDescription>Ultimele 12 luni</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={monthlyStats}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                        <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} />
                        <Tooltip 
                          contentStyle={{ backgroundColor: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "var(--radius)" }}
                          formatter={(value: number) => `${value} leads`}
                        />
                        <Bar dataKey="orders" fill="hsl(var(--primary))" name="Leads" radius={[8, 8, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Top performers */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Top 5 Servicii</CardTitle>
                </CardHeader>
                <CardContent>
                  {topServices.length === 0 ? (
                    <BrandState title="Nu există date" className="py-6" />
                  ) : (
                    <div className="space-y-3">
                      {topServices.map((service, i) => (
                        <div key={i} className="flex items-center justify-between">
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm truncate">{service.name}</p>
                            <p className="text-xs text-muted-foreground">{service.count} vândute</p>
                          </div>
                          <p className="font-bold text-sm ml-2">{service.revenue.toFixed(0)} RON</p>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Top 5 Pachete</CardTitle>
                </CardHeader>
                <CardContent>
                  {topPackages.length === 0 ? (
                    <BrandState title="Nu există date" className="py-6" />
                  ) : (
                    <div className="space-y-3">
                      {topPackages.map((pkg, i) => (
                        <div key={i} className="flex items-center justify-between">
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm truncate">{pkg.name}</p>
                            <p className="text-xs text-muted-foreground">{pkg.count} vândute</p>
                          </div>
                          <p className="font-bold text-sm ml-2">{pkg.revenue.toFixed(0)} RON</p>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

          </TabsContent>

          {/* Apeluri */}
          <TabsContent value="apeluri">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Phone className="h-5 w-5" />
                    Apeluri
                  </CardTitle>
                  <CardDescription>Toate apelurile primite (leads)</CardDescription>
                </CardHeader>
                <CardContent>
                  {callLogs.filter(c => !finalizedCallIds.has(c.id)).length === 0 ? (
                    <BrandState title="Nu există apeluri." />
                  ) : (
                    <div className="space-y-2">
                      {callLogs.filter(c => !finalizedCallIds.has(c.id)).map((log) => {
                        const isQualified = (log.call_duration ?? 0) >= QUALIFIED_LEAD_SECONDS;
                        return (
                          <div key={log.id} className="flex items-center justify-between gap-2 p-3 rounded-lg border">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <span className="text-sm font-medium truncate">
                                  {log.caller_name || maskPhone(log.caller_phone)}
                                </span>
                                <LeadStatusBadge call={log} className="text-[10px] px-1.5" />
                              </div>
                              <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
                                {log.caller_name && log.caller_phone && <span>{maskPhone(log.caller_phone)}</span>}
                                <span>{format(new Date(log.started_at), "dd MMM, HH:mm", { locale: ro })}</span>
                                <span className="flex items-center gap-0.5">
                                  <Clock className="h-3 w-3" />
                                  {log.call_duration ? `${Math.floor(log.call_duration / 60)}:${(log.call_duration % 60).toString().padStart(2, '0')}` : "-"}
                                </span>
                              </div>
                            </div>
                            <div className="flex items-center gap-1 shrink-0">
                              {getLeadStatusKey(log) === "missed" && log.caller_phone && (
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-primary hover:bg-primary/10"
                                  title="Sună clientul"
                                  onClick={() => setCallbackTarget(log)}
                                >
                                  <PhoneCall className="h-4 w-4" />
                                </Button>
                              )}
                              {log.recording_url && (
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => {
                                    if (playingId === log.id) {
                                      audioRef.current?.pause();
                                      audioRef.current = null;
                                      setPlayingId(null);
                                    } else {
                                      if (audioRef.current) audioRef.current.pause();
                                      const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/get-recording?url=${encodeURIComponent(log.recording_url!)}`;
                                      const audio = new Audio(url);
                                      audio.onended = () => setPlayingId(null);
                                      audio.play();
                                      audioRef.current = audio;
                                      setPlayingId(log.id);
                                    }
                                  }}
                                >
                                  {playingId === log.id ? <Square className="h-4 w-4 text-destructive" /> : <Play className="h-4 w-4 text-primary" />}
                                </Button>
                              )}
                              {isQualified && (
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-primary hover:bg-primary/10"
                                  title="Finalizare"
                                  onClick={() => {
                                    setFinalizeCallLog(log);
                                    setFinalizeDialogOpen(true);
                                  }}
                                >
                                  <Check className="h-4 w-4" />
                                </Button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>

          </TabsContent>

          {/* Oferte cerute */}
          <TabsContent value="oferte">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ShoppingCart className="h-5 w-5" />
                    Oferte cerute
                  </CardTitle>
                  <CardDescription>Cereri primite și comenzi finalizate</CardDescription>
                </CardHeader>
                <CardContent>
                  {(() => {
                    const formLeadIds = new Set(
                      orders
                        .filter((o) => o.lead_source === 'quote' || o.lead_source === 'custom_package')
                        .map((o) => o.id)
                    );
                    const allItems: OrderItem[] = [
                      ...orders.map(o => {
                        const custom = o.order_type === 'custom';
                        const services = orderServices[o.id] || [];
                        const detailParts = [
                          custom && services.length > 0 ? `Servicii: ${services.join(', ')}` : '',
                          o.notes ? `Detalii: ${o.notes}` : '',
                        ].filter(Boolean);
                        return {
                          id: o.id,
                          name: o.customer_name,
                          phone: o.customer_phone,
                          date: o.created_at,
                          amount: Number(o.total_price),
                          status: o.status,
                          details: detailParts.join('\n'),
                          address: '',
                          custom,
                        };
                      }),
                      ...localFinalizedOrders.map(fo => ({ id: fo.id, name: fo.contactName || fo.phone, phone: fo.phone, date: fo.created_at, amount: fo.price, status: 'finalizat', details: fo.details, address: fo.address })),
                    ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

                    if (allItems.length === 0) {
                      return <BrandState title="Nu există oferte cerute sau comenzi încă." />;
                    }

                    return (
                      <div className="space-y-2">
                        {allItems.map((item) => (
                          <div
                            key={item.id}
                            className="flex items-center justify-between gap-2 p-3 rounded-lg border cursor-pointer hover:bg-muted/50 transition-colors"
                            onClick={() => { setSelectedOrder(item); setOrderDetailOpen(true); }}
                          >
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium truncate">{item.name}</p>
                              <p className="text-xs text-muted-foreground">
                                {format(new Date(item.date), "dd MMM yyyy, HH:mm", { locale: ro })}
                              </p>
                            </div>
                            <div className="flex flex-wrap items-center justify-end gap-2 shrink-0">
                              {item.custom && (
                                <Badge variant="outline" className="text-[10px]">Pachet personalizat</Badge>
                              )}
                              {formLeadIds.has(item.id) && !item.custom && (
                                <Badge variant="outline" className="text-[10px]">Lead formular</Badge>
                              )}
                              <Badge variant={item.status === "completed" || item.status === "finalizat" ? "default" : "secondary"} className="text-[10px]">
                                {item.status === "pending" ? "În așteptare" : item.status === "completed" ? "Finalizată" : item.status === "finalizat" ? "Din apel" : item.status}
                              </Badge>
                              {item.custom ? (
                                <span className="text-sm font-medium text-muted-foreground">La cerere</span>
                              ) : item.amount > 0 ? (
                                <span className="text-sm font-medium">{item.amount.toFixed(0)} RON</span>
                              ) : null}
                            </div>
                          </div>
                        ))}
                      </div>
                    );
                  })()}
                </CardContent>
              </Card>
          </TabsContent>

          {/* TAB 3: Servicii & Pachete */}
          <TabsContent value="servicii">
            {funeralHome ? (
              <ManageServicesEmbed funeralHomeId={funeralHome.id} />
            ) : (
              <p className="text-muted-foreground text-center py-8">Nu există o firmă asociată.</p>
            )}
          </TabsContent>

          {/* TAB 4: Financiar */}
          <TabsContent value="financiar">
            <div className="space-y-6">
              {/* Current subscription */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CreditCard className="h-5 w-5" />
                    Abonament Curent
                  </CardTitle>
                  <CardDescription>Detalii despre abonamentul dvs. activ</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 p-4 rounded-lg border bg-muted/30">
                    <div>
                      <p className="font-semibold text-lg">Plan Standard</p>
                      <p className="text-sm text-muted-foreground">Abonament lunar activ</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold">--,-- RON</p>
                      <p className="text-xs text-muted-foreground">/ lună</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Leads cost */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Cost Leads
                  </CardTitle>
                  <CardDescription>Calculul costului pentru leads-urile primite</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="p-4 rounded-lg border bg-muted/30 text-center">
                    <p className="text-muted-foreground text-sm">
                      Calculul costului per lead va fi disponibil în curând.
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Invoice history */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Istoric Facturi
                  </CardTitle>
                  <CardDescription>Facturile emise pentru serviciile utilizate</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-3 rounded-lg border text-center">
                      <p className="text-muted-foreground text-sm py-4 w-full">Nu există facturi încă.</p>
                    </div>
                  </div>
                  <div className="mt-4 p-3 rounded-lg border border-dashed text-center">
                    <p className="text-sm text-muted-foreground mb-2">
                      Descărcarea și plata facturilor vor fi disponibile în curând.
                    </p>
                    <div className="flex justify-center gap-2">
                      <Button variant="outline" size="sm" disabled className="gap-2">
                        <Download className="h-4 w-4" />
                        Descarcă
                      </Button>
                      <Button size="sm" disabled className="gap-2">
                        <CreditCard className="h-4 w-4" />
                        Plătește
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Callback confirm dialog */}
        <AlertDialog open={!!callbackTarget} onOpenChange={(o) => !o && setCallbackTarget(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Sună clientul</AlertDialogTitle>
              <AlertDialogDescription>
                Te vom suna pe numărul firmei. După ce răspunzi, te conectăm automat cu clientul
                ({maskPhone(callbackTarget?.caller_phone)}). Numărul clientului rămâne confidențial.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={callbackLoading}>Anulează</AlertDialogCancel>
              <AlertDialogAction
                disabled={callbackLoading}
                onClick={(e) => {
                  e.preventDefault();
                  if (callbackTarget) startCallback(callbackTarget);
                }}
              >
                {callbackLoading ? "Se inițiază..." : "Sună acum"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Finalize call dialog */}
        <FinalizeCallDialog
          open={finalizeDialogOpen}
          onOpenChange={setFinalizeDialogOpen}
          callerPhone={finalizeCallLog?.caller_phone || ""}
          onSave={async (data: FinalizeFormData) => {
            if (!finalizeCallLog || !funeralHome) return;
            const details = [data.address, data.details].filter(Boolean).join(" — ");
            const { error } = await supabase
              .from("call_logs")
              .update({
                outcome: "resolved",
                contact_person: data.contactName || null,
                outcome_notes: details || null,
                outcome_amount: data.price ? parseFloat(data.price) : null,
                resolved_at: new Date().toISOString(),
                resolved_by: user?.id ?? null,
              })
              .eq("id", finalizeCallLog.id);

            if (error) {
              console.error("Error saving call outcome:", error);
              toast.error("Eroare la salvarea apelului.");
              return;
            }

            setFinalizedCallIds(prev => new Set(prev).add(finalizeCallLog.id));
            setLocalFinalizedOrders(prev => [...prev, {
              id: finalizeCallLog.id,
              contactName: data.contactName,
              phone: data.phone,
              price: data.price ? parseFloat(data.price) : 0,
              address: data.address,
              date: data.date ? data.date.toISOString() : "",
              details,
              created_at: finalizeCallLog.started_at,
            }]);
            setCallLogs(prev => prev.map(l => l.id === finalizeCallLog.id ? { ...l, outcome: "resolved", contact_person: data.contactName } : l));
            setFinalizeDialogOpen(false);
            setFinalizeCallLog(null);
            toast.success("Apelul a fost transformat în comandă.");
          }}

        />
        <OrderDetailDialog
          open={orderDetailOpen}
          onOpenChange={setOrderDetailOpen}
          order={selectedOrder}
          onSave={(updated) => {
            // Update local finalized orders if it's one of them
            setLocalFinalizedOrders(prev => prev.map(fo => 
              fo.id === updated.id ? { ...fo, phone: updated.phone, price: updated.amount, address: updated.address || '', details: updated.details } : fo
            ));
            setSelectedOrder(updated);
            toast.success("Comanda a fost actualizată.");
          }}
        />
      </div>
    </div>
  );
};

export default DashboardPage;
