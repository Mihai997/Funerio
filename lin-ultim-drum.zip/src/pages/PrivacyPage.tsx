import Navigation from "@/components/Navigation";
import Seo from "@/components/Seo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const PrivacyPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Seo
        title="Politica de confidențialitate | Funerio"
        description="Cum colectează, folosește și protejează Funerio datele personale ale utilizatorilor platformei."
      />
      <Navigation />
      
      
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold mb-8">Politica de Confidențialitate</h1>
          
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>1. Introducere</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Funerio respectă confidențialitatea datelor dumneavoastră personale și se angajează să le protejeze în conformitate cu Regulamentul General privind Protecția Datelor (GDPR - Regulamentul UE 2016/679) și legislația română aplicabilă.
              </p>
              <p>
                Această Politică de Confidențialitate explică ce date personale colectăm, cum le folosim, cui le divulgăm și ce drepturi aveți în legătură cu acestea.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>2. Date Personale Colectate</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>Colectăm următoarele categorii de date personale:</p>
              
              <div className="mt-4">
                <h4 className="font-semibold text-foreground mb-2">2.1. Date furnizate direct de dumneavoastră:</h4>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Date de identificare: nume, prenume</li>
                  <li>Date de contact: adresă email, număr de telefon</li>
                  <li>Date despre companie: denumire firmă (pentru furnizori)</li>
                  <li>Date de autentificare: adresă email și parolă criptată</li>
                  <li>Informații despre solicitările făcute prin platformă</li>
                </ul>
              </div>

              <div className="mt-4">
                <h4 className="font-semibold text-foreground mb-2">2.2. Date colectate automat:</h4>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Date de utilizare: pagini vizitate, timpul petrecut, acțiuni efectuate</li>
                  <li>Date tehnice: adresă IP, tip browser, sistem de operare</li>
                  <li>Cookie-uri și tehnologii similare (vezi Politica de Cookie-uri)</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>3. Scopul Prelucrării Datelor</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>Folosim datele dumneavoastră personale pentru:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Furnizarea serviciilor platformei (conectare utilizatori - furnizori)</li>
                <li>Procesarea solicitărilor de oferte</li>
                <li>Gestionarea contului de utilizator</li>
                <li>Comunicarea cu dumneavoastră (notificări, răspunsuri la întrebări)</li>
                <li>Îmbunătățirea serviciilor noastre</li>
                <li>Îndeplinirea obligațiilor legale și fiscale</li>
                <li>Prevenirea fraudelor și asigurarea securității platformei</li>
                <li>Marketing (doar cu consimțământul dumneavoastră explicit)</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>4. Temeiul Legal al Prelucrării</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>Prelucrăm datele dumneavoastră pe baza următoarelor temeiuri legale:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li><strong>Executarea contractului:</strong> pentru furnizarea serviciilor solicitate</li>
                <li><strong>Consimțământul:</strong> pentru activități de marketing și utilizarea cookie-urilor</li>
                <li><strong>Interesul legitim:</strong> pentru îmbunătățirea serviciilor și securitate</li>
                <li><strong>Obligații legale:</strong> pentru conformarea cu cerințele legale</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>5. Partajarea Datelor</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>Datele dumneavoastră pot fi partajate cu:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li><strong>Furnizori parteneri:</strong> când solicitați o ofertă, datele sunt transmise furnizorului selectat</li>
                <li><strong>Furnizori de servicii:</strong> hosting, procesare plăți, marketing (cu acorduri stricte de confidențialitate)</li>
                <li><strong>Autorități:</strong> când este cerut de lege sau pentru protejarea drepturilor noastre</li>
              </ul>
              <p className="mt-4">
                Nu vindem și nu închiriem datele dumneavoastră personale către terți pentru scopuri de marketing.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>6. Securitatea Datelor</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Implementăm măsuri tehnice și organizatorice adecvate pentru a proteja datele dumneavoastră:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Criptarea parolelor folosind algoritmi moderni de hashing</li>
                <li>Conexiuni securizate HTTPS</li>
                <li>Protecție împotriva atacurilor XSS și CSRF</li>
                <li>Rate limiting pentru prevenirea abuzurilor</li>
                <li>Backup-uri regulate ale datelor</li>
                <li>Acces restricționat la datele personale doar pentru personal autorizat</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>7. Perioada de Stocare</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Păstrăm datele dumneavoastră personale doar atât timp cât este necesar pentru scopurile pentru care au fost colectate:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Date de cont: până la ștergerea contului sau 3 ani de inactivitate</li>
                <li>Solicitări și oferte: 5 ani pentru scopuri fiscale și legale</li>
                <li>Date de marketing: până la retragerea consimțământului</li>
                <li>Loguri de securitate: maxim 12 luni</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>8. Drepturile Dumneavoastră</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>În conformitate cu GDPR, aveți următoarele drepturi:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li><strong>Dreptul de acces:</strong> să obțineți o copie a datelor personale</li>
                <li><strong>Dreptul la rectificare:</strong> să corectați datele inexacte</li>
                <li><strong>Dreptul la ștergere:</strong> să solicitați ștergerea datelor ("dreptul de a fi uitat")</li>
                <li><strong>Dreptul la restricționare:</strong> să limitați prelucrarea datelor</li>
                <li><strong>Dreptul la portabilitate:</strong> să primiți datele într-un format structurat</li>
                <li><strong>Dreptul la opoziție:</strong> să vă opuneți prelucrării bazate pe interese legitime</li>
                <li><strong>Dreptul de a retrage consimțământul:</strong> oricând, fără a afecta legalitatea prelucrărilor anterioare</li>
              </ul>
              <p className="mt-4">
                Pentru exercitarea drepturilor, contactați-ne la: <strong>privacy@servicii-funerare.ro</strong>
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>9. Cookie-uri</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Folosim cookie-uri pentru a îmbunătăți experiența dumneavoastră pe platformă. Pentru detalii complete, consultați Politica de Cookie-uri.
              </p>
              <p>
                Puteți gestiona preferințele cookie-urilor prin banner-ul afișat la prima vizită sau în setările browser-ului.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>10. Transferuri Internaționale</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Datele dumneavoastră sunt stocate și procesate în Spațiul Economic European (SEE). În cazul unor transferuri în afara SEE, ne asigurăm că există garanții adecvate conform GDPR (ex: Clauze Contractuale Standard).
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>11. Modificări ale Politicii</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Ne rezervăm dreptul de a actualiza această Politică de Confidențialitate. Vă vom notifica despre modificări semnificative prin email sau prin afișarea unui anunț pe platformă. Data ultimei actualizări este indicată mai jos.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>12. Contact și Reclamații</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Pentru întrebări despre această politică sau despre prelucrarea datelor dumneavoastră:
              </p>
              <p className="font-medium">Email: privacy@servicii-funerare.ro</p>
              <p className="font-medium">Telefon: 0800 123 456</p>
              <p className="mt-4">
                De asemenea, aveți dreptul de a depune o plângere la Autoritatea Națională de Supraveghere a Prelucrării Datelor cu Caracter Personal (ANSPDCP): <a href="https://www.dataprotection.ro" className="underline text-primary" target="_blank" rel="noopener noreferrer">www.dataprotection.ro</a>
              </p>
              <p className="text-sm mt-4">Ultima actualizare: Ianuarie 2025</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPage;
