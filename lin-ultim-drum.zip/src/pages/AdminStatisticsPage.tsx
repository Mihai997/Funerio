import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import Navigation from "@/components/Navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import DoveLoader from "@/components/brand/DoveLoader";
import { cn } from "@/lib/utils";
import { startOfMonth, subDays } from "date-fns";
import {
  Users,
  MousePointerClick,
  CheckCircle2,
  Building2,
  Phone,
  FileText,
  BarChart3,
  Layers,
} from "lucide-react";
import { QUALIFIED_LEAD_SECONDS } from "@/lib/leadStatus";

const LEAD_MIN_DURATION = QUALIFIED_LEAD_SECONDS;

type PeriodKey = "7d" | "30d" | "month" | "all";

const PERIODS: { key: PeriodKey; label: string }[] = [
  { key: "7d", label: "7 zile" },
  { key: "30d", label: "30 zile" },
  { key: "month", label: "Luna curentă" },
  { key: "all", label: "Total" },
];

interface FunnelCounts {
  visitors: number;
  wizardStart: number;
  wizardComplete: number;
  viewFirms: number;
  calls: number;
  quotes: number;
}

interface FirmCounts {
  total: number;
  active: number;
  inactive: number;
  withLeads: number;
}

interface LeadCounts {
  total: number;
  valid: number;
  calls: number;
  quotes: number;
}

const AdminStatisticsPage = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [period, setPeriod] = useState<PeriodKey>("30d");
  const [funnel, setFunnel] = useState<FunnelCounts | null>(null);
  const [firms, setFirms] = useState<FirmCounts | null>(null);
  const [leads, setLeads] = useState<LeadCounts | null>(null);
  const [dataLoading, setDataLoading] = useState(true);

  const range = useMemo(() => {
    const now = new Date();
    if (period === "7d") return { from: subDays(now, 7), to: now };
    if (period === "30d") return { from: subDays(now, 30), to: now };
    if (period === "month") return { from: startOfMonth(now), to: now };
    return { from: new Date("2000-01-01"), to: now };
  }, [period]);

  useEffect(() => {
    const init = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate("/auth");
        return;
      }
      const { data } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", session.user.id)
        .eq("role", "admin")
        .maybeSingle();

      if (!data) {
        toast.error("Nu aveți permisiuni de administrator.");
        navigate("/");
        return;
      }
      setIsAdmin(true);
      setLoading(false);
    };
    void init();
  }, [navigate]);

  useEffect(() => {
    if (!isAdmin) return;

    const load = async () => {
      setDataLoading(true);
      try {
        const fromIso = range.from.toISOString();
        const toIso = range.to.toISOString();

        const [funnelRes, homesRes, callsRes, ordersRes] = await Promise.all([
          supabase.rpc("get_site_funnel", { _from: fromIso, _to: toIso }),
          supabase.from("funeral_homes").select("id, subscription_active"),
          supabase
            .from("call_logs")
            .select("id, funeral_home_id, call_duration")
            .gte("started_at", fromIso)
            .lte("started_at", toIso),
          supabase
            .from("orders")
            .select("id, funeral_home_id")
            .gte("created_at", fromIso)
            .lte("created_at", toIso),
        ]);

        const funnelRows = (funnelRes.data || []) as { event_name: string; sessions: number }[];
        const sessionsFor = (name: string) =>
          Number(funnelRows.find((r) => r.event_name === name)?.sessions ?? 0);

        setFunnel({
          visitors: sessionsFor("page_view"),
          wizardStart: sessionsFor("wizard_start"),
          wizardComplete: sessionsFor("wizard_complete"),
          viewFirms: sessionsFor("view_firms"),
          calls: sessionsFor("call_requested"),
          quotes: sessionsFor("quote_requested"),
        });

        const homes = homesRes.data || [];
        const callRows = callsRes.data || [];
        const orderRows = ordersRes.data || [];

        const firmsWithLeads = new Set<string>([
          ...callRows.map((c) => c.funeral_home_id),
          ...orderRows.map((o) => o.funeral_home_id),
        ]);

        setFirms({
          total: homes.length,
          active: homes.filter((h) => h.subscription_active).length,
          inactive: homes.filter((h) => !h.subscription_active).length,
          withLeads: firmsWithLeads.size,
        });

        const validCalls = callRows.filter((c) => (c.call_duration || 0) >= LEAD_MIN_DURATION).length;
        setLeads({
          total: callRows.length + orderRows.length,
          valid: validCalls + orderRows.length,
          calls: callRows.length,
          quotes: orderRows.length,
        });
      } catch (error) {
        console.error("Error loading statistics:", error);
        toast.error("Eroare la încărcarea statisticilor.");
      } finally {
        setDataLoading(false);
      }
    };

    void load();
  }, [isAdmin, range]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <DoveLoader />
      </div>
    );
  }

  if (!isAdmin) return null;

  const funnelSteps = funnel
    ? [
        { label: "Vizitatori", value: funnel.visitors, icon: Users },
        { label: "Au început wizard-ul", value: funnel.wizardStart, icon: MousePointerClick },
        { label: "L-au finalizat", value: funnel.wizardComplete, icon: CheckCircle2 },
        { label: "Au văzut firme", value: funnel.viewFirms, icon: Building2 },
        { label: "Au sunat", value: funnel.calls, icon: Phone },
        { label: "Au cerut ofertă", value: funnel.quotes, icon: FileText },
      ]
    : [];

  const maxFunnel = Math.max(1, ...funnelSteps.map((s) => s.value));
  const conversion =
    funnel && funnel.visitors > 0
      ? Math.round(((funnel.calls + funnel.quotes) / funnel.visitors) * 100)
      : 0;

  const StatCard = ({
    title,
    value,
    hint,
    icon: Icon,
    tone,
  }: {
    title: string;
    value: number | string;
    hint?: string;
    icon: typeof Users;
    tone?: "success" | "danger";
  }) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-xs font-medium sm:text-sm">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div
          className={cn(
            "text-2xl font-bold",
            tone === "success" && "text-emerald-600 dark:text-emerald-400",
            tone === "danger" && "text-destructive"
          )}
        >
          {value}
        </div>
        {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h1 className="flex items-center gap-2 text-3xl font-bold">
              <BarChart3 className="h-7 w-7" />
              Statistici platformă
            </h1>
            <p className="mt-1 text-muted-foreground">
              Cerere, firme și lead-uri pe perioada selectată
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {PERIODS.map((p) => (
              <Button
                key={p.key}
                variant={period === p.key ? "default" : "outline"}
                size="sm"
                className="rounded-full"
                onClick={() => setPeriod(p.key)}
              >
                {p.label}
              </Button>
            ))}
          </div>
        </div>

        {dataLoading ? (
          <p className="py-10 text-center text-sm text-muted-foreground">Se încarcă statisticile...</p>
        ) : (
          <div className="space-y-8">
            {/* Cerere */}
            <Card>
              <CardHeader>
                <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Layers className="h-5 w-5" />
                      Cerere
                    </CardTitle>
                    <CardDescription>
                      Pâlnia vizitator → acțiune (sesiuni unice)
                    </CardDescription>
                  </div>
                  <Badge variant="secondary" className="w-fit">
                    Rată conversie totală: {conversion}%
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {funnelSteps.map((step) => {
                  const share = funnel && funnel.visitors > 0
                    ? Math.round((step.value / funnel.visitors) * 100)
                    : 0;
                  return (
                    <div key={step.label} className="space-y-1.5">
                      <div className="flex items-center justify-between gap-2 text-sm">
                        <span className="flex items-center gap-2">
                          <step.icon className="h-4 w-4 text-muted-foreground" />
                          {step.label}
                        </span>
                        <span className="font-semibold">
                          {step.value}
                          <span className="ml-2 text-xs font-normal text-muted-foreground">
                            {share}% din vizitatori
                          </span>
                        </span>
                      </div>
                      <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                        <div
                          className="h-full rounded-full bg-primary transition-all"
                          style={{ width: `${Math.round((step.value / maxFunnel) * 100)}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
                <p className="pt-2 text-xs text-muted-foreground">
                  Datele de pâlnie sunt colectate anonim și încep de la momentul activării urmăririi.
                </p>
              </CardContent>
            </Card>

            {/* Firme */}
            <div>
              <h2 className="mb-3 flex items-center gap-2 text-xl font-semibold">
                <Building2 className="h-5 w-5" />
                Firme
              </h2>
              <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
                <StatCard title="Firme înscrise" value={firms?.total ?? 0} icon={Building2} />
                <StatCard title="Active" value={firms?.active ?? 0} icon={CheckCircle2} tone="success" />
                <StatCard title="Inactive" value={firms?.inactive ?? 0} icon={Building2} tone="danger" />
                <StatCard
                  title="Au primit lead"
                  value={firms?.withLeads ?? 0}
                  hint="în perioada selectată"
                  icon={Users}
                />
              </div>
            </div>

            {/* Lead-uri */}
            <div>
              <h2 className="mb-3 flex items-center gap-2 text-xl font-semibold">
                <Phone className="h-5 w-5" />
                Lead-uri
              </h2>
              <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
                <StatCard title="Total lead-uri" value={leads?.total ?? 0} icon={Layers} />
                <StatCard
                  title="Lead-uri valide"
                  value={leads?.valid ?? 0}
                  hint={`apeluri de minimum ${LEAD_MIN_DURATION}s + cereri de ofertă`}
                  icon={CheckCircle2}
                />
                <StatCard title="Apeluri" value={leads?.calls ?? 0} icon={Phone} />
                <StatCard title="Cereri de ofertă" value={leads?.quotes ?? 0} icon={FileText} />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminStatisticsPage;
