import { useEffect, useState, useMemo } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Session } from "@supabase/supabase-js";
import Navigation from "@/components/Navigation";
import CallLogsTable from "@/components/CallLogsTable";
import ManageServicesEmbed from "@/components/dashboard/ManageServicesEmbed";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { ArrowLeft, FileText, CreditCard, BarChart3, Package, PhoneCall, Receipt, Users, TrendingUp } from "lucide-react";
import DoveLoader from "@/components/brand/DoveLoader";
import { QUALIFIED_LEAD_SECONDS } from "@/lib/leadStatus";

interface FuneralHome {
  id: string;
  name: string;
  subscription_active: boolean;
}

interface Stats {
  totalLeads: number;
  totalCalls: number;
}

const SUBSCRIPTION_PRICE = 150;
const LEAD_PRICE = 30;
const LEAD_MIN_DURATION = QUALIFIED_LEAD_SECONDS; // seconds

const monthNames = [
  "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
  "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie",
];

const AdminDashboardPage = () => {
  const navigate = useNavigate();
  const { funeralHomeId } = useParams<{ funeralHomeId: string }>();
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [funeralHome, setFuneralHome] = useState<FuneralHome | null>(null);
  const [stats, setStats] = useState<Stats>({ totalLeads: 0, totalCalls: 0 });

  // Financial state
  const today = new Date();
  const [period, setPeriod] = useState<"month" | "6m" | "1y" | "all">("month");
  const [selectedYear, setSelectedYear] = useState<number>(today.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState<number>(today.getMonth()); // 0-11
  const [billableLeads, setBillableLeads] = useState<number>(0);
  const [loadingLeads, setLoadingLeads] = useState(false);
  const [savingSubscription, setSavingSubscription] = useState(false);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (!session) {
        navigate("/auth");
      } else {
        checkAdminAndLoadData(session.user.id);
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate, funeralHomeId]);

  // Period range (start inclusive, end exclusive). null start = all time.
  const range = useMemo(() => {
    const now = new Date();
    if (period === "month") {
      return {
        start: new Date(selectedYear, selectedMonth, 1),
        end: new Date(selectedYear, selectedMonth + 1, 1),
        months: 1,
        label: `1 – ${new Date(selectedYear, selectedMonth + 1, 0).getDate()} ${monthNames[selectedMonth]} ${selectedYear}`,
      };
    }
    const end = new Date(now.getFullYear(), now.getMonth() + 1, 1);
    if (period === "6m") {
      const start = new Date(now.getFullYear(), now.getMonth() - 5, 1);
      return { start, end, months: 6, label: `ultimele 6 luni` };
    }
    if (period === "1y") {
      const start = new Date(now.getFullYear(), now.getMonth() - 11, 1);
      return { start, end, months: 12, label: `ultimele 12 luni` };
    }
    return { start: null as Date | null, end: null as Date | null, months: 1, label: "tot istoricul" };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [period, selectedYear, selectedMonth]);

  // Reload billable leads when period/month/year/firm changes
  useEffect(() => {
    if (funeralHomeId && isAdmin) {
      loadBillableLeads(funeralHomeId, range.start, range.end);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [funeralHomeId, isAdmin, range]);

  const checkAdminAndLoadData = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", userId)
        .eq("role", "admin")
        .maybeSingle();

      if (error) throw error;

      if (!data) {
        toast.error("Nu aveți permisiuni de administrator.");
        navigate("/");
        return;
      }

      setIsAdmin(true);

      if (funeralHomeId) {
        await loadDashboardData(funeralHomeId);
      }

      setLoading(false);
    } catch (error) {
      console.error("Error checking admin role:", error);
      toast.error("Eroare la verificarea rolului.");
      navigate("/");
    }
  };

  const loadDashboardData = async (fhId: string) => {
    try {
      const { data: fhData, error: fhError } = await supabase
        .from("funeral_homes")
        .select("id, name, subscription_active")
        .eq("id", fhId)
        .maybeSingle();

      if (fhError) throw fhError;

      if (!fhData) {
        toast.error("Firma nu a fost găsită.");
        navigate("/admin/funeral-homes");
        return;
      }

      setFuneralHome(fhData as FuneralHome);

      // Run both counts in parallel: total calls + billable leads (minimum 40s)
      const [{ count: totalCount, error: totalErr }, { count: leadsCount, error: leadsErr }] = await Promise.all([
        supabase
          .from("call_logs")
          .select("id", { count: "exact", head: true })
          .eq("funeral_home_id", fhId),
        supabase
          .from("call_logs")
          .select("id", { count: "exact", head: true })
          .eq("funeral_home_id", fhId)
          .gte("call_duration", LEAD_MIN_DURATION),
      ]);

      if (totalErr) throw totalErr;
      if (leadsErr) throw leadsErr;

      setStats({ totalCalls: totalCount || 0, totalLeads: leadsCount || 0 });
    } catch (error) {
      console.error("Error loading dashboard data:", error);
      toast.error("Eroare la încărcarea datelor.");
    }
  };

  const loadBillableLeads = async (fhId: string, start: Date | null, end: Date | null) => {
    setLoadingLeads(true);
    try {
      let query = supabase
        .from("call_logs")
        .select("id", { count: "exact", head: true })
        .eq("funeral_home_id", fhId)
        .gte("call_duration", LEAD_MIN_DURATION);

      if (start) query = query.gte("started_at", start.toISOString());
      if (end) query = query.lt("started_at", end.toISOString());

      const { count, error } = await query;

      if (error) throw error;
      setBillableLeads(count || 0);
    } catch (error) {
      console.error("Error loading billable leads:", error);
      toast.error("Eroare la încărcarea apelurilor facturabile.");
    } finally {
      setLoadingLeads(false);
    }
  };

  const handleToggleSubscription = async (active: boolean) => {
    if (!funeralHome) return;
    setSavingSubscription(true);
    try {
      const { error } = await supabase
        .from("funeral_homes")
        .update({ subscription_active: active })
        .eq("id", funeralHome.id);
      if (error) throw error;
      setFuneralHome({ ...funeralHome, subscription_active: active });
      toast.success(active ? "Abonament activat." : "Abonament dezactivat.");
    } catch (error) {
      console.error("Error updating subscription:", error);
      toast.error("Eroare la actualizarea abonamentului.");
    } finally {
      setSavingSubscription(false);
    }
  };

  const yearOptions = useMemo(() => {
    const years: number[] = [];
    for (let y = today.getFullYear(); y >= today.getFullYear() - 3; y--) years.push(y);
    return years;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const subscriptionMonths = range.months;
  const subscriptionCost = funeralHome?.subscription_active ? SUBSCRIPTION_PRICE * subscriptionMonths : 0;
  const leadsCost = billableLeads * LEAD_PRICE;
  const totalCost = subscriptionCost + leadsCost;
  const isCurrentMonth =
    period === "month" && selectedYear === today.getFullYear() && selectedMonth === today.getMonth();

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="flex items-center justify-center h-[calc(100vh-80px)]">
          <DoveLoader label="Se încarcă dashboard-ul firmei" />
        </div>
      </div>
    );
  }

  if (!isAdmin) return null;

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="container mx-auto px-4 py-6">
        {/* Header */}
        <div className="mb-6">
          {funeralHome && (
            <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight">
              {funeralHome.name}
            </h1>
          )}
          <p className="text-muted-foreground mt-1 mb-4">Administrare firmă</p>
          <div className="flex flex-wrap gap-2">
            <Link to="/admin/funeral-homes">
              <Button variant="outline" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Lista firmelor
              </Button>
            </Link>
          </div>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="w-full grid grid-cols-3">
            <TabsTrigger value="overview" className="gap-2">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">Sumar</span>
            </TabsTrigger>
            <TabsTrigger value="services" className="gap-2">
              <Package className="h-4 w-4" />
              <span className="hidden sm:inline">Servicii & Pachete</span>
              <span className="sm:hidden">Servicii</span>
            </TabsTrigger>
            <TabsTrigger value="financial" className="gap-2">
              <FileText className="h-4 w-4" />
              <span className="hidden sm:inline">Financiar</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-xs sm:text-sm font-medium">Potențiali Clienți</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.totalLeads}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Apeluri cu durată &gt; {LEAD_MIN_DURATION}s
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-xs sm:text-sm font-medium">Rată Conversie Apeluri</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {stats.totalCalls > 0
                      ? `${Math.round((stats.totalLeads / stats.totalCalls) * 100)}%`
                      : "—"}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {stats.totalLeads} din {stats.totalCalls} apeluri primite
                  </p>
                </CardContent>
              </Card>
            </div>

            {funeralHomeId && (
              <CallLogsTable
                funeralHomeId={funeralHomeId}
                limit={20}
                title="Apeluri (Leads)"
              />
            )}
          </TabsContent>

          <TabsContent value="services">
            {funeralHomeId && <ManageServicesEmbed funeralHomeId={funeralHomeId} />}
          </TabsContent>

          <TabsContent value="financial" className="space-y-6">
            {/* Header + period selector */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Financiar
              </h2>
              <div className="flex flex-wrap gap-2">
                <Select value={period} onValueChange={(v) => setPeriod(v as typeof period)}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="month">1 lună</SelectItem>
                    <SelectItem value="6m">6 luni</SelectItem>
                    <SelectItem value="1y">1 an</SelectItem>
                    <SelectItem value="all">Total</SelectItem>
                  </SelectContent>
                </Select>
                {period === "month" && (
                  <>
                    <Select value={String(selectedMonth)} onValueChange={(v) => setSelectedMonth(parseInt(v))}>
                      <SelectTrigger className="w-[140px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {monthNames.map((m, i) => (
                          <SelectItem key={i} value={String(i)}>{m}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select value={String(selectedYear)} onValueChange={(v) => setSelectedYear(parseInt(v))}>
                      <SelectTrigger className="w-[100px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {yearOptions.map(y => (
                          <SelectItem key={y} value={String(y)}>{y}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </>
                )}
              </div>
            </div>

            <p className="text-sm text-muted-foreground -mt-2">
              Date pentru perioada <span className="font-medium text-foreground">{range.label}</span>
              {isCurrentMonth && <span className="ml-1">(luna curentă, în desfășurare)</span>}
            </p>


            {/* Subscription card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <CreditCard className="h-5 w-5" />
                  Abonament lunar
                </CardTitle>
                <CardDescription>Plan standard, taxă fixă lunară</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-lg border bg-muted/30">
                  <div>
                    <p className="font-semibold">Plan Standard</p>
                    <p className="text-sm text-muted-foreground">{SUBSCRIPTION_PRICE} RON / lună</p>
                  </div>
                  <Badge variant={funeralHome?.subscription_active ? "default" : "secondary"}>
                    {funeralHome?.subscription_active ? "Activ" : "Inactiv"}
                  </Badge>
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg border">
                  <Label htmlFor="sub-toggle" className="cursor-pointer">
                    Abonament activ
                  </Label>
                  <Switch
                    id="sub-toggle"
                    checked={!!funeralHome?.subscription_active}
                    disabled={savingSubscription}
                    onCheckedChange={handleToggleSubscription}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Leads (calls of at least 40s) card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <PhoneCall className="h-5 w-5" />
                  Leads facturabile
                </CardTitle>
                <CardDescription>
                  Apeluri cu durată de minimum {LEAD_MIN_DURATION} secunde · {LEAD_PRICE} RON / lead
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="p-4 rounded-lg border text-center">
                    <p className="text-xs text-muted-foreground mb-1">Număr leads</p>
                    <p className="text-2xl font-bold">
                      {loadingLeads ? <DoveLoader size="inline" label="Se calculează lead-urile" /> : billableLeads}
                    </p>
                  </div>
                  <div className="p-4 rounded-lg border text-center">
                    <p className="text-xs text-muted-foreground mb-1">Preț per lead</p>
                    <p className="text-2xl font-bold">{LEAD_PRICE} RON</p>
                  </div>
                  <div className="p-4 rounded-lg border text-center bg-muted/30">
                    <p className="text-xs text-muted-foreground mb-1">Subtotal leads</p>
                    <p className="text-2xl font-bold">{leadsCost} RON</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Total breakdown */}
            <Card className="border-primary/40">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Receipt className="h-5 w-5" />
                  Total de plată — {period === "month" ? `${monthNames[selectedMonth]} ${selectedYear}` : range.label}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center text-sm">
                  <div>
                    <p className="font-medium">Abonament</p>
                    <p className="text-xs text-muted-foreground">
                      {funeralHome?.subscription_active
                        ? `Plan Standard activ · ${SUBSCRIPTION_PRICE} RON × ${subscriptionMonths} ${subscriptionMonths === 1 ? "lună" : "luni"}`
                        : "Abonament inactiv în această perioadă"}
                    </p>
                  </div>
                  <p className="font-semibold">{subscriptionCost} RON</p>
                </div>

                <div className="flex justify-between items-center text-sm">
                  <div>
                    <p className="font-medium">Leads peste {LEAD_MIN_DURATION}s</p>
                    <p className="text-xs text-muted-foreground">
                      {billableLeads} {billableLeads === 1 ? "lead" : "leads"} × {LEAD_PRICE} RON
                    </p>
                  </div>
                  <p className="font-semibold">{leadsCost} RON</p>
                </div>

                <div className="border-t pt-3 flex justify-between items-center">
                  <p className="text-base font-bold">Total</p>
                  <p className="text-2xl font-extrabold text-primary">{totalCost} RON</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboardPage;
