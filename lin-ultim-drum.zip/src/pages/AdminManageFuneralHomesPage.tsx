import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Session } from "@supabase/supabase-js";
import Navigation from "@/components/Navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { Building2, Plus, Pencil, Trash2, LayoutDashboard, Search, X, ArrowUpDown } from "lucide-react";
import DoveLoader from "@/components/brand/DoveLoader";
import BrandState from "@/components/brand/BrandState";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import FirmScoreBadge from "@/components/admin/FirmScoreBadge";
import { mapScoreRow, type FirmScoreRow } from "@/lib/firmScore";


interface FuneralHome {
  id: string;
  name: string;
  city: string;
  county: string;
  email: string;
  phone: string;
  description: string;
  price_range: string;
  tracking_phone: string | null;
}

const AdminManageFuneralHomesPage = () => {
  const navigate = useNavigate();
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [funeralHomes, setFuneralHomes] = useState<FuneralHome[]>([]);
  const [scores, setScores] = useState<Record<string, FirmScoreRow>>({});
  const [sortByScore, setSortByScore] = useState(false);
  const [onlyMissingTracking, setOnlyMissingTracking] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  
  const [newFhName, setNewFhName] = useState("");
  const [newFhCity, setNewFhCity] = useState("");
  const [newFhCounty, setNewFhCounty] = useState("");
  const [newFhEmail, setNewFhEmail] = useState("");
  const [newFhPhone, setNewFhPhone] = useState("");
  const [newFhDescription, setNewFhDescription] = useState("");
  const [newFhTrackingPhone, setNewFhTrackingPhone] = useState("");
  
  // Edit dialog state
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingHome, setEditingHome] = useState<FuneralHome | null>(null);
  const [editName, setEditName] = useState("");
  const [editCity, setEditCity] = useState("");
  const [editCounty, setEditCounty] = useState("");
  const [editEmail, setEditEmail] = useState("");
  const [editPhone, setEditPhone] = useState("");
  const [editDescription, setEditDescription] = useState("");
  
  const [editTrackingPhone, setEditTrackingPhone] = useState("");

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);

      if (event === "SIGNED_OUT") {
        setIsAdmin(false);
        navigate("/auth");
      }
    });

    const initializePage = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setSession(session);

      if (!session) {
        setLoading(false);
        navigate("/auth");
        return;
      }

      await checkAdminRole(session.user.id);
    };

    void initializePage();

    return () => subscription.unsubscribe();
  }, [navigate]);

  const checkAdminRole = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", userId)
        .eq("role", "admin")
        .maybeSingle();

      if (error) throw error;

      if (!data) {
        toast.error("Nu aveți permisiuni de administrator.");
        navigate("/");
        return;
      }

      setIsAdmin(true);
      await loadFuneralHomes();
    } catch (error) {
      console.error("Error checking admin role:", error);
      toast.error("Eroare la verificarea rolului.");
      navigate("/");
    } finally {
      setLoading(false);
    }
  };

  const loadFuneralHomes = async () => {
    try {
      const { data, error } = await supabase
        .from("funeral_homes")
        .select("*")
        .order("name", { ascending: true });

      if (error) throw error;

      setFuneralHomes(data || []);

      const { data: scoreData } = await supabase.rpc("get_firm_scores");
      if (scoreData) {
        const map: Record<string, FirmScoreRow> = {};
        (scoreData as any[]).forEach((row) => {
          const mapped = mapScoreRow(row);
          map[mapped.funeralHomeId] = mapped;
        });
        setScores(map);
      }
    } catch (error) {
      console.error("Error loading funeral homes:", error);
      toast.error("Eroare la încărcarea firmelor.");
    }
  };


  const handleCreateFuneralHome = async () => {
    if (!newFhName || !newFhCity || !newFhCounty || !newFhEmail || !newFhPhone || !newFhDescription) {
      toast.error("Toate câmpurile sunt obligatorii.");
      return;
    }

    try {
      const { error } = await supabase
        .from("funeral_homes")
        .insert({
          name: newFhName,
          city: newFhCity,
          county: newFhCounty,
          email: newFhEmail,
          phone: newFhPhone,
          description: newFhDescription,
          price_range: "€",
          tracking_phone: newFhTrackingPhone || null,
        });

      if (error) throw error;

      toast.success("Firma funerară a fost creată cu succes.");
      setIsCreateDialogOpen(false);
      setNewFhName("");
      setNewFhCity("");
      setNewFhCounty("");
      setNewFhEmail("");
      setNewFhPhone("");
      setNewFhDescription("");
      setNewFhTrackingPhone("");
      loadFuneralHomes();
    } catch (error) {
      console.error("Error creating funeral home:", error);
      toast.error("Eroare la crearea firmei funerare.");
    }
  };

  const handleDeleteFuneralHome = async (id: string) => {
    if (!confirm("Sigur doriți să ștergeți această firmă funerară?")) {
      return;
    }

    try {
      const { error } = await supabase
        .from("funeral_homes")
        .delete()
        .eq("id", id);

      if (error) throw error;

      toast.success("Firma funerară a fost ștearsă.");
      loadFuneralHomes();
    } catch (error) {
      console.error("Error deleting funeral home:", error);
      toast.error("Eroare la ștergerea firmei funerare.");
    }
  };

  const handleEditHome = (home: FuneralHome) => {
    setEditingHome(home);
    setEditName(home.name);
    setEditCity(home.city);
    setEditCounty(home.county);
    setEditEmail(home.email);
    setEditPhone(home.phone);
    setEditDescription(home.description);
    
    setEditTrackingPhone(home.tracking_phone || "");
    setIsEditDialogOpen(true);
  };

  const handleSaveHome = async () => {
    if (!editingHome) return;

    if (!editName || !editCity || !editCounty || !editEmail || !editPhone || !editDescription) {
      toast.error("Toate câmpurile obligatorii trebuie completate.");
      return;
    }

    try {
      const { error } = await supabase
        .from("funeral_homes")
        .update({
          name: editName,
          city: editCity,
          county: editCounty,
          email: editEmail,
          phone: editPhone,
          description: editDescription,
          tracking_phone: editTrackingPhone || null,
        })
        .eq("id", editingHome.id);

      if (error) throw error;

      toast.success("Firma funerară a fost actualizată.");
      setIsEditDialogOpen(false);
      setEditingHome(null);
      loadFuneralHomes();
    } catch (error) {
      console.error("Error updating funeral home:", error);
      toast.error("Eroare la actualizarea firmei funerare.");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="flex items-center justify-center h-[calc(100vh-80px)]">
          <DoveLoader label="Se încarcă firmele" />
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  const missingTrackingCount = funeralHomes.filter((fh) => !fh.tracking_phone).length;

  const filteredFuneralHomes = funeralHomes
    .filter((fh) => fh.name.toLowerCase().includes(searchQuery.toLowerCase()))
    .filter((fh) => (onlyMissingTracking ? !fh.tracking_phone : true))
    .sort((a, b) => {
      if (!sortByScore) return 0;
      return (scores[b.id]?.score ?? -1) - (scores[a.id]?.score ?? -1);
    });


  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8 flex flex-col gap-4 md:flex-row md:justify-between md:items-center">
          <div>
            <h1 className="text-3xl font-bold">Gestionare Firme Funerare</h1>
            <p className="text-muted-foreground mt-1">
              Administrați firmele funerare din platformă
            </p>
          </div>
          <div className="flex flex-col gap-3 md:flex-row-reverse md:items-center md:gap-3">
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Adaugă Firmă Funerară
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Adaugă Firmă Funerară Nouă</DialogTitle>
                <DialogDescription>
                  Completați informațiile pentru noua firmă funerară.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="fh-name">Nume Firmă *</Label>
                  <Input
                    id="fh-name"
                    value={newFhName}
                    onChange={(e) => setNewFhName(e.target.value)}
                    placeholder="Ex: Casa Funerară Speranța"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="fh-city">Oraș *</Label>
                    <Input
                      id="fh-city"
                      value={newFhCity}
                      onChange={(e) => setNewFhCity(e.target.value)}
                      placeholder="Ex: București"
                    />
                  </div>
                  <div>
                    <Label htmlFor="fh-county">Județ *</Label>
                    <Select value={newFhCounty} onValueChange={setNewFhCounty}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selectați județul" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Alba">Alba</SelectItem>
                        <SelectItem value="Arad">Arad</SelectItem>
                        <SelectItem value="Argeș">Argeș</SelectItem>
                        <SelectItem value="Bacău">Bacău</SelectItem>
                        <SelectItem value="Bihor">Bihor</SelectItem>
                        <SelectItem value="Bistrița-Năsăud">Bistrița-Năsăud</SelectItem>
                        <SelectItem value="Botoșani">Botoșani</SelectItem>
                        <SelectItem value="Brașov">Brașov</SelectItem>
                        <SelectItem value="Brăila">Brăila</SelectItem>
                        <SelectItem value="București">București</SelectItem>
                        <SelectItem value="Buzău">Buzău</SelectItem>
                        <SelectItem value="Caraș-Severin">Caraș-Severin</SelectItem>
                        <SelectItem value="Călărași">Călărași</SelectItem>
                        <SelectItem value="Cluj">Cluj</SelectItem>
                        <SelectItem value="Constanța">Constanța</SelectItem>
                        <SelectItem value="Covasna">Covasna</SelectItem>
                        <SelectItem value="Dâmbovița">Dâmbovița</SelectItem>
                        <SelectItem value="Dolj">Dolj</SelectItem>
                        <SelectItem value="Galați">Galați</SelectItem>
                        <SelectItem value="Giurgiu">Giurgiu</SelectItem>
                        <SelectItem value="Gorj">Gorj</SelectItem>
                        <SelectItem value="Harghita">Harghita</SelectItem>
                        <SelectItem value="Hunedoara">Hunedoara</SelectItem>
                        <SelectItem value="Ialomița">Ialomița</SelectItem>
                        <SelectItem value="Iași">Iași</SelectItem>
                        <SelectItem value="Ilfov">Ilfov</SelectItem>
                        <SelectItem value="Maramureș">Maramureș</SelectItem>
                        <SelectItem value="Mehedinți">Mehedinți</SelectItem>
                        <SelectItem value="Mureș">Mureș</SelectItem>
                        <SelectItem value="Neamț">Neamț</SelectItem>
                        <SelectItem value="Olt">Olt</SelectItem>
                        <SelectItem value="Prahova">Prahova</SelectItem>
                        <SelectItem value="Satu Mare">Satu Mare</SelectItem>
                        <SelectItem value="Sălaj">Sălaj</SelectItem>
                        <SelectItem value="Sibiu">Sibiu</SelectItem>
                        <SelectItem value="Suceava">Suceava</SelectItem>
                        <SelectItem value="Teleorman">Teleorman</SelectItem>
                        <SelectItem value="Timiș">Timiș</SelectItem>
                        <SelectItem value="Tulcea">Tulcea</SelectItem>
                        <SelectItem value="Vaslui">Vaslui</SelectItem>
                        <SelectItem value="Vâlcea">Vâlcea</SelectItem>
                        <SelectItem value="Vrancea">Vrancea</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="fh-email">Email *</Label>
                    <Input
                      id="fh-email"
                      type="email"
                      value={newFhEmail}
                      onChange={(e) => setNewFhEmail(e.target.value)}
                      placeholder="contact@firma.ro"
                    />
                  </div>
                  <div>
                    <Label htmlFor="fh-phone">Telefon *</Label>
                    <Input
                      id="fh-phone"
                      value={newFhPhone}
                      onChange={(e) => setNewFhPhone(e.target.value)}
                      placeholder="0712345678"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="fh-description">Descriere *</Label>
                  <Textarea
                    id="fh-description"
                    value={newFhDescription}
                    onChange={(e) => setNewFhDescription(e.target.value)}
                    placeholder="Descrierea firmei..."
                    rows={4}
                  />
                </div>
                <div>
                  <Label htmlFor="fh-tracking-phone">Nr. Tracking Twilio</Label>
                  <Input
                    id="fh-tracking-phone"
                    value={newFhTrackingPhone}
                    onChange={(e) => setNewFhTrackingPhone(e.target.value)}
                    placeholder="+40700000000"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Numărul Twilio pentru tracking apeluri (opțional)
                  </p>
                </div>
                <Button onClick={handleCreateFuneralHome} className="w-full">
                  Creează Firma Funerară
                </Button>
              </div>
            </DialogContent>
            </Dialog>
            <Popover>
              <PopoverTrigger asChild>
                <div className="relative md:w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none z-10" />
                  <Input
                    placeholder="Caută după nume..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9 pr-9 cursor-pointer"
                  />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSearchQuery("");
                      }}
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded-md hover:bg-accent z-10"
                      aria-label="Șterge"
                    >
                      <X className="h-3.5 w-3.5 text-muted-foreground" />
                    </button>
                  )}
                </div>
              </PopoverTrigger>
              <PopoverContent
                className="w-[--radix-popover-trigger-width] p-0 bg-popover z-50"
                align="start"
                onOpenAutoFocus={(e) => e.preventDefault()}
              >
                <Command shouldFilter={false}>
                  <CommandList className="max-h-72">
                    <CommandEmpty>Nicio firmă găsită.</CommandEmpty>
                    <CommandGroup>
                      {funeralHomes
                        .filter((fh) =>
                          fh.name.toLowerCase().includes(searchQuery.toLowerCase())
                        )
                        .slice(0, 50)
                        .map((fh) => (
                          <CommandItem
                            key={fh.id}
                            value={fh.name}
                            onSelect={() => setSearchQuery(fh.name)}
                          >
                            <Building2 className="mr-2 h-4 w-4 text-muted-foreground" />
                            <span className="truncate">{fh.name}</span>
                          </CommandItem>
                        ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
          </div>
        </div>

        {missingTrackingCount > 0 && (
          <div className="mb-6 rounded-lg border border-destructive/40 bg-destructive/10 p-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm">
              <span className="font-semibold">{missingTrackingCount}</span> firme nu au număr de tracking Twilio.
              Fără el, apelurile nu pot fi urmărite sau înregistrate, iar butonul de apel nu se afișează pe site.
            </p>
            <Button
              variant={onlyMissingTracking ? "default" : "outline"}
              size="sm"
              className="shrink-0"
              onClick={() => setOnlyMissingTracking((v) => !v)}
            >
              {onlyMissingTracking ? "Arată toate firmele" : "Arată doar firmele fără număr"}
            </Button>
          </div>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Lista Firmelor Funerare</CardTitle>
          </CardHeader>
          <CardContent>
            {funeralHomes.length === 0 ? (
              <BrandState title="Nu există firme funerare înregistrate încă." />
            ) : filteredFuneralHomes.length === 0 ? (
              <BrandState title="Nu s-au găsit firme care să corespundă căutării." />
            ) : (
              <>
                {/* Mobile cards */}
                <div className="md:hidden space-y-3">
                  {filteredFuneralHomes.map((home) => (
                    <div key={home.id} className="rounded-lg border bg-card p-4 space-y-1.5">
                      <div className="flex items-start justify-between gap-2">
                        <p className="font-semibold">{home.name}</p>
                        {scores[home.id] && <FirmScoreBadge score={scores[home.id]} showStars={false} />}
                      </div>
                      <p className="text-sm text-muted-foreground">{home.city}, {home.county}</p>
                      {home.tracking_phone && (
                        <p className="text-sm">
                          <span className="text-muted-foreground">Tracking: </span>
                          <span className="text-green-600 font-medium">{home.tracking_phone}</span>
                        </p>
                      )}

                      
                      <div className="flex justify-end gap-2 pt-1">
                        <Link to={`/admin/funeral-home/${home.id}/dashboard`}>
                          <Button variant="outline" size="sm" title="Administrare firmă">
                            <LayoutDashboard className="h-4 w-4" />
                          </Button>
                        </Link>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditHome(home)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDeleteFuneralHome(home.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Desktop table */}
                <div className="hidden md:block">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nume</TableHead>
                        <TableHead>Oraș</TableHead>
                        <TableHead>Județ</TableHead>
                        <TableHead className="hidden lg:table-cell">Email</TableHead>
                        <TableHead className="hidden lg:table-cell">Telefon</TableHead>
                        <TableHead>Nr. Tracking</TableHead>
                        <TableHead>
                          <button
                            className="inline-flex items-center gap-1 hover:text-foreground transition-colors"
                            onClick={() => setSortByScore((v) => !v)}
                            title="Sortează după scor"
                          >
                            Scor
                            <ArrowUpDown className={sortByScore ? "h-3 w-3" : "h-3 w-3 opacity-40"} />
                          </button>
                        </TableHead>
                        <TableHead className="text-right">Acțiuni</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredFuneralHomes.map((home) => (
                        <TableRow key={home.id}>
                          <TableCell className="font-medium">{home.name}</TableCell>
                          <TableCell>{home.city}</TableCell>
                          <TableCell>{home.county}</TableCell>
                          <TableCell className="hidden lg:table-cell">{home.email}</TableCell>
                          <TableCell className="hidden lg:table-cell">{home.phone}</TableCell>
                          <TableCell>
                            {home.tracking_phone ? (
                              <span className="text-green-600 font-medium">{home.tracking_phone}</span>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </TableCell>
                          <TableCell>
                            {scores[home.id] ? (
                              <FirmScoreBadge score={scores[home.id]} />
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </TableCell>

                          
                          <TableCell className="text-right">
                            <Link to={`/admin/funeral-home/${home.id}/dashboard`}>
                              <Button variant="ghost" size="sm" className="mr-1" title="Administrare firmă">
                                <LayoutDashboard className="h-4 w-4" />
                              </Button>
                            </Link>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditHome(home)}
                              className="mr-1"
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteFuneralHome(home.id)}
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Edit Funeral Home Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Editare Firmă Funerară</DialogTitle>
              <DialogDescription>
                Modificați detaliile firmei {editingHome?.name}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit-name">Nume Firmă *</Label>
                <Input
                  id="edit-name"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  placeholder="Ex: Casa Funerară Speranța"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-city">Oraș *</Label>
                  <Input
                    id="edit-city"
                    value={editCity}
                    onChange={(e) => setEditCity(e.target.value)}
                    placeholder="Ex: București"
                  />
                </div>
                <div>
                  <Label htmlFor="edit-county">Județ *</Label>
                  <Select value={editCounty} onValueChange={setEditCounty}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selectați județul" />
                    </SelectTrigger>
                    <SelectContent>
                      {["Alba","Arad","Argeș","Bacău","Bihor","Bistrița-Năsăud","Botoșani","Brașov","Brăila","București","Buzău","Caraș-Severin","Călărași","Cluj","Constanța","Covasna","Dâmbovița","Dolj","Galați","Giurgiu","Gorj","Harghita","Hunedoara","Ialomița","Iași","Ilfov","Maramureș","Mehedinți","Mureș","Neamț","Olt","Prahova","Satu Mare","Sălaj","Sibiu","Suceava","Teleorman","Timiș","Tulcea","Vaslui","Vâlcea","Vrancea"].map((county) => (
                        <SelectItem key={county} value={county}>{county}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-email">Email *</Label>
                  <Input
                    id="edit-email"
                    type="email"
                    value={editEmail}
                    onChange={(e) => setEditEmail(e.target.value)}
                    placeholder="contact@firma.ro"
                  />
                </div>
                <div>
                  <Label htmlFor="edit-phone">Telefon *</Label>
                  <Input
                    id="edit-phone"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    placeholder="0712345678"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="edit-description">Descriere *</Label>
                <Textarea
                  id="edit-description"
                  value={editDescription}
                  onChange={(e) => setEditDescription(e.target.value)}
                  placeholder="Descrierea firmei..."
                  rows={4}
                />
              </div>
              <div>
                <Label htmlFor="edit-tracking-phone">Nr. Tracking Twilio</Label>
                <Input
                  id="edit-tracking-phone"
                  value={editTrackingPhone}
                  onChange={(e) => setEditTrackingPhone(e.target.value)}
                  placeholder="+40700000000"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Numărul Twilio pentru tracking apeluri (opțional)
                </p>
              </div>
              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                  Anulează
                </Button>
                <Button onClick={handleSaveHome}>
                  Salvează
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default AdminManageFuneralHomesPage;
