import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import Navigation from "@/components/Navigation";
import Seo from "@/components/Seo";
import { supabase } from "@/integrations/supabase/client";
import { romanianCounties } from "@/types/funeral";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import {
  BarChart3, Check, CheckCircle2, ChevronsUpDown, Handshake, LayoutGrid, LifeBuoy, Mail, Phone, PhoneCall, ShieldCheck,
} from "lucide-react";
import { cn } from "@/lib/utils";

const benefits = [
  { icon: PhoneCall, title: "Apeluri directe din zona ta", description: "Familiile care au nevoie de servicii funerare te sună direct de pe platformă." },
  { icon: ShieldCheck, title: "Număr dedicat, apeluri înregistrate", description: "Primești un număr de telefon dedicat, iar fiecare apel este înregistrat și poate fi verificat." },
  { icon: LayoutGrid, title: "Profil complet", description: "Prezintă-ți serviciile și pachetele într-un profil clar, ușor de găsit." },
  { icon: BarChart3, title: "Statistici și rezultate", description: "Vezi apelurile, cererile de ofertă și rezultatele lunare într-un singur panou." },
  { icon: Handshake, title: "Plătești pentru rezultate", description: "Primești o ofertă adaptată firmei tale, în funcție de zonă și volum." },
  { icon: LifeBuoy, title: "Te ajutăm la configurare", description: "Echipa noastră te ajută să-ți configurezi profilul, serviciile și pachetele." },
];

const steps = [
  { title: "Trimiți cererea", description: "Completezi formularul scurt de mai jos." },
  { title: "Primești oferta", description: "Te contactăm cu o ofertă personalizată." },
  { title: "Îți activăm profilul", description: "Profilul tău apare pe Funerio și începi să primești apeluri." },
];

const faqs = [
  { q: "Cât costă?", a: "Prețul se stabilește personalizat, în funcție de zonă și volum. Trimite cererea și revenim cu o ofertă." },
  { q: "Există un contract pe termen lung?", a: "Detaliile colaborării se stabilesc împreună, în oferta personalizată." },
  { q: "Cât de repede pot începe?", a: "După ce accepți oferta, îți configurăm profilul de obicei în câteva zile." },
  { q: "Pot vedea apelurile primite?", a: "Da. Ai acces la un panou cu toate apelurile, înregistrările și rezultatele." },
];

const schema = z.object({
  name: z.string().trim().min(2, "Introduceți numele (minimum 2 caractere)").max(100),
  companyName: z.string().trim().min(2, "Introduceți numele firmei").max(200),
  phone: z.string().trim().min(10, "Numărul de telefon trebuie să aibă cel puțin 10 cifre").max(20),
  email: z.string().trim().email("Email invalid").max(255),
  county: z.string().min(2, "Alegeți județul"),
  message: z.string().trim().max(1500, "Mesajul este prea lung").optional(),
});

const norm = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

const PartnersPage = () => {
  const [county, setCounty] = useState("");
  const [countyOpen, setCountyOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const scrollToForm = () => document.getElementById("cerere-oferta")?.scrollIntoView({ behavior: "smooth" });

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const parsed = schema.safeParse({
      name: fd.get("name"), companyName: fd.get("companyName"), phone: fd.get("phone"),
      email: fd.get("email"), county, message: (fd.get("message") as string) || "",
    });
    if (!parsed.success) { toast.error(parsed.error.errors[0].message); return; }
    const d = parsed.data;
    setLoading(true);
    const { error } = await supabase.functions.invoke("send-contact-email", {
      body: {
        name: d.name, email: d.email, phone: d.phone, companyName: d.companyName,
        message: `Cerere ofertă partener\nJudeț: ${d.county}\n\n${d.message || "Doresc o ofertă personalizată pentru listarea firmei pe Funerio."}`,
      },
    });
    setLoading(false);
    if (error) { toast.error("A apărut o eroare. Vă rugăm încercați din nou."); return; }
    setSent(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <Seo
        title="Devino partener Funerio — Clienți noi pentru firma ta funerară"
        description="Listează-ți firma de servicii funerare pe Funerio: apeluri directe din zona ta, profil complet și statistici. Cere o ofertă personalizată."
      />
      <Navigation />

      <main className="container mx-auto px-4 py-12">
        <div className="mx-auto max-w-5xl space-y-16">
          {/* Hero */}
          <section className="text-center">
            <Badge variant="secondary" className="mb-4 px-4 py-1 text-sm">Pentru firme funerare</Badge>
            <h1 className="mb-4 text-4xl font-bold md:text-5xl">Primește clienți noi din zona ta, prin Funerio</h1>
            <p className="mx-auto mb-8 max-w-2xl text-lg text-muted-foreground">
              Familiile care caută servicii funerare te găsesc și te sună direct. Tu te ocupi de clienți, noi de vizibilitate.
            </p>
            <Button variant="hero" size="lg" className="rounded-full" onClick={scrollToForm}>
              Cere o ofertă personalizată
            </Button>
          </section>

          {/* Benefits */}
          <section>
            <h2 className="mb-8 text-center text-2xl font-bold md:text-3xl">De ce Funerio?</h2>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {benefits.map((b) => (
                <Card key={b.title} className="text-center">
                  <CardContent className="pt-6">
                    <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                      <b.icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="mb-2 font-semibold">{b.title}</h3>
                    <p className="text-sm text-muted-foreground">{b.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          {/* Steps */}
          <section>
            <h2 className="mb-8 text-center text-2xl font-bold md:text-3xl">Cum funcționează</h2>
            <div className="grid gap-6 md:grid-cols-3">
              {steps.map((s, i) => (
                <div key={s.title} className="flex flex-col items-center text-center">
                  <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-primary text-lg font-bold text-primary-foreground">
                    {i + 1}
                  </div>
                  <h3 className="mb-1 font-semibold">{s.title}</h3>
                  <p className="text-sm text-muted-foreground">{s.description}</p>
                </div>
              ))}
            </div>
          </section>

          {/* Form */}
          <section id="cerere-oferta" className="scroll-mt-24">
            <Card className="mx-auto max-w-2xl border-primary/30">
              <CardContent className="p-6 md:p-8">
                {sent ? (
                  <div className="py-8 text-center">
                    <CheckCircle2 className="mx-auto mb-4 h-12 w-12 text-primary" />
                    <h2 className="mb-2 text-2xl font-bold">Mulțumim!</h2>
                    <p className="text-muted-foreground">Revenim cu o ofertă personalizată în cel mult 24 de ore.</p>
                  </div>
                ) : (
                  <>
                    <h2 className="mb-1 text-center text-2xl font-bold">Cere o ofertă personalizată</h2>
                    <p className="mb-6 text-center text-sm text-muted-foreground">Durează mai puțin de un minut.</p>
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div className="grid gap-4 sm:grid-cols-2">
                        <div className="space-y-1.5"><Label htmlFor="name">Nume</Label><Input id="name" name="name" className="rounded-full" required /></div>
                        <div className="space-y-1.5"><Label htmlFor="companyName">Numele firmei</Label><Input id="companyName" name="companyName" className="rounded-full" required /></div>
                        <div className="space-y-1.5"><Label htmlFor="phone">Telefon</Label><Input id="phone" name="phone" type="tel" className="rounded-full" required /></div>
                        <div className="space-y-1.5"><Label htmlFor="email">Email</Label><Input id="email" name="email" type="email" className="rounded-full" required /></div>
                      </div>
                      <div className="space-y-1.5">
                        <Label>Județ</Label>
                        <Popover open={countyOpen} onOpenChange={setCountyOpen}>
                          <PopoverTrigger asChild>
                            <Button type="button" variant="outline" role="combobox" className="w-full justify-between rounded-full font-normal">
                              {county || <span className="text-muted-foreground">Alege județul</span>}
                              <ChevronsUpDown className="h-4 w-4 opacity-50" />
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-[--radix-popover-trigger-width] p-0" align="start">
                            <Command
                              filter={(value, search) => (norm(value).includes(norm(search)) ? 1 : 0)}
                            >
                              <CommandInput placeholder="Caută județul..." />
                              <CommandList>
                                <CommandEmpty>Niciun județ găsit.</CommandEmpty>
                                <CommandGroup>
                                  {romanianCounties.map((c) => (
                                    <CommandItem key={c} value={c} onSelect={() => { setCounty(c); setCountyOpen(false); }}>
                                      <Check className={cn("mr-2 h-4 w-4", county === c ? "opacity-100" : "opacity-0")} />
                                      {c}
                                    </CommandItem>
                                  ))}
                                </CommandGroup>
                              </CommandList>
                            </Command>
                          </PopoverContent>
                        </Popover>
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="message">Mesaj (opțional)</Label>
                        <Textarea id="message" name="message" rows={3} placeholder="Ex: orașele în care activați, servicii principale" />
                      </div>
                      <Button type="submit" variant="hero" size="lg" className="w-full rounded-full" disabled={loading}>
                        {loading ? "Se trimite..." : "Trimite cererea"}
                      </Button>
                    </form>
                  </>
                )}
              </CardContent>
            </Card>
            <div className="mt-6 flex flex-col items-center justify-center gap-3 text-sm sm:flex-row sm:gap-8">
              <span className="flex items-center gap-2"><Phone className="h-4 w-4 text-primary" /> 0800 123 456 (L–V, 09:00–18:00)</span>
              <span className="flex items-center gap-2"><Mail className="h-4 w-4 text-primary" /> contact@funerio.ro</span>
            </div>
          </section>

          {/* FAQ */}
          <section className="mx-auto max-w-2xl">
            <h2 className="mb-6 text-center text-2xl font-bold md:text-3xl">Întrebări frecvente</h2>
            <Accordion type="single" collapsible>
              {faqs.map((f) => (
                <AccordionItem key={f.q} value={f.q}>
                  <AccordionTrigger className="text-left">{f.q}</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </section>
        </div>
      </main>
    </div>
  );
};

export default PartnersPage;
