import { Link, Navigate, useParams } from "react-router-dom";
import Navigation from "@/components/Navigation";
import Seo from "@/components/Seo";
import FuneralHomeCard from "@/components/FuneralHomeCard";
import BrandState from "@/components/brand/BrandState";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronRight } from "lucide-react";
import { useFuneralHomes } from "@/hooks/useFuneralHomes";
import { slugify } from "@/lib/slug";
import { citiesInCounty, getCountyBySlug, serviceLandings } from "@/content/serviceLandings";

const SITE_URL = "https://funerio.ro";

const CountyLandingPage = () => {
  const { slug = "" } = useParams();
  const county = getCountyBySlug(slug);
  const { funeralHomes, loading } = useFuneralHomes();

  if (!county) return <Navigate to="/servicii" replace />;

  const homes = funeralHomes.filter((h) => h.location.county === county);
  const cities = citiesInCounty(county);

  const jsonLd = [
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "Acasă", item: `${SITE_URL}/` },
        { "@type": "ListItem", position: 2, name: "Servicii funerare", item: `${SITE_URL}/servicii-funerare` },
        { "@type": "ListItem", position: 3, name: `Județul ${county}`, item: `${SITE_URL}/servicii-funerare/${slug}` },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Seo
        title={`Servicii funerare în județul ${county} | Funerio`}
        description={`Firme de servicii funerare din județul ${county}: prețuri transparente, disponibilitate non-stop și oferte personalizate.`}
        jsonLd={jsonLd}
        noindex={!loading && homes.length === 0}
      />
      <Navigation />

      <div className="container mx-auto px-4 py-8 sm:px-6">
        <nav aria-label="Breadcrumb" className="mb-6 flex flex-wrap items-center gap-1 text-sm text-muted-foreground">
          <Link to="/" className="hover:text-primary">Acasă</Link>
          <ChevronRight className="h-3 w-3" />
          <Link to="/servicii" className="hover:text-primary">Servicii</Link>
          <ChevronRight className="h-3 w-3" />
          <span className="text-foreground">Județul {county}</span>
        </nav>

        <header className="mb-8 max-w-3xl mx-auto text-center">
          <h1 className="mb-3 text-2xl font-bold md:text-4xl">Servicii funerare în județul {county}</h1>
          <p className="text-sm text-muted-foreground md:text-lg">
            Toate firmele de pompe funebre din județul {county} listate pe Funerio, cu servicii, pachete și prețuri
            afișate transparent.
          </p>
          <div className="mt-6">
            <Link to={`/cere-oferta?county=${encodeURIComponent(county)}`}>
              <Button size="lg">Cere ofertă în {county}</Button>
            </Link>
          </div>
        </header>

        <section className="mb-12">
          <h2 className="mb-5 text-xl font-semibold md:text-2xl">Firme din județul {county}</h2>
          {loading ? (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {[1, 2, 3].map((i) => <Skeleton key={i} className="h-72 rounded-lg" />)}
            </div>
          ) : homes.length === 0 ? (
            <BrandState
              title={`Momentan nu avem firme listate în județul ${county}.`}
              description="Trimite o cerere de ofertă și te punem în legătură cu firmele din zonă."
            />
          ) : (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {homes.map((home) => <FuneralHomeCard key={home.id} funeralHome={home} />)}
            </div>
          )}
        </section>

        <section className="mb-12">
          <h2 className="mb-4 text-xl font-semibold">Localități din județul {county}</h2>
          <div className="flex flex-wrap gap-2">
            {cities.map((c) => (
              <Link
                key={c.city}
                to={`/servicii-funerare/${slugify(c.city)}`}
                className="rounded-full border px-4 py-2 text-sm hover:border-primary hover:text-primary"
              >
                Servicii funerare {c.city}
              </Link>
            ))}
          </div>
        </section>

        <section>
          <h2 className="mb-4 text-xl font-semibold">Servicii disponibile</h2>
          <div className="flex flex-wrap gap-2">
            {serviceLandings.map((s) => (
              <Link
                key={s.slug}
                to={s.base}
                className="rounded-full border px-4 py-2 text-sm hover:border-primary hover:text-primary"
              >
                {s.label}
              </Link>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default CountyLandingPage;
