# Project architecture decisions

- Keep firm call leads and requested offers in separate dashboard tabs while reusing their existing data sources and detail flow; this makes each workflow easy to find without duplicating records.- Services and packages require admin approval (approval_status column enforced by DB trigger; public RLS shows only approved); firms cannot self-approve because the trigger resets non-admin writes to pending.
- Firm priority score lives in DB function get_firm_priority_scores (90-day window, new firms blend from a start score over first calls); initiate-sequential-call weights random order by it and src/lib/firmScore.ts mirrors the same formula for display.
