// Runs before `vite dev` and `vite build` (predev/prebuild hooks); writes public/sitemap.xml.

import { writeFileSync } from "fs";
import { resolve } from "path";
import { articles } from "../src/content/articles";
import { landingCities, serviceLandings } from "../src/content/serviceLandings";
import { slugify } from "../src/lib/slug";

const BASE_URL = "https://funerio.ro";

interface SitemapEntry {
  path: string;
  lastmod?: string;
  changefreq?: "always" | "hourly" | "daily" | "weekly" | "monthly" | "yearly" | "never";
  priority?: string;
}

const staticEntries: SitemapEntry[] = [
  { path: "/", changefreq: "weekly", priority: "1.0" },
  { path: "/firme", changefreq: "weekly", priority: "0.9" },
  { path: "/cere-oferta", changefreq: "monthly", priority: "0.9" },
  { path: "/servicii", changefreq: "weekly", priority: "0.8" },
  { path: "/articole", changefreq: "weekly", priority: "0.7" },
  { path: "/contact", changefreq: "monthly", priority: "0.7" },
  { path: "/faq", changefreq: "monthly", priority: "0.6" },
  { path: "/terms", changefreq: "yearly", priority: "0.3" },
  { path: "/privacy", changefreq: "yearly", priority: "0.3" },
  { path: "/gdpr", changefreq: "yearly", priority: "0.3" },
  { path: "/return-policy", changefreq: "yearly", priority: "0.3" },
];

const articleEntries: SitemapEntry[] = articles.map((a) => ({
  path: `/articole/${a.slug}`,
  lastmod: a.updated ?? a.date,
  changefreq: "monthly",
  priority: "0.7",
}));

const citySlugs = new Set(landingCities.map((c) => slugify(c.city)));

const serviceHubEntries: SitemapEntry[] = serviceLandings.map((s) => ({
  path: s.base,
  changefreq: "weekly",
  priority: "0.8",
}));

const serviceCityEntries: SitemapEntry[] = serviceLandings.flatMap((s) =>
  landingCities.map((c) => ({
    path: `${s.base}/${slugify(c.city)}`,
    changefreq: "weekly" as const,
    priority: "0.8",
  }))
);

// County hubs live under /servicii-funerare/:countySlug, but a city with the same
// slug takes precedence in routing, so those collisions are excluded.
const countyEntries: SitemapEntry[] = Array.from(new Set(landingCities.map((c) => c.county)))
  .map((county) => slugify(county))
  .filter((slug) => !citySlugs.has(slug))
  .map((slug) => ({
    path: `/servicii-funerare/${slug}`,
    changefreq: "weekly" as const,
    priority: "0.7",
  }));

const entries: SitemapEntry[] = [
  ...staticEntries,
  ...serviceHubEntries,
  ...serviceCityEntries,
  ...countyEntries,
  ...articleEntries,
];

function generateSitemap(list: SitemapEntry[]) {
  const urls = list.map((e) =>
    [
      `  <url>`,
      `    <loc>${BASE_URL}${e.path}</loc>`,
      e.lastmod ? `    <lastmod>${e.lastmod}</lastmod>` : null,
      e.changefreq ? `    <changefreq>${e.changefreq}</changefreq>` : null,
      e.priority ? `    <priority>${e.priority}</priority>` : null,
      `  </url>`,
    ]
      .filter(Boolean)
      .join("\n")
  );

  return [
    `<?xml version="1.0" encoding="UTF-8"?>`,
    `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
    ...urls,
    `</urlset>`,
  ].join("\n");
}

writeFileSync(resolve("public/sitemap.xml"), generateSitemap(entries));
console.log(`sitemap.xml written (${entries.length} entries)`);
